# Cine/Figure OS

Dark-mode web OS: boot screen, lock screen, left app rail, top bar, Ctrl K search, app drawer, wallpapers, profile, config.

## What's new in 2.17
- **OBS Studio** (taskbar + App Store > Tools). A remake of OBS inside the OS: **Scenes** and **Sources** docks, a live preview canvas (click to select, drag to move, corner handle to resize, double-click for Properties), an **Audio Mixer** (Mic/Aux and OS audio with meters, volume and mute), **Cut / Fade** scene transitions, screenshots, and **recording** with pause / resume to WebM (or MP4 where the browser supports it). Sources: OS Capture, Image, Color, Text and Video Capture Device (camera), each with position, size, opacity and (for video / images) crop and scaling.
  **OS-only recording:** the OS Capture source cannot see your PC. In the desktop app `main.js` answers the page's screen request with the OS's own window (`setDisplayMediaRequestHandler`, no picker, requests from webviews or other frames get nothing). In a plain browser it uses `getDisplayMedia({ preferCurrentTab })` so the OS tab is the one on offer. Recording hides the OBS window (Settings) so the video shows the OS, with a red dot on the taskbar icon; Ctrl+Shift+R starts / stops, Ctrl+Shift+P pauses. "Capture OS audio" in the desktop app records all PC sound (Electron has no per-window audio), so it is off by default; the mic is a separate channel.
  Not included: live streaming (browsers cannot send RTMP), plugins and filters. Code: `public/obs.js`, the `.ob-*` styles at the end of `public/style.css`, and the capture handler in `main.js`.

## What's new in 2.16
- **Lyrics in Cine-Tunes.** Now Playing has a mic button (next to the queue button) that swaps the cover art for lyrics. When the song has timings the current line is highlighted and scrolls along like Spotify, and clicking a line jumps the song to it. If you scroll yourself, auto-scroll pauses for a couple of seconds. The expand button on the lyrics (or `lyrics full` in the Terminal) opens **full-screen lyrics** over the whole player, with the cover as a blurred background, play / prev / next, a seek bar and a button for true full screen (Esc closes). The mic in the player bar opens lyrics too. Server side: `/api/music/lyrics` in `lib/api.js` asks https://lrclib.net (free, no key), tries an exact match first and a search second, and falls back to plain (unsynced) text; instrumentals and "no lyrics" are shown as such. Code: the "lyrics" block in the Cine-Tunes part of `public/apps.js`, styles at the end of `public/style.css`.
- **Search with a choice** (Ctrl K and the top bar). Pick **Everything**, **Cine-Tunes**, **FigureTube** or **Web**; Tab / Shift+Tab switches, the choice is remembered, and the top bar label and icon follow it. Enter on a Cine-Tunes search opens Cine-Tunes on its Search page and runs it, FigureTube opens with the results, Web opens Cine-Web. In *Everything* mode apps and games still come first and the three searches follow. Code: `SMODES` / `renderStart` in `public/os.js`, markup `#sm-modes` in `public/index.html`.
- **Terminal 1.2.** It now starts with a **CINE OS** banner drawn only with `|` and `/` (horizontal strokes are `//`, vertical strokes `||`, with a `/|/|` line above and below). It measures the window and switches to a narrower banner when needed. New commands: `slash <text>` (any text in the same style), `clock` (live big clock), `music <words>`, `np` (now playing with a progress bar), `play` / `pause` / `next` / `prev`, `lyrics [full]`, `top`, `stats`, `timer 1m30s`, `speedtest` (simulated), `genpass [length]`, `uuid`, `rainbow <text>` and `snake` (arrow keys / WASD, Esc quits). Ctrl+C stops the clock, Tab now also completes command names, and `banner` replays the intro (`logo` prints the old one).

## What's new in 2.15
- **Visual Code** (new app on the taskbar). A code editor for the OS's own code: file explorer, tabs, syntax colours, find / replace, Ctrl+S. Code: `public/vcode.js`, backend `lib/vcode.js`, IPC in `main.js`, bridge in `preload.js` (`cine.code`).
  - **Only app code can be edited.** It only sees the `public/` folder (index.html, style.css, the app scripts, icons...). `main.js`, `preload.js`, `lib/` and your PC's files are not reachable. Paths are checked (no `..`, no drive letters), only web file types are allowed (html css js json svg txt md png jpg gif webp ico mp3 ogg wav mp4 webm woff ttf...), and the first save of every session needs you to press **Allow editing** in a native dialog.
  - **Your edits never overwrite the originals.** They are saved in a separate folder (`custom` inside the app's data folder, `%APPDATA%\cine-figure-os\custom` on Windows; menu **...** > *Open the folder with my edits*) and `main.js` serves that copy instead of the original. That works in `npm start` and in the built .exe. **Revert** (right-click a file) deletes your copy; **Reset all edits** removes everything.
  - **Add files:** Upload button or drag files onto the explorer (PNG, JPG, GIF, WebP, SVG, audio, video, fonts). Pick the folder (default `icons`), then use the path in your code, e.g. `icons/mine.png`.
  - **Run your edits:** Save shows CSS changes instantly. **Apply** saves everything and reloads the OS so HTML / JS changes run (Ctrl+Enter).
  - **If an edit breaks the OS:** the page tells the app when it started fine. If the last launch with edits never got that far, the next start asks whether to run in **Safe mode** (original files, your edits kept and marked with a dot) so you can fix or revert the file and press Apply. You can also pick *Reload in safe mode* from the **...** menu, or delete the `custom` folder by hand.
  - Not available in a plain browser or the `npm run dev` server (Localhost mode does serve your edits).
- **Steam Sync fixed.** Steam removed the old XML game list. Sync now reads the games page you see when signed in (the list is embedded in the page), with a backup that asks the Steam Store which apps your account owns. It says what is wrong if it still can't read anything (not signed in / nothing returned).

## What's new in 2.14
- **Steam** (App Store > Games). The real https://store.steampowered.com and https://steamcommunity.com inside the OS, in one saved profile (`persist:steam`, follows the proxy setting), so your Steam sign-in sticks. Tabs: Store, Library, Community. Code: `public/steam.js`, icon `public/icons/steam.png` (replace that file with your own icon).
  - **Playing Steam games:** commercial Steam games can't be bundled or streamed by the OS, so they start in the **real Steam client on the same PC**. On any game's store page a bar appears with **PLAY** (`steam://run/<id>`), **INSTALL** (`steam://install/<id>`) and **Add to library**. The Library tab also launches them. Needs Steam installed and signed in; if it isn't, the OS says so.
  - **Library:** Steam games (Add a game = search the Steam store, popular free-to-play suggestions, or Sync = read your game list from the Community tab while signed in; Sync is best effort and needs your game details to be public) and **Playable in the OS** (every HTML game that ships with Cine-Play, played in a full-screen overlay, back button to leave).
  - Security: only `steam://run|rungameid|install|open|store/...` links are ever handed to the OS (`STEAM_URL_RE` in `main.js`); webview `steam://` links are routed through the same check. Search runs through `/api/steam/search` in `lib/api.js`.

## What's new in 2.13
- **Figure Shorts** (FigureTube > Shorts, or `shorts` in the Terminal). A full-height vertical feed of short clips (up to 75 s) from YouTube, played through the same embedded player as FigureTube. Mouse wheel, swipe or the Up / Down buttons and arrow keys move between shorts, click pauses, `M` mutes, `L` likes, and the topic buttons on the left (For you, Funny, Gaming, ...) reload the feed. A Shorts row also appears on the FigureTube home page. Server side: `/api/yt/shorts` in `lib/api.js` mixes several `#shorts` searches and keeps only clips of 75 s or less. If YouTube refuses an embed, that short is skipped; after 6 in a row you get an Open on YouTube button.
- **FigureTube redesign.** The category buttons now live in a side panel (Home, Shorts, Explore, Recent searches) opened and closed with the menu button at the top left (remembered). The home page has a featured video, a Shorts row and a grid with channel avatars; cards, the side panel and the Up next list animate in and react on hover. The watch page has Like, Share and YouTube buttons. Code: `public/apps.js` (FigureTube) and the FIGURETUBE block in `public/style.css`.
- **Terminal 1.1.** `sudo install 'AppName'` / `sudo uninstall 'AppName'` (also `sudo apt install x`, `sudo remove x`, `sudo install list`) install or remove App Store apps with a progress bar, pinning them to the taskbar just like the store does. Built-in apps can't be removed. New commands: `open`, `store`, `neofetch`, `uptime`, `version`, `lock`, `pwd`, `ls`, `shorts`, `yt <words>`, `web <url or words>`, `fortune`, `joke`, `cowsay`, `banner`, `dice`, `flip`, `8ball`, `calc`, `ping` (simulated), `hack` (fake), `matrix` (click or press a key to stop) and a few easter eggs. Tab completes app names after `install`, `uninstall`, `open`, `task main` and `kill task`.
- **Boot screen polish:** shine sweep on the logo, pulsing ring around Enter Cine, drifting particles, version tag.

## What's new in 2.12
- **TikTok** (App Store > Social). The real https://www.tiktok.com/en/ web app inside the OS, in its own saved profile (`persist:tiktok`, follows the proxy setting). Code: `public/tiktok.js`, icon `public/icons/tiktok.png`.
- **Localhost button.** Config > Localhost turns the desktop app into a localhost site: it starts the dev server inside the app on `127.0.0.1` (first free port from 3000), shows the link with Open and Copy buttons, and stops it when you press the button again. It is off at every launch and is not reachable from other devices. The browser version keeps its own saved settings and apps (a different origin from the app window). Code: `cine:host-*` handlers in `main.js`, `host` in `preload.js`, the tab in `public/settings.js`.

## What's new in 2.11
- **App loading screen.** Opening any app for the first time (Cine-Play, Cine-Tunes, Discord, Messages, ...) shows a black glitch screen: a flickering, broken bar frame that fills in chunks, with LOADING underneath (about 1.6 s, the app loads behind it). Re-opening a minimized app skips it. Config > Performance > "App Loading Screen" turns it off; with "Optimized Background" or your system's reduce-motion setting on it is a short static version. Code: `showLoader()` in `public/os.js`, styles at the end of `public/style.css`.

## What's new in 2.10
- **Video wallpaper.** "Cinematic (video)" (public/wallpapers/cinematic.mp4) is in the Wallpapers menu and Config > Personalization, for the home screen, the lock screen, or both. It plays muted and looped, only while it is on screen, and stops when "Optimized Background" is on. The desktop app serves it with HTTP Range support so it loops cleanly.
- **FigureTube plays videos again.** The watch page now uses YouTube's player API (same method as Cine-Tunes). If YouTube refuses the embed (error 101/150/153) or it never starts within 10 seconds, FigureTube swaps in the real youtube.com page inside the app. There is also a "Not playing? Use the full YouTube player" button under every video.
- **English-only results.** Searches ask YouTube for US/English results and then drop anything in an Indian script, from well-known Indian channels, or with Indian-language keywords (Hindi, Tamil, Bollywood, Bigg Boss, T-Series and so on; the list is in `lib/helpers.js` > `INDIAN_WORDS`). The old "trending today" search was literally matching a Tamil channel called Today Trending; Trending is now a mix of several English searches.
- **More videos.** The grid fits many more thumbnails per row (about 8 on a 1080p screen), with 24 skeletons while loading, up to ~60 results per search (extra result pages are fetched), and 24 related videos next to a playing video.
- **Mantle** is in Cine-Play (`public/games/mantle.html`, with its own icon and cover). It is a launcher that loads its hub from GitHub, so it needs internet the first time.

## What's new in 2.9
- **Messages** (new app on the taskbar and home screen). Add friends by username, accept or decline requests, and chat in private DMs like Discord: online dots, typing indicator, emoji picker, links, delete your own messages, unread badges on the taskbar and home tile, and a pop-up when a friend writes (even with the app closed). No calling. Settings (gear, bottom left) has your avatar colour and Sign out.
- **Nothing highlights blue any more.** Ctrl+A, click-dragging and double-click no longer select the interface. Text boxes, chat text and the Terminal output can still be selected and copied.
- **Home screen polish:** even tile grid, long names wrap onto two lines (no more "Stardew V..."), glassier tiles with an accent glow on hover, and accent section titles.

### Setting up Messages (one time)
Friends can only chat if you are all connected to the same chat server. It is a tiny Node program in `messages-server/` (no packages to install).

1. On the PC (or host) that will run it: `cd messages-server` then `node server.js` (or `npm run messages-server` from the main folder). It prints the port (default 3939). Accounts and chats are saved to `data.json` next to it.
2. Make it reachable by your friends. Any of these works:
   - A free Node host (Render, Railway, Fly, Replit, Glitch...): upload the `messages-server` folder, start command `node server.js`. You get an `https://...` address.
   - Your own PC: port-forward 3939, or use a tunnel (for example `cloudflared tunnel --url http://localhost:3939` gives you an `https://...` address with nothing to forward).
3. Everyone opens Messages, types the server address, picks **Create account**, then adds each other from **Friends > Add friend**.

Use `https://` addresses when you can (passwords are sent to the server). Passwords are stored hashed (scrypt), never in plain text. Only friends can message each other.
Host tip: free hosts that sleep or reset their disk will lose `data.json`. Set `DATA_FILE` to a persistent disk path if the host offers one.

## What's new in 2.8
- **Fix: top-right profile button** was drawn as a stretched blob with a giant letter (a Cine-Tunes style clashed with the avatar style). Also stopped the same class names from touching Cine-Play's featured banner.
- **Fix: songs stuck at 0:30.** YouTube refuses to play inside a page that has no https referrer (error 153), and the OS runs from cine://, so every song fell back to the 30-second preview. The app now gives YouTube a valid referrer and no longer sends a cine:// origin. A video that never starts is skipped after 9 seconds, and if Cine-Tunes does have to fall back to the preview it says why next to the artist name (for example "YouTube error 153").
- **Cine-Play redesign.** Home opens with a Continue Playing banner (or today's featured game), Your Games and Try Something New rows. Cards show the genre, an installed check, and a play button on hover. Genre filter chips in Library and Play Store, Remove from library, live search that no longer rebuilds the page on every key, proper empty states, a faster splash (the input-method picker only appears the first time; click to skip), and Esc exits a running game.
- **Cine-Tunes polish.** Recently played (Home row and sidebar), Mute button with remembered volume, keyboard shortcuts (Space play/pause, Left/Right seek 5s, M mute), seek and volume bars that show their handle on hover, cleaner card play buttons, a Try again button when music fails to load, and an icon-only sidebar when the window is narrow.
- **Cine-Tunes: Now Playing screen.** Click the cover or the expand button in the player bar for a full card with big cover art, heart, seek bar (elapsed / time left), shuffle, previous, play, next and repeat. The list button opens the queue, the three dots jump to the artist, the album or the video view.
- **Cine-Tunes: Albums.** New Albums tab with browse rows and album search. An album page shows the cover, year, length and the full track list (click any track to play from there), plus Play and Shuffle.
- **Cine-Tunes: Artist profiles.** Click any artist name (songs, albums, Now Playing) to open a profile: photo, top songs, albums, singles and EPs, and a short bio. Search now returns artists, songs and albums.
- **Shuffle** in the player bar and Now Playing (each song plays once per round; Previous steps back through what was played).
- Data: iTunes for songs, albums and artists; the bio and photo come from Wikipedia when a match is found (no match just means no bio).

## What's new in 2.7
- **Motion layer.** Animated boot (drifting glow, fade-up logo, pulsing button) and lock screen, a staggered reveal of the top bar, taskbar, home tiles and widgets when you unlock, windows that slide in and out when opened and closed, a sliding title in the top bar, springy taskbar / tile / app hover and press effects, animated Start menu, app drawer, context menu and profile popover, modals that spring in, and toasts that slide in and out with a countdown bar. FigureTube and Cine-Tunes show shimmering skeleton cards while loading. Everything respects the system's reduce-motion setting.
- **New App Store.** Auto-rotating featured carousel, Discover and Installed tabs (with a count), category chips (Entertainment, Games, Social, Tools), live search that keeps focus while you type, cards with a GET -> progress ring -> OPEN button, and a slide-in details panel (what you get, source, status, uninstall). Right-click an installed app to uninstall, as before.

## What's new in 2.6
- **Taskbar behaves like a real one.** Unpin an app (right-click > Unpin from taskbar) and it leaves the left rail. Open it and it appears on the rail with the running dot; close it and it disappears again. Right-click a running app to Pin it back. Drag pinned icons to reorder, middle-click to close.
- A broken app no longer leaves a ghost window or rail icon; errors show a short toast instead of failing silently.
- Empty Start menu now explains how to pin; the app drawer updates right away when you pin / unpin.

## What's new in 2.5
- **It's an app now, not a website.** `npm start` opens a desktop window. There is no localhost and no port: the OS is served from the app files through a private `cine://` address and the data APIs run inside the app. `npm run dev` (browser at localhost:3000) still exists for development only.
- **Cine-Web is a real browser with its own search engine.** Tabs, a Cine-Search results page (rendered by the OS), and every tab is a full browser view, so sites that block iframes, logins and videos just work. Popups open as new tabs. The shield button sets a **proxy** (`socks5://host:port` or `http://host:port`, optional `user:pass@`) for the browser, Netflix and Discord.
- **CineFlix (the Netflix slot) is now https://www.movy.sx/** running inside the OS with its own saved sign-in. Ad popups are dropped; it follows the proxy setting.
- **Discord** (the real discord.com/channels/@me web app, signed in and saved inside the OS). Install it from the App Store like Xbox.
- **New title bar**: the plain Windows frame is replaced by a slim dark bar with the logo, title, a settings button and smooth minimize / maximize / close buttons. Drag it to move the window, double-click to maximize.
- Two new games with cover art: **PEAK** and **Among Us** (Among Us downloads ~860 MB the first time it starts, then loads from cache).
- Profile and settings are stored per app (they do not carry over from the old localhost version).

## Run it
    npm install

    npm start                # opens Cine/Figure OS as a desktop app (no localhost)
    npm run dist             # builds dist/Cine-Figure-OS.exe (portable, double-click to run)
    npm run dist:installer   # a normal Windows installer instead

Needs Node 18+ and internet access (search, FigureTube, music, maps and the games fetch live data). Run `npm run dist` on Windows (building a Windows .exe from Mac/Linux needs Wine).
`npm run dev` is only for working on the code in a normal browser.

To add a game: drop `<id>.webp` (cover art) and `<id>-icon.png` (square icon) in `public/icons/games/`, the game's .html in `public/games/`, and add a `mkGame(...)` line to `public/games.js`.

## Apps
- Cine-Web: tabbed browser + own search engine + proxy switch (see 2.5)
- FigureTube: real YouTube search + playback (youtube-nocookie embeds)
- Cine-Tunes: music search; plays **full songs** with a real timeline, Repeat (off / all / one) and an optional video view.
  Songs are found on iTunes and played through the YouTube player; if a song can't be found the 30s iTunes preview is the fallback.
- CineFlix: the real movy.sx site inside the OS
- Cine-Play: game launcher that runs the HTML games in `public/games/` (add more by dropping a .html file there and adding a line to `public/games.js`)
- App Store: Cine-Tunes, FigureTube, CineFlix, Cine-Maps, Xbox and Steam must be installed from here first (GET). Right-click an installed app to uninstall it.
- Steam: real Steam Store + Community, Library, PLAY/INSTALL through the Steam client (see 2.14)
- Xbox: Xbox Cloud Gaming (https://www.xbox.com/en-us/play). In the desktop app (`npm start`) it runs the real site in the OS with its own saved profile, so your Microsoft sign-in stays. In a plain browser it opens the site in a new tab.
- Mini player: small music player in the bottom right. Shows when a song is loaded and Cine-Tunes isn't on screen. Closing Cine-Tunes while a song plays minimizes it so the music keeps going; the X on the mini player really closes it.
- Messages: friends + private chat (see 2.9). Needs the chat server in `messages-server/`.
- Terminal: a tiny shell (see below)
- Cine-Maps: our own map app on open data. Street / Light / Dark / Satellite / Terrain styles, place search,
  nearby categories, driving / walking / cycling directions with steps, saved places, measure tool, my location.
  Right-click the map for "What's here / Directions from here / to here / Save".
  Data: OpenStreetMap (tiles + Nominatim search + Overpass places), OSRM routing (routing.openstreetmap.de), CARTO, Esri, OpenTopoMap. No Google.
- Config: tabs for Performance, Personalization (12 wallpapers + upload), Shortcuts, Data and About

## Terminal commands
    sudo RS desktop              restart the desktop
    sudo task main 'FigureTube'  open an app   (names are not case sensitive, quotes optional)
    sudo kill task 'FigureTube'  close an app
    apps · tasks · clear · help · date · whoami · echo · history

Up/Down = command history, Tab completes app names after `task main` / `kill task`.

## Files
main.js (desktop window, cine:// protocol, proxy) · preload.js · lib/api.js (data APIs) · lib/vcode.js (Visual Code files) · server.js (dev server only) · lib/helpers.js · public/index.html · style.css · core.js · os.js · profile.js · apps.js · terminal.js · maps.js · settings.js · games.js · xbox.js · steam.js · vcode.js · store.js · minitunes.js · messages.js · public/icons/ · messages-server/server.js (chat server, run separately)
