// Cine/Figure OS desktop app (Electron). `npm start` runs this.
// There is NO local web server and no localhost port: the OS is served straight from the app files through the
// private cine:// protocol, and the data APIs (FigureTube, music, maps, search) run inside this process.
const { app, BrowserWindow, Menu, shell, protocol, session, ipcMain, net, dialog, desktopCapturer } = require('electron');
const path = require('path');
const fs = require('fs');
const { Readable } = require('stream');
const { pathToFileURL } = require('url');
const { routes } = require('./lib/api');
const vcodeLib = require('./lib/vcode');

const PUBLIC = path.join(__dirname, 'public');

/* ---------- Visual Code: edits live in userData/custom and are layered over public/ (see lib/vcode.js) ---------- */
let OVER = null;          // the edits folder (set in boot)
let vc = null;            // file operations for Visual Code
let safeMode = false;     // true = the original files are served and your edits are ignored (for fixing a broken edit)
let codeUnlocked = false; // Visual Code only writes after you allowed it in a native dialog (reset on every reload)
const stateFile = () => path.join(app.getPath('userData'), 'vcode-state.json');
const readCodeState = () => { try { return JSON.parse(fs.readFileSync(stateFile(), 'utf8')) || {}; } catch { return {}; } };
const writeCodeState = st => { try { fs.writeFileSync(stateFile(), JSON.stringify(st)); } catch {} };
const isPlainFile = f => { try { return fs.statSync(f).isFile(); } catch { return false; } };

// cine:// must be registered as a standard + secure scheme before the app is ready (so localStorage, IndexedDB and fetch work)
protocol.registerSchemesAsPrivileged([
  { scheme: 'cine', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true, allowServiceWorkers: true } },
]);

// Look like plain Chrome to every site (an "Electron/x" token makes some sites refuse to load or stream)
app.userAgentFallback = app.userAgentFallback.replace(/\s*Electron\/\S+/i, '').replace(/\s*cine-figure-os\/\S+/i, '');

let win = null;

/* ---------- cine:// protocol: static OS files + /api/* ---------- */
function registerProtocol() {
  protocol.handle('cine', async req => {
    const u = new URL(req.url);
    let p;
    try { p = decodeURIComponent(u.pathname); } catch { return new Response('Bad request', { status: 400 }); }

    if (p.startsWith('/msg/')) return msgProxy(req, u, p.slice(4)); // Messages: talk to the chat server from here (no browser CORS / mixed-content limits)

    if (p.startsWith('/api/')) {
      const name = p.slice(5);
      const fn = Object.prototype.hasOwnProperty.call(routes, name) ? routes[name] : null;
      if (!fn) return Response.json({ error: 'Unknown API' }, { status: 404 });
      try {
        const { status, body } = await fn(Object.fromEntries(u.searchParams));
        return Response.json(body, { status });
      } catch (e) {
        return Response.json({ error: String(e && e.message || e), results: [] }, { status: 500 });
      }
    }

    if (p === '/') p = '/index.html';
    let file = path.normalize(path.join(PUBLIC, p));
    if (file !== PUBLIC && !file.startsWith(PUBLIC + path.sep)) return new Response('Forbidden', { status: 403 });
    if (OVER && !safeMode) { // a file you edited (or added) in Visual Code wins over the original
      const o = path.normalize(path.join(OVER, p));
      if (o.startsWith(OVER + path.sep) && isPlainFile(o)) file = o;
    }
    // media (the video wallpaper) needs HTTP Range support to loop and seek, which a plain file fetch does not give us
    const range = /^bytes=(\d*)-(\d*)$/.exec(req.headers.get('range') || '');
    if (range && /\.(mp4|webm|m4v)$/i.test(file)) {
      let st; try { st = fs.statSync(file); } catch { return new Response('Not found', { status: 404 }); }
      let start = range[1] === '' ? Math.max(0, st.size - Number(range[2])) : Number(range[1]);
      let end = range[1] === '' || range[2] === '' ? st.size - 1 : Math.min(Number(range[2]), st.size - 1);
      if (!(start <= end) || start >= st.size) return new Response(null, { status: 416, headers: { 'content-range': `bytes */${st.size}` } });
      return new Response(Readable.toWeb(fs.createReadStream(file, { start, end })), {
        status: 206,
        headers: { 'content-type': /\.webm$/i.test(file) ? 'video/webm' : 'video/mp4', 'accept-ranges': 'bytes', 'content-length': String(end - start + 1), 'content-range': `bytes ${start}-${end}/${st.size}` },
      });
    }
    return net.fetch(pathToFileURL(file).toString());
  });
}

/* ---------- Messages: forward the app's chat requests (incl. the live event stream) to the chat server ---------- */
async function msgProxy(req, u, rest) {
  let base; try { base = new URL(u.searchParams.get('server') || ''); } catch { return Response.json({ error: 'Bad server address' }, { status: 400 }); }
  if (!/^https?:$/.test(base.protocol)) return Response.json({ error: 'Server address must start with http:// or https://' }, { status: 400 });
  const target = new URL(base.origin + base.pathname.replace(/\/+$/, '') + rest);
  u.searchParams.forEach((v, k) => { if (k !== 'server') target.searchParams.set(k, v); });
  const headers = {}; for (const h of ['authorization', 'content-type']) if (req.headers.get(h)) headers[h] = req.headers.get(h);
  const init = { method: req.method, headers, signal: req.signal };
  if (req.method !== 'GET' && req.method !== 'HEAD') init.body = await req.text();
  try {
    const r = await net.fetch(target.toString(), init);
    return new Response(r.body, { status: r.status, headers: { 'content-type': r.headers.get('content-type') || 'application/json', 'cache-control': 'no-store' } });
  } catch (e) { return Response.json({ error: 'Cannot reach the chat server' }, { status: 502 }); }
}

/* ---------- "no blocks": let any site be framed / embedded, in every session the OS uses ---------- */
function unblock(ses) {
  ses.webRequest.onHeadersReceived((details, cb) => {
    const h = details.responseHeaders || {};
    for (const k of Object.keys(h)) {
      const l = k.toLowerCase();
      if (l === 'x-frame-options') delete h[k];
      else if (l === 'content-security-policy' || l === 'content-security-policy-report-only') {
        h[k] = h[k].map(v => v.replace(/(^|;)\s*frame-ancestors[^;]*/gi, '$1'));
      }
    }
    cb({ responseHeaders: h });
  });
}

// YouTube refuses to embed (player error 153) when the page has no http(s) referrer. The OS page is served from
// cine://, which sends none, so give embed / player requests a neutral https one. Needed for Cine-Tunes full songs and FigureTube.
function fixYouTubeReferer(ses) {
  ses.webRequest.onBeforeSendHeaders({ urls: ['https://www.youtube-nocookie.com/*', 'https://www.youtube.com/*', 'https://s.ytimg.com/*'] }, (details, cb) => {
    const h = details.requestHeaders || {};
    const ref = h.Referer || h.referer || '';
    if (!/^https?:\/\//i.test(ref)) { delete h.referer; h.Referer = 'https://cine-figure-os.app/'; }
    cb({ requestHeaders: h });
  });
}

/* ---------- proxy for the browser (Cine-Web) and Netflix ---------- */
const PROXIED_PARTITIONS = ['persist:web', 'persist:movy', 'persist:discord', 'persist:tiktok', 'persist:steam'];
let proxyCreds = null;
ipcMain.handle('cine:set-proxy', async (_e, raw) => {
  let rule = String(raw || '').trim().slice(0, 300);
  proxyCreds = null;
  if (rule) {
    if (!/^[a-z0-9+.-]+:\/\//i.test(rule)) rule = 'http://' + rule;               // "host:port" -> http://host:port
    let u;
    try { u = new URL(rule); } catch { return { ok: false, error: 'That is not a valid proxy address.' }; }
    if (!/^(https?|socks4|socks5):$/.test(u.protocol)) return { ok: false, error: 'Use http://, https://, socks4:// or socks5://' };
    if (u.username) proxyCreds = { user: decodeURIComponent(u.username), pass: decodeURIComponent(u.password) };
    rule = `${u.protocol}//${u.host}`;
  }
  const cfg = rule ? { mode: 'fixed_servers', proxyRules: rule, proxyBypassRules: '<local>' } : { mode: 'direct' };
  try {
    await Promise.all(PROXIED_PARTITIONS.map(p => session.fromPartition(p).setProxy(cfg)));
    await Promise.all(PROXIED_PARTITIONS.map(p => session.fromPartition(p).closeAllConnections()));
  } catch (e) { return { ok: false, error: String(e.message || e) }; }
  return { ok: true, rule };
});
// proxies that ask for a username / password
app.on('login', (event, _wc, _req, authInfo, callback) => {
  if (authInfo.isProxy && proxyCreds) { event.preventDefault(); callback(proxyCreds.user, proxyCreds.pass); }
});

/* ---------- Steam: hand steam:// links to the real Steam client (play / install games) ---------- */
// Only a short allow-list of harmless steam:// actions is ever passed to the OS (nothing a web page can use to run other programs).
const STEAM_URL_RE = /^steam:\/\/(run|rungameid|install|open|store)\/[A-Za-z0-9_\-/]*$/i;
async function openSteam(url) {
  if (!STEAM_URL_RE.test(String(url || ''))) return { ok: false, error: 'That Steam link is not allowed.' };
  try { await shell.openExternal(url); return { ok: true }; }
  catch (e) { return { ok: false, error: 'Steam does not seem to be installed on this PC.' }; }
}
ipcMain.handle('cine:open-steam', (e, url) => (win && e.sender === win.webContents ? openSteam(url) : { ok: false, error: 'Not allowed.' }));

/* ---------- Localhost mode (Config > Localhost): serve the OS on http://localhost for your browser ---------- */
// Off by default. Bound to 127.0.0.1 only, so nothing else on your network can reach it.
let hostSrv = null, hostPort = 0;
const hostState = () => ({ on: !!hostSrv, port: hostPort, url: hostSrv ? `http://localhost:${hostPort}` : '' });
ipcMain.handle('cine:host-state', e => (win && e.sender === win.webContents ? hostState() : { on: false, port: 0, url: '' }));
ipcMain.handle('cine:host-set', async (e, on) => {
  if (!win || e.sender !== win.webContents) return { ok: false, error: 'Not allowed.', ...hostState() };
  try {
    if (on && !hostSrv) {
      const { start, setOverlay } = require('./server');
      setOverlay(safeMode ? null : OVER);
      let err = null;
      for (let p = 3000; p < 3020 && !hostSrv; p++) {
        try { hostSrv = await start(p, '127.0.0.1'); hostPort = hostSrv.address().port; }
        catch (x) { err = x; if (x.code !== 'EADDRINUSE') break; }
      }
      if (!hostSrv) return { ok: false, error: err && err.code === 'EADDRINUSE' ? 'Ports 3000-3019 are all busy.' : String(err && err.message || err), ...hostState() };
    } else if (!on && hostSrv) {
      const s = hostSrv; hostSrv = null; hostPort = 0;
      await new Promise(r => { s.close(() => r()); if (s.closeAllConnections) s.closeAllConnections(); });
    }
  } catch (x) { return { ok: false, error: String(x && x.message || x), ...hostState() }; }
  return { ok: true, ...hostState() };
});

/* ---------- Visual Code (edit the app's own code) ---------- */
// Only the OS window itself may call these (never a <webview>). Writing needs a one-time "Allow" per session.
const fromOS = e => !!(win && e.sender === win.webContents);
function codeHandler(channel, needsUnlock, fn) {
  ipcMain.handle(channel, async (e, ...args) => {
    if (!fromOS(e) || !vc) return { ok: false, error: 'Not allowed.' };
    if (needsUnlock && !codeUnlocked) return { ok: false, locked: true, error: 'Editing is locked. Press Allow editing first.' };
    try { return Object.assign({ ok: true }, await fn(...args)); }
    catch (x) { return { ok: false, error: String((x && x.message) || x) }; }
  });
}
codeHandler('cine:code-info', false, () => ({ safeMode, unlocked: codeUnlocked, folder: OVER, hasMods: vc.hasMods() }));
codeHandler('cine:code-list', false, () => ({ files: vc.list() }));
codeHandler('cine:code-read', false, p => vc.read(p));
codeHandler('cine:code-original', false, p => vc.original(p));
codeHandler('cine:code-write', true, (p, text) => vc.write(p, text));
codeHandler('cine:code-write-file', true, (p, data) => vc.writeFile(p, data));
codeHandler('cine:code-reset', true, p => vc.reset(p));
codeHandler('cine:code-reset-all', true, () => { const r = vc.resetAll(); writeCodeState({ pending: false }); return r; });
// Emergency recovery works even when Visual Code or the desktop scripts are broken.
// No editing unlock required: a native confirmation protects against accidental use.
ipcMain.handle('cine:code-emergency-restore', async e => {
  if (!fromOS(e) || !vc) return { ok: false, error: 'Not allowed.' };
  if (!vc.hasMods()) return { ok: true, unchanged: true };
  const choice = await dialog.showMessageBox(win, {
    type: 'warning', buttons: ['Restore original OS', 'Cancel'], defaultId: 1, cancelId: 1,
    title: 'Cine/Figure Recovery', message: 'Restore original Visual Code scripts?',
    detail: 'All Visual Code customizations will be disabled, including added files. A backup of your edits will be kept in your app data folder. Your apps, profiles and settings will not be reset.'
  });
  if (choice.response !== 0) return { ok: false, cancelled: true };
  try {
    const backup = path.join(app.getPath('userData'), 'custom-backup-' + new Date().toISOString().replace(/[:.]/g, '-'));
    fs.renameSync(OVER, backup);
    fs.mkdirSync(OVER, { recursive: true });
    safeMode = false;
    writeCodeState({ pending: false });
    try { await session.defaultSession.clearCache(); } catch {}
    if (win) win.webContents.reloadIgnoringCache();
    return { ok: true, backup };
  } catch (err) { return { ok: false, error: String(err.message || err) }; }
});
codeHandler('cine:code-folder', false, async () => { fs.mkdirSync(OVER, { recursive: true }); await shell.openPath(OVER); return {}; });
ipcMain.handle('cine:code-unlock', async e => {
  if (!fromOS(e) || !vc) return { ok: false, unlocked: false };
  if (codeUnlocked) return { ok: true, unlocked: true };
  const r = await dialog.showMessageBox(win, {
    type: 'question', buttons: ['Allow editing', 'Cancel'], defaultId: 0, cancelId: 1, noLink: true, title: 'Visual Code',
    message: 'Let Visual Code edit Cine/Figure OS?',
    detail: 'Visual Code can change the OS\'s own look and code (the files in the public folder) and add pictures and files to it. Your edits are kept in a separate folder and the original files are never changed, so you can always revert.\n\nOnly allow this if you opened Visual Code yourself.',
  });
  codeUnlocked = r.response === 0;
  return { ok: true, unlocked: codeUnlocked };
});
// run the edits: reload the whole OS (safe = ignore the edits and run the original files)
ipcMain.handle('cine:code-apply', async (e, opts) => {
  if (!fromOS(e) || !vc || !codeUnlocked) return { ok: false, error: 'Not allowed.' };
  safeMode = !!(opts && opts.safe);
  writeCodeState({ pending: !safeMode && vc.hasMods() });
  try { await session.defaultSession.clearCache(); } catch {}
  if (win) win.webContents.reloadIgnoringCache();
  return { ok: true };
});
// the page tells us it started fine (see the end of index.html); until then a launch with edits counts as "pending"
ipcMain.on('cine:code-ok', e => { if (fromOS(e)) writeCodeState({ pending: false }); });

// custom title bar buttons
ipcMain.on('cine:win', (e, action) => {
  const w = BrowserWindow.fromWebContents(e.sender); if (!w || w !== win) return;
  if (action === 'min') w.minimize();
  else if (action === 'max') (w.isMaximized() ? w.unmaximize() : w.maximize());
  else if (action === 'close') w.close();
});
ipcMain.handle('cine:win-state', e => { const w = BrowserWindow.fromWebContents(e.sender); return w ? { max: w.isMaximized(), full: w.isFullScreen() } : { max: false, full: false }; });

async function boot() {
  OVER = path.join(app.getPath('userData'), 'custom');
  vc = vcodeLib.create(PUBLIC, OVER);
  // Safety net: if the last launch with edits never finished starting, offer to run the original files so you can fix the edit
  if (vc.hasMods()) {
    if (readCodeState().pending) {
      const r = dialog.showMessageBoxSync({
        type: 'warning', buttons: ['Start in safe mode', 'Try my edits again'], defaultId: 0, cancelId: 0, noLink: true, title: 'Cine/Figure OS',
        message: 'Cine/Figure OS did not finish starting with your edits.',
        detail: 'Safe mode runs the original files. Your edits are not deleted: open Visual Code, fix or revert the file that is marked with a dot, then press Apply.',
      });
      safeMode = r === 0;
    }
    writeCodeState({ pending: !safeMode });
  }
  registerProtocol();
  [session.defaultSession, ...['persist:web', 'persist:movy', 'persist:discord', 'persist:xbox', 'persist:tiktok', 'persist:steam'].map(p => session.fromPartition(p))].forEach(unblock);

  // OBS Studio: "OS Capture" can only ever see the OS window itself. The OS page asks for the screen, we answer with our own window
  // (no picker, no desktop, no other apps). Anything that is not the OS page itself gets nothing.
  session.defaultSession.setDisplayMediaRequestHandler(async (request, callback) => {
    try {
      const mf = win && !win.isDestroyed() ? win.webContents.mainFrame : null, f = request.frame;
      if (!mf || !f || f.processId !== mf.processId || f.routingId !== mf.routingId) return callback({});
      const sources = await desktopCapturer.getSources({ types: ['window'], thumbnailSize: { width: 0, height: 0 } });
      const me = sources.find(s => s.id === win.getMediaSourceId());
      const out = { video: me || mf };
      if (request.audioRequested) out.audio = 'loopback';
      callback(out);
    } catch { callback({}); }
  });

  fixYouTubeReferer(session.defaultSession);
  Menu.setApplicationMenu(null);
  win = new BrowserWindow({
    width: 1366, height: 820, minWidth: 900, minHeight: 600,
    backgroundColor: '#101113', title: 'Cine/Figure OS', autoHideMenuBar: true,
    frame: false, // our own title bar (public/titlebar.js) replaces the Windows one
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false, autoplayPolicy: 'no-user-gesture-required', webviewTag: true, backgroundThrottling: false, // OBS Studio keeps recording while the OS is behind another app
    },
  });
  win.maximize();
  win.webContents.on('did-start-navigation', d => { if (d && d.isMainFrame) codeUnlocked = false; }); // Visual Code has to be allowed again after every reload
  win.loadURL('cine://app/');

  // state for the custom title bar buttons (restore icon, hide bar in fullscreen)
  const sendState = () => { if (win && !win.isDestroyed()) win.webContents.send('cine:win-state', { max: win.isMaximized(), full: win.isFullScreen() }); };
  ['maximize', 'unmaximize', 'enter-full-screen', 'leave-full-screen', 'restore'].forEach(ev => win.on(ev, sendState));
  win.webContents.on('did-finish-load', sendState);

  // F11 = fullscreen, Ctrl+R = reload (no menu bar to hold these)
  win.webContents.on('before-input-event', (e, i) => {
    if (i.type !== 'keyDown') return;
    if (i.key === 'F11') { win.setFullScreen(!win.isFullScreen()); e.preventDefault(); }
    if (i.control && i.key.toLowerCase() === 'r') { win.reload(); e.preventDefault(); }
  });
  // the OS window itself never navigates away; links that leave it open in your real browser
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('cine://')) e.preventDefault(); });
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/i.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.on('closed', () => { win = null; });
}

// <webview> pages (browser tabs, Netflix, Xbox, Steam): a popup / target=_blank is handed back to the OS, which decides
// whether it becomes a new browser tab, loads in the same view, or is dropped (ad popups)
app.on('web-contents-created', (_e, contents) => {
  if (contents.getType() !== 'webview') return;
  // Steam store pages start games with steam:// links ("Play", "Install"): send those to the real Steam client
  const steamNav = (e, u) => { const url = String(u || e.url || ''); if (/^steam:/i.test(url)) { e.preventDefault(); openSteam(url); } };
  contents.on('will-navigate', steamNav);
  contents.on('will-frame-navigate', steamNav);
  contents.setWindowOpenHandler(({ url }) => {
    if (/^steam:/i.test(url)) { openSteam(url); return { action: 'deny' }; }
    if (/^https?:/i.test(url) && contents.hostWebContents && !contents.hostWebContents.isDestroyed()) {
      contents.hostWebContents.send('cine:open-url', { from: contents.id, url });
    }
    return { action: 'deny' };
  });
});

app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion'); // keep painting (and recording) when another window covers the OS
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();
else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  app.whenReady().then(boot);
  app.on('window-all-closed', () => app.quit());
}
