#!/usr/bin/env node
// Cine Messages relay - the tiny chat server behind the Messages app. No packages needed.
//   node server.js            (PORT env var changes the port, default 3939)
// Accounts, friend requests and DMs are saved to data.json next to this file (DATA_FILE env var changes it).
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const PORT = +process.env.PORT || 3939;
const FILE = process.env.DATA_FILE || path.join(__dirname, 'data.json');
const COLORS = ['#5865f2', '#eb459e', '#23a55a', '#f0b232', '#f23f43', '#9b59b6', '#1abc9c', '#e67e22'];
const MAX_TEXT = 2000, KEEP = 500;

let db = { users: {}, tokens: {}, dms: {} };
try { db = Object.assign(db, JSON.parse(fs.readFileSync(FILE, 'utf8'))); } catch {}
let dirty = false;
const save = () => { dirty = true; };
const flush = () => { if (!dirty) return; dirty = false; try { fs.writeFileSync(FILE + '.tmp', JSON.stringify(db)); fs.renameSync(FILE + '.tmp', FILE); } catch (e) { console.error('save failed', e.message); } };
setInterval(flush, 2000);
['SIGINT', 'SIGTERM'].forEach(s => process.on(s, () => { flush(); process.exit(0); }));

const live = new Map(); // user key -> Set of open event streams
const isOnline = k => (live.get(k) || new Set()).size > 0;
const pair = (a, b) => [a, b].sort().join('|');
const key = n => String(n || '').trim().toLowerCase();
const pub = k => { const u = db.users[k]; return { name: u.name, color: u.color, online: isOnline(k) }; };
function push(k, event, data) { for (const r of live.get(k) || []) r.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); }
const pushFriends = (k, ev, data) => (db.users[k].friends || []).forEach(f => push(f, ev, data));
setInterval(() => live.forEach(set => set.forEach(r => r.write(': ping\n\n'))), 25000);

function hashPw(pw, salt) { return crypto.scryptSync(pw, salt, 32).toString('hex'); }
const newToken = k => { const t = crypto.randomBytes(32).toString('hex'); db.tokens[t] = k; save(); return t; };
const hits = new Map(); // crude brute-force guard: 25 sign-in attempts / 10 min / address
function limited(ip) { const now = Date.now(), a = (hits.get(ip) || []).filter(t => now - t < 600000); a.push(now); hits.set(ip, a); return a.length > 25; }
const sent = new Map(); // 20 messages / 10 s / user
function flooding(k) { const now = Date.now(), a = (sent.get(k) || []).filter(t => now - t < 10000); a.push(now); sent.set(k, a); return a.length > 20; }

class Err extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const need = (c, status, msg) => { if (!c) throw new Err(status, msg); };

function meView(k) {
  const u = db.users[k];
  const friends = u.friends.map(f => {
    const list = db.dms[pair(k, f)] || [], last = list[list.length - 1] || null, rd = (u.read || {})[f] || 0;
    return Object.assign(pub(f), { unread: list.filter(m => m.from === f && m.ts > rd).length, last: last && { text: last.text.slice(0, 80), ts: last.ts, from: last.from } });
  });
  return { me: { name: u.name, color: u.color }, friends, incoming: u.incoming.map(n => db.users[n].name), outgoing: u.outgoing.map(n => db.users[n].name) };
}
const unlink = (arr, v) => { const i = arr.indexOf(v); if (i >= 0) arr.splice(i, 1); };

const routes = {
  'POST /register'(b, _k, ip) {
    need(!limited(ip), 429, 'Too many tries. Wait a few minutes.');
    const name = String(b.username || '').trim(), pw = String(b.password || '');
    need(/^[A-Za-z0-9_]{3,20}$/.test(name), 400, 'Username: 3-20 letters, numbers or _');
    need(pw.length >= 6 && pw.length <= 100, 400, 'Password must be at least 6 characters');
    need(!db.users[key(name)], 409, 'That username is taken');
    const salt = crypto.randomBytes(16).toString('hex');
    db.users[key(name)] = { name, salt, hash: hashPw(pw, salt), created: Date.now(), color: COLORS[Math.floor(Math.random() * COLORS.length)], friends: [], incoming: [], outgoing: [], read: {} };
    return Object.assign({ token: newToken(key(name)) }, meView(key(name)));
  },
  'POST /login'(b, _k, ip) {
    need(!limited(ip), 429, 'Too many tries. Wait a few minutes.');
    const k = key(b.username), u = db.users[k];
    const ok = u && crypto.timingSafeEqual(Buffer.from(hashPw(String(b.password || ''), u.salt), 'hex'), Buffer.from(u.hash, 'hex'));
    need(ok, 401, 'Wrong username or password');
    return Object.assign({ token: newToken(k) }, meView(k));
  },
  'POST /logout'(_b, k, _ip, tok) { delete db.tokens[tok]; save(); return { ok: true }; },
  'GET /me'(_b, k) { return meView(k); },
  'POST /profile'(b, k) { if (COLORS.includes(b.color) || /^#[0-9a-f]{6}$/i.test(b.color || '')) { db.users[k].color = b.color; save(); push(k, 'friends', {}); pushFriends(k, 'friends', {}); } return meView(k); },

  'POST /friends/add'(b, k) {
    const t = key(b.username), me = db.users[k];
    need(t, 400, 'Type a username'); need(db.users[t], 404, 'No user with that name');
    need(t !== k, 400, "You can't add yourself");
    need(!me.friends.includes(t), 400, 'You are already friends');
    if (me.incoming.includes(t)) return routes['POST /friends/accept']({ username: t }, k);
    need(!me.outgoing.includes(t), 400, 'Request already sent');
    me.outgoing.push(t); db.users[t].incoming.push(k); save();
    push(t, 'friends', {}); push(k, 'friends', {}); return { ok: true, name: db.users[t].name };
  },
  'POST /friends/accept'(b, k) {
    const t = key(b.username), me = db.users[k];
    need(me.incoming.includes(t), 404, 'No request from that user');
    unlink(me.incoming, t); unlink(db.users[t].outgoing, k);
    me.friends.push(t); db.users[t].friends.push(k); save();
    push(t, 'friends', {}); push(k, 'friends', {}); return { ok: true };
  },
  'POST /friends/decline'(b, k) { // declines an incoming request, or cancels one you sent
    const t = key(b.username), me = db.users[k]; if (!db.users[t]) return { ok: true };
    unlink(me.incoming, t); unlink(me.outgoing, t); unlink(db.users[t].incoming, k); unlink(db.users[t].outgoing, k); save();
    push(t, 'friends', {}); push(k, 'friends', {}); return { ok: true };
  },
  'POST /friends/remove'(b, k) {
    const t = key(b.username), me = db.users[k]; need(me.friends.includes(t), 404, 'Not on your friends list');
    unlink(me.friends, t); unlink(db.users[t].friends, k); save();
    push(t, 'friends', {}); push(k, 'friends', {}); return { ok: true };
  },

  'GET /messages'(b, k) {
    const w = key(b.with); need(db.users[k].friends.includes(w), 403, 'You can only read chats with friends');
    return { messages: (db.dms[pair(k, w)] || []).slice(-150) };
  },
  'POST /messages'(b, k) {
    const to = key(b.to), text = String(b.text || '').replace(/\r/g, '').trim().slice(0, MAX_TEXT);
    need(db.users[k].friends.includes(to), 403, 'You can only message friends'); need(text, 400, 'Empty message');
    need(!flooding(k), 429, 'Slow down a little');
    const m = { id: crypto.randomBytes(6).toString('hex'), from: db.users[k].name, to: db.users[to].name, text, ts: Date.now() };
    const list = db.dms[pair(k, to)] = db.dms[pair(k, to)] || []; list.push(m); if (list.length > KEEP) list.splice(0, list.length - KEEP); save();
    push(to, 'message', { m, with: db.users[k].name }); push(k, 'message', { m, with: db.users[to].name });
    return { message: m };
  },
  'POST /messages/delete'(b, k) {
    const w = key(b.with), list = db.dms[pair(k, w)] || [], i = list.findIndex(m => m.id === b.id && key(m.from) === k);
    need(i >= 0, 404, 'Message not found'); list.splice(i, 1); save();
    push(w, 'delete', { id: b.id, with: db.users[k].name }); push(k, 'delete', { id: b.id, with: db.users[w].name }); return { ok: true };
  },
  'POST /read'(b, k) { const w = key(b.with); if (db.users[w]) { db.users[k].read[w] = Date.now(); save(); push(k, 'read', { with: db.users[w].name }); } return { ok: true }; },
  'POST /typing'(b, k) { const t = key(b.to); if (db.users[k].friends.includes(t)) push(t, 'typing', { from: db.users[k].name }); return { ok: true }; },
};

const cors = { 'access-control-allow-origin': '*', 'access-control-allow-headers': 'authorization, content-type', 'access-control-allow-methods': 'GET, POST, OPTIONS', 'access-control-max-age': '86400' };
const send = (res, status, obj) => { res.writeHead(status, Object.assign({ 'content-type': 'application/json', 'cache-control': 'no-store' }, cors)); res.end(JSON.stringify(obj)); };

http.createServer((req, res) => {
  if (req.method === 'OPTIONS') { res.writeHead(204, cors); return res.end(); }
  const url = new URL(req.url, 'http://x'), ip = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress).split(',')[0].trim();
  if (url.pathname === '/' || url.pathname === '/health') return send(res, 200, { ok: true, app: 'cine-messages', users: Object.keys(db.users).length });
  const tok = (req.headers.authorization || '').replace(/^Bearer /i, ''), k = db.tokens[tok];
  const open = ['POST /register', 'POST /login'].includes(req.method + ' ' + url.pathname);

  if (url.pathname === '/events') { // live stream (server-sent events)
    if (!k || !db.users[k]) return send(res, 401, { error: 'Sign in again' });
    res.writeHead(200, Object.assign({ 'content-type': 'text/event-stream', 'cache-control': 'no-store', connection: 'keep-alive', 'x-accel-buffering': 'no' }, cors));
    res.write('retry: 3000\n\n');
    const set = live.get(k) || new Set(); live.set(k, set); const was = set.size > 0; set.add(res);
    if (!was) pushFriends(k, 'presence', { name: db.users[k].name, online: true });
    req.on('close', () => { set.delete(res); if (!set.size) { live.delete(k); pushFriends(k, 'presence', { name: db.users[k].name, online: false }); } });
    return;
  }
  const fn = routes[req.method + ' ' + url.pathname];
  if (!fn) return send(res, 404, { error: 'Not found' });
  if (!open && (!k || !db.users[k])) return send(res, 401, { error: 'Sign in again' });
  let raw = '';
  req.on('data', c => { raw += c; if (raw.length > 20000) req.destroy(); });
  req.on('end', () => {
    let body = {}; try { body = raw ? JSON.parse(raw) : Object.fromEntries(url.searchParams); } catch { return send(res, 400, { error: 'Bad request' }); }
    if (req.method === 'GET') body = Object.fromEntries(url.searchParams);
    try { send(res, 200, fn(body, k, ip, tok)); }
    catch (e) { if (e instanceof Err) send(res, e.status, { error: e.message }); else { console.error(e); send(res, 500, { error: 'Server error' }); } }
  });
}).listen(PORT, () => console.log(`Cine Messages relay running on port ${PORT}`));
