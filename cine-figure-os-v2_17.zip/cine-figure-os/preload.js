// Bridge between the OS page and the app: lets the web UI set the browser proxy and hear about popup requests.
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('cine', {
  desktop: true,
  win: {
    do: action => ipcRenderer.send('cine:win', action),          // 'min' | 'max' | 'close'
    state: () => ipcRenderer.invoke('cine:win-state'),
    onState: cb => { const h = (_e, s) => cb(s); ipcRenderer.on('cine:win-state', h); return () => ipcRenderer.removeListener('cine:win-state', h); },
  },
  host: {                                                          // Config > Localhost
    state: () => ipcRenderer.invoke('cine:host-state'),
    set: on => ipcRenderer.invoke('cine:host-set', !!on),
  },
  code: {                                                          // Visual Code (app files only, enforced in main.js)
    info: () => ipcRenderer.invoke('cine:code-info'),
    unlock: () => ipcRenderer.invoke('cine:code-unlock'),
    list: () => ipcRenderer.invoke('cine:code-list'),
    read: p => ipcRenderer.invoke('cine:code-read', String(p)),
    original: p => ipcRenderer.invoke('cine:code-original', String(p)),
    write: (p, text) => ipcRenderer.invoke('cine:code-write', String(p), String(text)),
    writeFile: (p, bytes) => ipcRenderer.invoke('cine:code-write-file', String(p), bytes),
    reset: p => ipcRenderer.invoke('cine:code-reset', String(p)),
    emergencyRestore: () => ipcRenderer.invoke('cine:code-emergency-restore'),
    resetAll: () => ipcRenderer.invoke('cine:code-reset-all'),
    apply: safe => ipcRenderer.invoke('cine:code-apply', { safe: !!safe }),
    folder: () => ipcRenderer.invoke('cine:code-folder'),
    ok: () => ipcRenderer.send('cine:code-ok'),
  },
  openSteam: url => ipcRenderer.invoke('cine:open-steam', String(url)), // steam://run/<id> etc, handled by the real Steam client
  setProxy: rule => ipcRenderer.invoke('cine:set-proxy', rule),
  onOpenUrl: cb => {
    const h = (_e, d) => cb(d);
    ipcRenderer.on('cine:open-url', h);
    return () => ipcRenderer.removeListener('cine:open-url', h);
  },
});
