// Cine/Figure OS apps
const onOpen = (w, o) => w.opts && w.opts(o);

/* ============================================================
   CINE-WEB  (our own search engine + browser with tabs and proxy)
   Desktop app: every tab is a real browser view (nothing is rewritten, so sites, logins and videos just work),
   and an optional proxy (socks5 / http) can be switched on for the whole browser.
   Plain browser (npm run dev): pages go through the rewriting /proxy route instead.
   ============================================================ */
const CW_ENGINES = [['Google', 'https://www.google.com/search?q='], ['Bing', 'https://www.bing.com/search?q='], ['DuckDuckGo', 'https://duckduckgo.com/?q='], ['Brave', 'https://search.brave.com/search?q=']];
const cwLooksLikeUrl = v => /^https?:\/\//i.test(v) || /^(localhost|[^\s/]+\.[a-z]{2,})(:\d+)?([/?#]\S*)?$/i.test(v);
const cwToUrl = v => /^https?:\/\//i.test(v) ? v : 'https://' + v;

registerApp({
  id: 'web', name: 'Cine-Web', icon: 'fa-globe', bg: '#12121a', pinned: true, onOpen,
  mount(root, w, o) {
    const desktop = !!window.cine;
    root.classList.add('cw');
    root.innerHTML = `
      <div class="cw-bar">
        <button data-a="back" title="Back"><i class="fas fa-arrow-left"></i></button>
        <button data-a="fwd" title="Forward"><i class="fas fa-arrow-right"></i></button>
        <button data-a="reload" title="Reload"><i class="fas fa-rotate-right"></i></button>
        <button data-a="home" title="Home"><i class="fas fa-house"></i></button>
        <form class="cw-url"><input placeholder="Search or enter address" autocomplete="off" spellcheck="false"></form>
        <button data-a="proxy" title="Proxy"><i class="fas fa-shield-halved"></i></button>
      </div>
      <div class="cw-tabs"></div>
      <div class="cw-pop hidden">
        <h4><i class="fas fa-shield-halved"></i> Proxy</h4>
        <p>${desktop ? 'Route this browser and Netflix through a proxy server to get past network blocks. Example: <code>socks5://127.0.0.1:1080</code> or <code>http://host:port</code> (<code>user:pass@</code> is supported).' : 'The proxy setting works in the desktop app (<code>npm start</code>). In a plain browser pages already go through the OS rewriting proxy.'}</p>
        <input class="cw-proxy" placeholder="socks5://host:port" spellcheck="false" ${desktop ? '' : 'disabled'}>
        <div class="cw-pop-row"><button class="btn" data-a="proxy-on" ${desktop ? '' : 'disabled'}>Apply</button><button class="btn ghost" data-a="proxy-off" ${desktop ? '' : 'disabled'}>Turn off</button><span class="cw-pstat"></span></div>
      </div>
      <div class="cw-view"></div>`;
    const view = $('.cw-view', root), bar = $('.cw-url input', root), tabsEl = $('.cw-tabs', root), pop = $('.cw-pop', root), pin = $('.cw-proxy', root), pstat = $('.cw-pstat', root);
    let tabs = [], active = null, uid = 0;

    /* ---- proxy ---- */
    const showProxy = () => { const r = LS.get('proxy', ''); pin.value = r; pstat.textContent = r ? 'On' : 'Off'; pstat.className = 'cw-pstat' + (r ? ' on' : ''); };
    async function applyProxy(rule) {
      pstat.textContent = 'Applying…';
      const r = await window.cine.setProxy(rule).catch(e => ({ ok: false, error: String(e) }));
      if (!r.ok) { pstat.textContent = r.error || 'Failed'; pstat.className = 'cw-pstat bad'; return false; }
      LS.set('proxy', rule.trim() ? r.rule : ''); showProxy();
      toast('Proxy', rule.trim() ? 'Browser and Netflix now use ' + r.rule : 'Proxy turned off');
      return true;
    }
    showProxy();
    if (desktop) window.cine.setProxy(LS.get('proxy', '')).catch(() => {});

    /* ---- tabs ---- */
    function newTab(input, activate = true) {
      const t = { id: ++uid, hist: [], pos: -1, cur: null, title: 'New tab', pending: false, wcid: null, el: null };
      t.pane = document.createElement('div'); t.pane.className = 'cw-pane hidden';
      t.int = document.createElement('div'); t.int.className = 'cw-int'; t.pane.append(t.int);
      view.append(t.pane); tabs.push(t);
      if (activate) select(t);
      go(t, input ? parse(input) : { t: 'home' });
      return t;
    }
    function select(t) {
      active = t; tabs.forEach(x => x.pane.classList.toggle('hidden', x !== t)); renderTabs(); syncBar();
    }
    function closeTab(t) {
      const i = tabs.indexOf(t); if (i < 0) return;
      t.pane.remove(); tabs.splice(i, 1);
      if (!tabs.length) return newTab('');
      if (active === t) select(tabs[Math.min(i, tabs.length - 1)]); else renderTabs();
    }
    function renderTabs() {
      tabsEl.innerHTML = '';
      tabs.forEach(t => {
        const d = document.createElement('div'); d.className = 'cw-tab' + (t === active ? ' on' : '');
        d.innerHTML = `<span>${esc(t.title)}</span><i class="fas fa-xmark" title="Close tab"></i>`;
        d.onclick = e => e.target.closest('.fa-xmark') ? closeTab(t) : select(t);
        d.onauxclick = e => { if (e.button === 1) closeTab(t); };
        tabsEl.append(d);
      });
      const p = document.createElement('button'); p.className = 'cw-plus'; p.title = 'New tab'; p.innerHTML = '<i class="fas fa-plus"></i>'; p.onclick = () => newTab('');
      tabsEl.append(p);
    }
    function syncBar() {
      if (!active) return;
      const c = active.cur || {}; bar.value = c.t === 'page' ? c.url : c.t === 'search' ? c.q : '';
    }
    const setTitle = (t, s) => { t.title = (s || 'New tab').slice(0, 40); renderTabs(); };

    /* ---- navigation: entries are { t:'home' } | { t:'search', q } | { t:'page', url } ---- */
    function parse(v) {
      v = String(v).trim(); if (!v) return { t: 'home' };
      return cwLooksLikeUrl(v) ? { t: 'page', url: cwToUrl(v) } : { t: 'search', q: v };
    }
    function go(t, entry, push = true) {
      if (push) { t.hist = t.hist.slice(0, t.pos + 1); t.hist.push(entry); t.pos++; }
      t.cur = entry;
      if (entry.t === 'page') showPage(t, entry.url); else showInternal(t, entry);
      if (t === active) syncBar();
    }
    // a page reported a new address (link click, redirect, script navigation)
    function onPageNav(t, url, title) {
      if (!/^https?:/i.test(url)) return;
      if (t.pending) { t.pending = false; t.cur.url = url; t.hist[t.pos] = t.cur; }
      else if (!t.cur || t.cur.t !== 'page' || t.cur.url !== url) { t.cur = { t: 'page', url }; t.hist = t.hist.slice(0, t.pos + 1); t.hist.push(t.cur); t.pos++; }
      if (title) setTitle(t, title);
      if (t === active) syncBar();
    }
    function showPage(t, url) {
      t.int.classList.add('hidden');
      t.pending = true; setTitle(t, hostLabel(url));
      if (desktop) {
        if (t.el && t.el.loadURL) { try { t.el.loadURL(url); } catch { t.el.setAttribute('src', url); } t.el.classList.remove('hidden'); return; }
        const el = document.createElement('webview');
        el.setAttribute('src', url); el.setAttribute('partition', 'persist:web'); el.setAttribute('allowpopups', '');
        el.addEventListener('dom-ready', () => { try { t.wcid = el.getWebContentsId(); } catch {} });
        const nav = e => { if (e.isMainFrame !== false) onPageNav(t, e.url, el.getTitle && safeTitle(el)); };
        el.addEventListener('did-navigate', nav);
        el.addEventListener('did-navigate-in-page', nav);
        el.addEventListener('page-title-updated', e => setTitle(t, e.title));
        t.el = el; t.pane.append(el);
      } else {
        if (!t.el) { t.el = document.createElement('iframe'); t.el.referrerPolicy = 'no-referrer'; t.pane.append(t.el); }
        t.el.classList.remove('hidden'); t.el.src = '/proxy?url=' + encodeURIComponent(url);
      }
    }
    const safeTitle = el => { try { return el.getTitle(); } catch { return ''; } };
    const hostLabel = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return 'Loading…'; } };

    function showInternal(t, entry) {
      if (t.el) t.el.classList.add('hidden');
      t.int.classList.remove('hidden');
      if (entry.t === 'home') { setTitle(t, 'New tab'); return renderHome(t); }
      setTitle(t, entry.q); renderSearch(t, entry.q);
    }

    function searchForm(val, auto) {
      return `<form class="cw-sform"><i class="fas fa-magnifying-glass"></i><input value="${esc(val)}" placeholder="Search the web or type a URL" autocomplete="off" spellcheck="false" ${auto ? 'autofocus' : ''}></form>`;
    }
    function wireSearch(t, scope) {
      const f = $('.cw-sform', scope); if (f) f.onsubmit = e => { e.preventDefault(); go(t, parse($('input', f).value)); };
    }
    function renderHome(t) {
      t.int.innerHTML = `<div class="cw-start"><h1>CINE-WEB</h1>${searchForm('', true)}<div class="cw-links"></div></div>`;
      wireSearch(t, t.int);
      [['Wikipedia', 'fa-book', 'https://en.wikipedia.org', '#3b3b46'], ['YouTube', 'fa-play', 'https://www.youtube.com', '#c4302b'], ['GitHub', 'fa-code-branch', 'https://github.com', '#24292f'],
       ['Hacker News', 'fa-newspaper', 'https://news.ycombinator.com', '#ff6600'], ['Archive', 'fa-box-archive', 'https://archive.org', '#2a5c9a']].forEach(([n, ic, u, bg]) => {
        const a = document.createElement('a'); a.innerHTML = `<div class="ico" style="background:${bg}"><i class="fas ${ic}"></i></div>${n}`;
        a.onclick = () => go(t, { t: 'page', url: u }); $('.cw-links', t.int).append(a);
      });
      setTimeout(() => { const i = $('.cw-sform input', t.int); i && t === active && i.focus(); }, 30);
    }
    async function renderSearch(t, q) {
      t.int.innerHTML = `<div class="cw-res">${searchForm(q)}<div class="loading"><span class="spin"></span></div></div>`;
      const box = $('.cw-res', t.int); wireSearch(t, box);
      const d = await api('/api/search?q=' + encodeURIComponent(q)).catch(() => ({ results: [], error: 'Could not reach the search service' }));
      if (t.cur !== t.hist[t.pos] || t.cur.q !== q) return; // the tab moved on while we waited
      const engines = CW_ENGINES.map(([n, u]) => `<a data-u="${esc(u + encodeURIComponent(q))}">${n}</a>`).join('');
      box.innerHTML = `${searchForm(q)}
        <div class="cw-meta"><span>Cine-Search${d.engine ? ' · results via ' + esc(d.engine) : ''}</span><span class="cw-eng">Also try: ${engines}</span><a class="cw-ft" data-ft="1"><i class="fas fa-play"></i> Videos on FigureTube</a></div>
        ${(d.results || []).length ? (d.results || []).map(r => `<div class="cw-r"><a data-u="${esc(r.url)}"><small>${esc(r.site)}</small><h3>${esc(r.title)}</h3></a><p>${esc(r.snippet)}</p></div>`).join('') : `<div class="err">${esc(d.error || 'No results. Try different words, or use one of the engines above.')}</div>`}`;
      wireSearch(t, box);
      box.onclick = e => {
        if (e.target.closest('[data-ft]')) return launchApp('figuretube', { q });
        const a = e.target.closest('[data-u]'); if (!a) return;
        e.ctrlKey || e.metaKey ? newTab(a.dataset.u, false) : go(t, { t: 'page', url: a.dataset.u });
      };
      t.int.scrollTop = 0;
    }

    /* ---- toolbar ---- */
    function step(d) {
      const t = active, n = t.pos + d; if (n < 0 || n >= t.hist.length) return;
      t.pos = n; go(t, t.hist[n], false);
    }
    $('.cw-url', root).onsubmit = e => { e.preventDefault(); go(active, parse(bar.value)); bar.blur(); };
    root.addEventListener('click', e => {
      const b = e.target.closest('.cw-bar [data-a], .cw-pop [data-a]'); if (!b) { if (!e.target.closest('.cw-pop')) pop.classList.add('hidden'); return; }
      const a = b.dataset.a, t = active;
      if (a === 'back') step(-1);
      if (a === 'fwd') step(1);
      if (a === 'reload') { if (t.cur.t === 'page' && t.el) { t.pending = true; t.el.reload ? t.el.reload() : (t.el.src = t.el.src); } else go(t, t.cur, false); }
      if (a === 'home') go(t, { t: 'home' });
      if (a === 'proxy') pop.classList.toggle('hidden');
      if (a === 'proxy-on') applyProxy(pin.value);
      if (a === 'proxy-off') applyProxy('');
    });
    pin.onkeydown = e => { if (e.key === 'Enter') applyProxy(pin.value); };

    // fallback (plain browser): the rewriting proxy reports its address through postMessage
    const onMsg = e => {
      if (desktop || !e.data || !e.data.cineUrl) return;
      const t = tabs.find(x => x.el && x.el.contentWindow === e.source); if (t) onPageNav(t, e.data.cineUrl, e.data.title);
    };
    addEventListener('message', onMsg);
    // popups / target=_blank from a browser tab open as a new tab
    const offOpen = desktop ? window.cine.onOpenUrl(({ from, url }) => { if (tabs.some(t => t.wcid === from)) newTab(url); }) : null;
    w.onclose = () => { removeEventListener('message', onMsg); offOpen && offOpen(); };

    w.opts = o2 => { if (o2 && o2.url) { active ? go(active, parse(o2.url)) : newTab(o2.url); } };
    newTab(o && o.url ? o.url : '');
  },
});

/* ============================================================
   FIGURETUBE  (real YouTube videos)
   ============================================================ */
registerApp({
  id: 'figuretube', name: 'FigureTube', icon: 'fa-play', img: 'icons/youtube.png', bg: 'transparent', pinned: false, store: true, onOpen,
  mount(root, w, o) {
    root.classList.add('ft');
    root.innerHTML = `
      <header class="ft-head app-head"><button class="ft-burger" title="Show / hide the side panel" aria-label="Side panel"><i class="fas fa-bars"></i></button>
        <div class="ft-logo"><i class="fas fa-play"></i><span>Figure<b>Tube</b></span></div>
        <form class="ft-search"><input placeholder="Search videos" autocomplete="off"><button><i class="fas fa-search"></i></button></form></header>
      <div class="ft-shell${LS.get('ftSide', true) ? '' : ' closed'}"><aside class="ft-side"></aside><main class="ft-main"><section class="ft-body"></section></main></div>`;
    const shell = $('.ft-shell', root), side = $('.ft-side', root), body = $('.ft-body', root), box = $('.ft-search input', root);
    const HOME = '__home'; // the server mixes several English-language searches for the home page
    const CATS = [['Music', 'fa-music', 'new official music videos 2026'], ['Gaming', 'fa-gamepad', 'gaming gameplay highlights'], ['Movie trailers', 'fa-film', 'official movie trailer 2026'], ['Tech', 'fa-microchip', 'tech review'],
      ['Comedy', 'fa-face-laugh-squint', 'stand up comedy english'], ['Sports', 'fa-futbol', 'sports highlights'], ['Science', 'fa-flask', 'science explained'], ['Cooking', 'fa-utensils', 'cooking recipes']];
    const TOPICS = [['all', 'For you'], ['funny', 'Funny'], ['gaming', 'Gaming'], ['cooking', 'Cooking'], ['science', 'Science'], ['animals', 'Animals'], ['sports', 'Sports'], ['tech', 'Tech'], ['music', 'Music']];
    const SKEL = '<div class="vid sk"><div class="th skeleton"></div><div class="skeleton line"></div><div class="skeleton line s"></div></div>';
    const hue = s => [...String(s)].reduce((a, c) => (a * 31 + c.charCodeAt(0)) % 360, 7);
    const av = n => `<span class="av" style="background:hsl(${hue(n)} 52% 38%)">${esc((String(n).trim()[0] || '?').toUpperCase())}</span>`;
    const likes = () => LS.get('ftLikes', []);
    const mode = m => { body.className = 'ft-body' + (m ? ' is-' + m : ''); };
    const copy = (t, msg) => { try { navigator.clipboard.writeText(t); toast('Copied', msg || t); } catch { toast('Copy failed', t); } };

    /* ---- side panel (open / close with the burger button; remembered) ---- */
    function sideHTML() {
      let n = 0; const b = (key, label, icon, q) => `<button class="ft-nv" data-nav="${esc(key)}"${q != null ? ` data-q="${esc(q)}"` : ''} style="--i:${n++}"><i class="fas ${icon}"></i><span>${esc(label)}</span></button>`;
      const rec = LS.get('ftRecent', []);
      side.innerHTML = b('home', 'Home', 'fa-house', HOME) + b('shorts', 'Shorts', 'fa-bolt') + '<h5>Explore</h5>' + CATS.map(c => b(c[2], c[0], c[1], c[2])).join('')
        + (rec.length ? '<h5>Recent</h5>' + rec.map(r => b('r:' + r, r, 'fa-clock-rotate-left', r)).join('') : '');
    }
    const mark = key => $$('.ft-nv', side).forEach(b => b.classList.toggle('on', b.dataset.nav === key));
    $('.ft-burger', root).onclick = () => { shell.classList.toggle('closed'); LS.set('ftSide', !shell.classList.contains('closed')); };
    side.onclick = e => { const b = e.target.closest('.ft-nv'); if (!b) return; if (b.dataset.nav === 'shorts') return shortsView(); box.value = b.dataset.nav.startsWith('r:') ? b.dataset.q : ''; grid(b.dataset.q); };

    /* ---- data ---- */
    async function list(q) { return api('/api/yt/search?q=' + encodeURIComponent(q)).catch(() => ({ results: [], error: 'Could not reach the server' })); }
    const SC = {};
    async function getShorts(t = 'all') {
      if (SC[t]) return SC[t];
      const d = await api('/api/yt/shorts?q=' + encodeURIComponent(t)).catch(() => ({ results: [], error: 'Could not reach the server' }));
      if (d.results && d.results.length) SC[t] = d; return d;
    }

    /* ---- cards ---- */
    const card = (v, cls = 'vid') => {
      const d = document.createElement('div'); d.className = cls;
      d.innerHTML = cls === 'rel'
        ? `<div class="th"><img loading="lazy" src="${esc(v.thumb)}" alt=""><span class="dur">${esc(v.duration)}</span></div><div><h4>${esc(v.title)}</h4><small>${esc(v.channel)}</small><small>${esc(v.views)} ${v.published ? '· ' + esc(v.published) : ''}</small></div>`
        : `<div class="th"><img loading="lazy" src="${esc(v.thumb)}" alt=""><span class="dur">${esc(v.duration)}</span></div><div class="vm">${av(v.channel)}<div><h4>${esc(v.title)}</h4><small>${esc(v.channel)}</small><small>${esc(v.views)} ${v.published ? '· ' + esc(v.published) : ''}</small></div></div>`;
      d.onclick = () => watch(v); return d;
    };
    function hero(v) {
      const d = document.createElement('section'); d.className = 'ft-hero';
      d.innerHTML = `<div class="hbg" style="background-image:url(${esc(v.thumb)})"></div><div class="htxt"><small>Featured</small><h2>${esc(v.title)}</h2><p>${esc(v.channel)} · ${esc(v.views)} ${v.published ? '· ' + esc(v.published) : ''}</p><button class="hplay"><i class="fas fa-play"></i> Watch now</button></div>
        <div class="hth"><img src="${esc(v.thumb)}" alt=""><span class="dur">${esc(v.duration)}</span></div>`;
      d.onclick = () => watch(v); return d;
    }
    function shelf() {
      const s = document.createElement('section'); s.className = 'ft-shelf';
      s.innerHTML = '<h3><i class="fas fa-bolt"></i> Figure Shorts<button type="button">See all<i class="fas fa-arrow-right"></i></button></h3><div class="ft-rail">' + '<div class="sc skeleton"></div>'.repeat(9) + '</div>';
      $('button', s).onclick = () => shortsView();
      getShorts('all').then(d => {
        const rail = $('.ft-rail', s); if (!rail) return;
        if (!d.results.length) return s.remove();
        rail.innerHTML = ''; d.results.slice(0, 14).forEach((v, i) => {
          const c = document.createElement('div'); c.className = 'sc'; c.style.setProperty('--i', i);
          c.innerHTML = `<img loading="lazy" src="${esc(v.thumb)}" alt=""><div class="sg"><b>${esc(v.title)}</b><small>${esc(v.views)}</small></div>`;
          c.onclick = () => shortsView(d.results, i, 'all'); rail.append(c);
        });
      });
      return s;
    }

    /* ---- player: YouTube's embedded player first; if YouTube refuses the embed (or it never starts) fall back to the real YouTube page ---- */
    let ytPlayer = null, guard = 0, tok = 0, gtok = 0;
    function stopPlayer() { tok++; clearTimeout(guard); try { ytPlayer && ytPlayer.destroy && ytPlayer.destroy(); } catch {} ytPlayer = null; }
    function fallback(v) {
      const pb = $('.ft-player', body); if (!pb) return;
      stopPlayer(); const watchEl = $('.ft-watch', body); watchEl && watchEl.classList.add('full');
      const url = 'https://www.youtube.com/watch?v=' + encodeURIComponent(v.id);
      if (window.cine) {
        pb.innerHTML = '';
        const el = document.createElement('webview');
        el.setAttribute('src', url); el.setAttribute('partition', 'persist:web'); el.setAttribute('allowpopups', '');
        pb.append(el);
      } else {
        pb.innerHTML = `<div class="ft-nope"><i class="fas fa-circle-play"></i><p>This video can only be played on YouTube itself.</p><button class="btn" data-open="1"><i class="fas fa-up-right-from-square"></i> Open on YouTube</button></div>`;
        $('[data-open]', pb).onclick = () => window.open(url, '_blank', 'noopener');
      }
      const alt = $('.ft-alt', body); alt && alt.remove();
    }
    async function playEmbed(v) {
      const my = ++tok, host = $('.ft-yt', body); if (!host) return;
      try {
        const Y = await loadYT(); if (my !== tok) return;
        ytPlayer = new Y.Player(host, {
          width: '100%', height: '100%', videoId: v.id, host: 'https://www.youtube-nocookie.com',
          playerVars: Object.assign({ autoplay: 1, rel: 0, playsinline: 1, modestbranding: 1, fs: 1 }, /^https?:$/.test(location.protocol) ? { origin: location.origin } : {}), // a cine:// origin makes YouTube refuse the embed
          events: {
            onReady: e => { try { e.target.playVideo(); } catch {} },
            onStateChange: e => { if (e.data === 1 || e.data === 3) clearTimeout(guard); },
            onError: () => { if (my === tok) fallback(v); },
          },
        });
        // some blocked embeds never start and never report an error: give it 10 seconds, then use the real YouTube page
        guard = setTimeout(() => { if (my !== tok) return; let st = -1; try { st = ytPlayer.getPlayerState(); } catch {} if (st === -1 || st === 5) fallback(v); }, 10000);
      } catch { if (my === tok) fallback(v); }
    }

    /* ---- home / search / category grid ---- */
    async function grid(q) {
      const my = ++gtok; stopPlayer(); stopShorts(); mark(q === HOME ? 'home' : q); mode('');
      body.innerHTML = '<div class="ft-grid">' + SKEL.repeat(24) + '</div>';
      const d = await list(q); if (my !== gtok) return;
      if (!d.results.length) return (body.innerHTML = `<div class="err">${esc(d.error || 'No results')}</div>`);
      const res = d.results.slice(); body.innerHTML = '<div class="ft-wrap"></div>'; const wrap = $('.ft-wrap', body);
      if (q === HOME && !box.value.trim()) { wrap.append(hero(res.shift())); wrap.append(shelf()); }
      const g = document.createElement('div'); g.className = 'ft-grid';
      res.forEach((v, i) => { const c = card(v); c.style.setProperty('--i', Math.min(i, 24)); g.append(c); }); wrap.append(g);
    }

    /* ---- watch page ---- */
    async function watch(v) {
      ++gtok; stopPlayer(); stopShorts(); mode('watch');
      const on = likes().includes(v.id);
      body.innerHTML = `<div class="ft-watch"><div class="wl"><div class="ft-player"><div class="ft-yt"></div></div>
        <h2>${esc(v.title)}</h2>
        <div class="wrow"><div class="wch">${av(v.channel)}<div><strong>${esc(v.channel)}</strong><small>${esc(v.views)} ${v.published ? '· ' + esc(v.published) : ''}</small></div></div>
          <div class="wact"><button data-w="like" class="${on ? 'on' : ''}"><i class="fas fa-thumbs-up"></i> <span>${on ? 'Liked' : 'Like'}</span></button><button data-w="share"><i class="fas fa-share"></i> Share</button><button data-w="yt"><i class="fas fa-up-right-from-square"></i> YouTube</button></div></div>
        <button class="ft-alt" title="Plays the real YouTube page inside FigureTube"><i class="fas fa-circle-play"></i> Not playing? Use the full YouTube player</button></div>
        <div class="rel-list"><h3>Up next</h3><div class="loading"><span class="spin"></span></div></div></div>`;
      body.scrollTop = 0;
      $('.ft-alt', body).onclick = () => fallback(v);
      $('.wact', body).onclick = e => {
        const b = e.target.closest('[data-w]'); if (!b) return; const a = b.dataset.w;
        if (a === 'like') { const l = likes(), i = l.indexOf(v.id); if (i < 0) l.push(v.id); else l.splice(i, 1); LS.set('ftLikes', l); b.classList.toggle('on', i < 0); $('span', b).textContent = i < 0 ? 'Liked' : 'Like'; }
        if (a === 'share') copy('https://youtu.be/' + v.id, 'Link copied');
        if (a === 'yt') window.open('https://www.youtube.com/watch?v=' + encodeURIComponent(v.id), '_blank', 'noopener');
      };
      playEmbed(v);
      const d = await list(v.title.split(/\s+/).slice(0, 5).join(' '));
      const rl = $('.rel-list', body); if (!rl) return; $('.loading', rl) && $('.loading', rl).remove();
      d.results.filter(x => x.id !== v.id).slice(0, 24).forEach((x, i) => { const c = card(x, 'rel'); c.style.setProperty('--i', i); rl.append(c); });
    }

    /* ---- Figure Shorts: full-height vertical feed (wheel / swipe / arrow keys / buttons) ---- */
    let S = null, hov = false;
    function stopShorts() { if (!S) return; clearInterval(S.tick); clearTimeout(S.guard); clearTimeout(S.skip); S.dead = true; try { S.player && S.player.destroy(); } catch {} S = null; }
    async function shortsView(items, start = 0, topic = 'all') {
      const my = ++gtok; stopPlayer(); stopShorts(); mark('shorts'); mode('shorts');
      body.innerHTML = '<div class="loading"><span class="spin"></span></div>';
      if (!items) {
        const d = await getShorts(topic); if (my !== gtok) return;
        if (!d.results.length) return (body.innerHTML = `<div class="err">${esc(d.error || 'No shorts found')}</div>`);
        items = d.results;
      }
      const s = S = { list: items, i: Math.max(0, Math.min(start, items.length - 1)), topic, muted: LS.get('ftMute', false), player: null, tick: 0, guard: 0, skip: 0, busy: 0, errs: 0, last: 0 };
      body.innerHTML = `<div class="fs"><div class="fs-bg"></div>
        <div class="fs-topics">${TOPICS.map(t => `<button data-t="${t[0]}" class="${t[0] === topic ? 'on' : ''}">${t[1]}</button>`).join('')}</div>
        <div class="fs-stage"><div class="fs-vid"></div><div class="fs-hit"></div><div class="fs-flash"><i class="fas fa-pause"></i></div><div class="fs-msg"></div>
          <div class="fs-info"><div class="fs-ch"></div><p></p></div><div class="fs-prog"><i></i></div></div>
        <div class="fs-rt"><button class="fs-b" data-s="like" title="Like (L)"><i class="fas fa-heart"></i></button><button class="fs-b" data-s="share" title="Copy link"><i class="fas fa-share"></i></button><button class="fs-b" data-s="mute" title="Mute (M)"><i class="fas fa-volume-high"></i></button><button class="fs-b" data-s="yt" title="Open on YouTube"><i class="fas fa-up-right-from-square"></i></button>
          <div class="fs-nav"><button class="fs-b" data-s="prev" title="Previous (Up)"><i class="fas fa-chevron-up"></i></button><button class="fs-b" data-s="next" title="Next (Down)"><i class="fas fa-chevron-down"></i></button></div></div></div>`;
      const fs = $('.fs', body), stage = $('.fs-stage', fs), prog = $('.fs-prog i', fs), msg = $('.fs-msg', fs);
      const cur = () => s.list[s.i];
      const flash = ic => { const f = $('.fs-flash', fs); f.innerHTML = `<i class="fas ${ic}"></i>`; f.classList.remove('go'); void f.offsetWidth; f.classList.add('go'); };
      const paintBtns = () => { $('[data-s=like]', fs).classList.toggle('on', likes().includes(cur().id)); $('[data-s=mute] i', fs).className = 'fas ' + (s.muted ? 'fa-volume-xmark' : 'fa-volume-high'); };
      const say = t => { msg.textContent = t; msg.classList.toggle('on', !!t); };
      function skip() { if (S !== s) return; s.errs++; if (s.errs >= 6) { say('Shorts can\u2019t play right now. Use the YouTube button to watch this one.'); return; } say('That one can\u2019t be played, skipping\u2026'); s.skip = setTimeout(() => { if (S === s) { s.last = 0; move(1); } }, 800); }
      async function show(dir) {
        const v = cur(); clearInterval(s.tick); clearTimeout(s.guard); clearTimeout(s.skip); say('');
        stage.classList.remove('up', 'down'); void stage.offsetWidth; if (dir) stage.classList.add(dir > 0 ? 'down' : 'up');
        $('.fs-bg', fs).style.backgroundImage = `url(${v.thumb})`;
        $('.fs-ch', fs).innerHTML = av(v.channel) + `<b>${esc(v.channel)}</b>`; $('.fs-info p', fs).textContent = v.title; paintBtns(); prog.style.width = '0';
        try { s.player && s.player.destroy(); } catch {} s.player = null;
        const vid = $('.fs-vid', fs); vid.innerHTML = '<div class="fs-yt"></div>';
        const nx = s.list[(s.i + 1) % s.list.length]; if (nx) new Image().src = nx.thumb; // warm up the next cover
        const id = v.id, mine = ++s.busy;
        try {
          const Y = await loadYT(); if (S !== s || mine !== s.busy) return;
          s.player = new Y.Player($('.fs-yt', vid), {
            width: '100%', height: '100%', videoId: id, host: 'https://www.youtube-nocookie.com',
            playerVars: Object.assign({ autoplay: 1, controls: 0, rel: 0, playsinline: 1, modestbranding: 1, fs: 0, disablekb: 1, iv_load_policy: 3, loop: 1, playlist: id }, /^https?:$/.test(location.protocol) ? { origin: location.origin } : {}),
            events: {
              onReady: e => { try { s.muted ? e.target.mute() : e.target.unMute(); e.target.playVideo(); } catch {} },
              onStateChange: e => { if (e.data === 1) { s.errs = 0; clearTimeout(s.guard); } if (e.data === 0) { try { e.target.seekTo(0); e.target.playVideo(); } catch {} } },
              onError: () => { if (S === s && mine === s.busy) skip(); },
            },
          });
          s.tick = setInterval(() => { try { const d = s.player.getDuration(), t = s.player.getCurrentTime(); if (d > 0) prog.style.width = (t / d * 100) + '%'; } catch {} }, 250);
          s.guard = setTimeout(() => { if (S !== s || mine !== s.busy) return; let st = -1; try { st = s.player.getPlayerState(); } catch {} if (st === -1 || st === 5) skip(); }, 9000);
        } catch { if (S === s) say('YouTube\u2019s player is blocked on this connection. Use the YouTube button to watch.'); }
      }
      function move(d) { if (S !== s || Date.now() - s.last < 450) return; s.last = Date.now(); s.i = (s.i + d + s.list.length) % s.list.length; show(d); }
      function toggle() { try { const st = s.player.getPlayerState(); if (st === 1) { s.player.pauseVideo(); flash('fa-pause'); } else { s.player.playVideo(); flash('fa-play'); } } catch {} }
      // gestures on the transparent layer above the video: click = play/pause, wheel or swipe = next / previous
      const hit = $('.fs-hit', fs); let y0 = null;
      hit.onpointerdown = e => { y0 = e.clientY; try { hit.setPointerCapture(e.pointerId); } catch {} };
      hit.onpointerup = e => { if (y0 == null) return; const dy = e.clientY - y0; y0 = null; if (Math.abs(dy) < 10) toggle(); else if (dy < -50) move(1); else if (dy > 50) move(-1); };
      fs.addEventListener('wheel', e => { e.preventDefault(); if (Math.abs(e.deltaY) > 6) move(e.deltaY > 0 ? 1 : -1); }, { passive: false });
      fs.onclick = e => {
        const t = e.target.closest('[data-t]'); if (t) return shortsView(null, 0, t.dataset.t);
        const b = e.target.closest('[data-s]'); if (!b) return; const a = b.dataset.s, v = cur();
        if (a === 'next') move(1); if (a === 'prev') move(-1);
        if (a === 'like') { const l = likes(), i = l.indexOf(v.id); if (i < 0) l.push(v.id); else l.splice(i, 1); LS.set('ftLikes', l); paintBtns(); }
        if (a === 'share') copy('https://www.youtube.com/shorts/' + v.id, 'Short link copied');
        if (a === 'yt') window.open('https://www.youtube.com/shorts/' + encodeURIComponent(v.id), '_blank', 'noopener');
        if (a === 'mute') { s.muted = !s.muted; LS.set('ftMute', s.muted); try { s.muted ? s.player.mute() : s.player.unMute(); } catch {} paintBtns(); }
      };
      show(0);
    }
    root.addEventListener('mouseenter', () => { hov = true; }); root.addEventListener('mouseleave', () => { hov = false; });
    const onKey = e => {
      if (!S || !root.isConnected || !(hov || root.contains(document.activeElement)) || (e.target.closest && e.target.closest('input,textarea'))) return;
      const k = e.key.toLowerCase(), b = sel => { const x = $(sel, body); x && x.click(); };
      if (k === 'arrowdown' || k === 'j') { e.preventDefault(); b('[data-s=next]'); }
      else if (k === 'arrowup') { e.preventDefault(); b('[data-s=prev]'); }
      else if (k === ' ' || k === 'k') { e.preventDefault(); const h = $('.fs-hit', body); if (h) { h.onpointerdown({ clientY: 0, pointerId: 0 }); h.onpointerup({ clientY: 0 }); } }
      else if (k === 'm') b('[data-s=mute]'); else if (k === 'l') b('[data-s=like]');
    };
    addEventListener('keydown', onKey);

    $('.ft-search', root).onsubmit = e => {
      e.preventDefault(); const q = box.value.trim(); if (!q) return;
      LS.set('ftRecent', [q, ...LS.get('ftRecent', []).filter(x => x !== q)].slice(0, 5)); sideHTML(); grid(q);
    };
    $('.ft-logo', root).onclick = () => { box.value = ''; grid(HOME); };
    w.onclose = () => { stopPlayer(); stopShorts(); removeEventListener('keydown', onKey); };
    w.opts = o => { if (!o) return; if (o.view === 'shorts') return shortsView(); if (o.q) { box.value = o.q; grid(o.q); } };
    sideHTML();
    o && o.view === 'shorts' ? shortsView() : o && o.q ? (box.value = o.q, grid(o.q)) : grid(HOME);
  },
});

/* ============================================================
   CINE-TUNES  (music: full-length songs, repeat, real timeline)
   Songs are looked up on iTunes (art / title / artist) and played in full through the
   YouTube player. If a song can't be found there we fall back to the 30s iTunes preview.
   ============================================================ */
let ytApiPromise = null;
function loadYT() {
  if (window.YT && YT.Player) return Promise.resolve(window.YT);
  return ytApiPromise || (ytApiPromise = new Promise((res, rej) => {
    const prev = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => { prev && prev(); res(window.YT); };
    const s = document.createElement('script'); s.src = 'https://www.youtube.com/iframe_api';
    s.onerror = () => { ytApiPromise = null; rej(new Error('YouTube player blocked')); };
    document.head.append(s);
    setTimeout(() => { if (!(window.YT && YT.Player)) { ytApiPromise = null; rej(new Error('YouTube player timed out')); } }, 12000);
  }));
}

registerApp({
  id: 'tunes', name: 'Cine-Tunes', icon: 'fa-music', img: 'icons/spotify.png', bg: 'transparent', pinned: false, store: true, keepAlive: true, onOpen,
  mount(root, w, o) {
    root.classList.add('tn');
    root.innerHTML = `
      <div class="tn-main">
        <aside class="tn-side">
          <div class="tn-card"><a data-v="home" class="on" title="Home"><i class="fas fa-home"></i><span>Home</span></a><a data-v="search" title="Search"><i class="fas fa-search"></i><span>Search</span></a><a data-v="albums" title="Albums"><i class="fas fa-compact-disc"></i><span>Albums</span></a></div>
          <div class="tn-card"><h4><i class="fas fa-book"></i>&nbsp; Your Library</h4>
            <div class="tn-liked" data-v="liked"><div class="box"><i class="fas fa-heart"></i></div><div><strong>Liked Songs</strong><br><small class="lk-count" style="color:#aaa"></small></div></div><div class="tn-recent"></div></div>
        </aside>
        <section class="tn-content"></section>
        <div class="tn-np hidden">
          <div class="np-bg"></div>
          <div class="np-card">
            <div class="np-top"><button data-n="close" title="Back"><i class="fas fa-chevron-left"></i></button><button data-n="menu" title="More"><i class="fas fa-ellipsis-vertical"></i></button></div>
            <div class="np-menu hidden"><a data-n="artist"><i class="fas fa-user"></i> Go to artist</a><a data-n="album"><i class="fas fa-compact-disc"></i> Go to album</a><a data-n="video"><i class="fas fa-tv"></i> Show / hide video</a></div>
            <div class="np-art empty"><img alt=""><div class="ph"><i class="fas fa-music"></i></div><button class="np-heart" data-n="like" title="Like"><i class="far fa-heart"></i></button></div>
            <div class="np-queue"><h4>Queue</h4><div class="np-ql"></div></div>
            <div class="np-meta"><div><strong class="np-t">Nothing playing</strong><small class="np-a">Pick a song</small></div><div class="np-rt"><button data-n="lyrics" title="Lyrics"><i class="fas fa-microphone-lines"></i></button><button data-n="queue" title="Queue"><i class="fas fa-list-ul"></i></button></div></div>
            <div class="np-lyrics"><button class="ly-exp" data-n="lyfull" title="Full screen lyrics"><i class="fas fa-expand"></i></button><div class="ly-body"></div></div>
            <div class="np-prog"><input class="np-seek" type="range" min="0" max="1000" value="0"><div class="np-times"><span class="ncur">0:00</span><span class="nrem">-0:00</span></div></div>
            <div class="np-btns">
              <button data-c="shuffle" class="shf" title="Shuffle: off"><i class="fas fa-shuffle"></i></button>
              <button data-c="prev" title="Previous"><i class="fas fa-backward-step"></i></button>
              <button class="np-play" data-c="play" title="Play / pause"><i class="fas fa-play"></i></button>
              <button data-c="next" title="Next"><i class="fas fa-forward-step"></i></button>
              <button data-c="repeat" class="rep" title="Repeat: off"><i class="fas fa-repeat"></i><b class="rb"></b></button>
            </div>
          </div>
        </div>
      </div>
      <div class="tn-video"><div class="tn-yt"></div></div>
      <div class="ly-full hidden">
        <div class="lf-bg"></div>
        <header class="lf-head"><img alt=""><div><strong class="lf-t">Nothing playing</strong><small class="lf-a"></small></div>
          <div class="lf-btns"><button data-l="fs" title="Toggle full screen"><i class="fas fa-expand"></i></button><button data-l="close" title="Close lyrics"><i class="fas fa-xmark"></i></button></div></header>
        <div class="ly-body"></div>
        <footer class="lf-foot"><div class="lf-prog"><span class="lf-cur">0:00</span><input class="lf-seek" type="range" min="0" max="1000" value="0"><span class="lf-dur">0:00</span></div>
          <div class="lf-ctl"><button data-c="prev" title="Previous"><i class="fas fa-backward-step"></i></button><button class="lf-play" data-c="play" title="Play / pause"><i class="fas fa-play"></i></button><button data-c="next" title="Next"><i class="fas fa-forward-step"></i></button></div></footer>
      </div>
      <footer class="tn-bar">
        <div class="tn-now"><img alt="" title="Open Now Playing"><div title="Open Now Playing"><strong>Nothing playing</strong><small>Pick a song</small></div><button class="heart"><i class="far fa-heart"></i></button><button class="expand" title="Now Playing"><i class="fas fa-up-right-and-down-left-from-center"></i></button></div>
        <div class="tn-ctl"><div class="tn-btns">
            <button data-c="shuffle" class="shf" title="Shuffle: off"><i class="fas fa-shuffle"></i></button>
            <button data-c="prev" title="Previous"><i class="fas fa-backward-step"></i></button>
            <button class="big" data-c="play" title="Play / pause"><i class="fas fa-play"></i></button>
            <button data-c="next" title="Next"><i class="fas fa-forward-step"></i></button>
            <button data-c="repeat" class="rep" title="Repeat: off"><i class="fas fa-repeat"></i><b class="rb"></b></button></div>
          <div class="tn-prog"><span class="cur">0:00</span><input type="range" min="0" max="1000" value="0"><span class="dur">0:00</span></div></div>
        <div class="tn-vol"><button class="lybtn" title="Lyrics"><i class="fas fa-microphone-lines"></i></button><button class="vtog" title="Show video"><i class="fas fa-tv"></i></button><button class="mute" title="Mute (M)"><i class="fas fa-volume-high"></i></button><input type="range" min="0" max="100" value="80"></div>
      </footer>`;

    const content = $('.tn-content', root), seek = $('.tn-prog input', root), nps = $('.np-seek', root), npEl = $('.tn-np', root), audio = new Audio();
    let queue = [], idx = -1, liked = LS.get('liked', []), repeat = LS.get('repeat', 0), shuffle = LS.get('shuffle', false);
    let kind = 'none', yt = null, ytP = null, ytState = -1, cands = [], ci = 0, token = 0, seeking = false, vol = LS.get('vol', 80);
    let hist = [], seen = new Set(), stack = [], curView = null, vtok = 0, lastErr = 0, watch = 0;
    audio.volume = vol / 100;

    const enc = encodeURIComponent;
    const fmt = s => { s = Math.max(0, Math.floor(s || 0)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = String(s % 60).padStart(2, '0'); return h ? `${h}:${String(m).padStart(2, '0')}:${x}` : `${m}:${x}`; };
    const hue = s => [...String(s)].reduce((a, c) => (a * 31 + c.charCodeAt(0)) % 360, 7);
    const big = (u, n) => String(u || '').replace(/\/\d+x\d+(bb)?\.(jpg|png|webp)/i, `/${n}x${n}bb.$2`);
    const isLiked = t => !!t && liked.some(x => x.id === t.id);
    function updateLikes() {
      $('.lk-count', root).textContent = liked.length + ' songs';
      const t = queue[idx], on = isLiked(t);
      $('.tn-now .heart i', root).className = on ? 'fas fa-heart' : 'far fa-heart'; $('.tn-now .heart', root).classList.toggle('on', on);
      $('.np-heart i', root).className = on ? 'fas fa-heart' : 'far fa-heart'; $('.np-heart', root).classList.toggle('on', on);
      $$('.trk', root).forEach(r => { const l = isLiked(r._t); $('.lk i', r).className = (l ? 'fas' : 'far') + ' fa-heart'; $('.lk', r).classList.toggle('on', l); });
    }
    function toggleLike(t) { if (!t) return; liked = isLiked(t) ? liked.filter(x => x.id !== t.id) : [...liked, t]; LS.set('liked', liked); updateLikes(); }

    /* ---- playback engine (YouTube player or 30s preview fallback) ---- */
    const cur = () => (kind === 'yt' && yt && yt.getCurrentTime ? yt.getCurrentTime() : kind === 'audio' ? audio.currentTime : 0) || 0;
    const dur = () => (kind === 'yt' && yt && yt.getDuration ? yt.getDuration() : kind === 'audio' && isFinite(audio.duration) ? audio.duration : 0) || 0;
    const playing = () => (kind === 'yt' ? ytState === 1 || ytState === 3 : kind === 'audio' ? !audio.paused : false);
    function markPlaying() {
      const t = queue[idx], p = playing();
      $$('.trk', root).forEach(r => { const c = !!t && r._t && r._t.id === t.id; r.classList.toggle('sel', c); r.classList.toggle('playing', c && p); });
    }
    function paintPlay() { $$('[data-c=play] i', root).forEach(i => (i.className = playing() ? 'fas fa-pause' : 'fas fa-play')); markPlaying(); }
    function tick() {
      const d = dur(), c = cur();
      $('.dur', root).textContent = fmt(d); $('.nrem', root).textContent = '-' + fmt(Math.max(0, d - c));
      if (seeking) return;
      const p = d ? Math.min(1000, c / d * 1000) : 0;
      seek.value = nps.value = p; $('.cur', root).textContent = $('.ncur', root).textContent = fmt(c);
      seek.style.background = `linear-gradient(to right,#1db954 ${p / 10}%,#4d4d4d ${p / 10}%)`;
      nps.style.background = `linear-gradient(to right,#f5a623 ${p / 10}%,#5a5b60 ${p / 10}%)`;
    }
    const timer = setInterval(tick, 250);
    const note = t => { $('.tn-now small', root).textContent = t; $('.np-a', root).textContent = t; };
    function paintNow() {
      const t = queue[idx];
      const art = t ? t.art : '';
      for (const img of $$('.tn-now img, .np-art img', root)) { if (art) img.src = img.closest('.np-art') ? big(art, 800) : art; else img.removeAttribute('src'); }
      $('.np-art', root).classList.toggle('empty', !art);
      $('.np-bg', root).style.backgroundImage = art ? `url("${big(art, 200)}")` : '';
      $('.tn-now strong', root).textContent = $('.np-t', root).textContent = t ? t.title : 'Nothing playing';
      if (!t) note('Pick a song');
      if (!npEl.classList.contains('hidden') && npEl.classList.contains('q')) paintQueue();
      paintLyHead(); loadLyrics(t);
    }

    function ensureYT() {
      if (ytP) return ytP;
      return (ytP = loadYT().then(Y => new Promise(res => {
        yt = new Y.Player($('.tn-yt', root), {
          width: '100%', height: '100%', host: 'https://www.youtube-nocookie.com',
          playerVars: Object.assign({ autoplay: 1, controls: 0, rel: 0, playsinline: 1, modestbranding: 1, disablekb: 1, iv_load_policy: 3 }, /^https?:$/.test(location.protocol) ? { origin: location.origin } : {}), // a cine:// origin makes YouTube refuse the embed
          events: {
            onReady: () => { yt.setVolume(vol); res(yt); },
            onStateChange: e => { ytState = e.data; if (e.data === 1) clearTimeout(watch); paintPlay(); if (e.data === 0) ended(); },
            onError: e => { lastErr = e.data; nextCandidate(); },
          },
        });
      })).catch(e => { ytP = null; throw e; }));
    }
    function stopEngines() { clearTimeout(watch); audio.pause(); audio.removeAttribute('src'); try { yt && yt.stopVideo && yt.stopVideo(); } catch {} kind = 'none'; ytState = -1; }
    function startPreview(t) {
      if (!t.url) { note(t.artist + ' · not available'); paintPlay(); return; }
      kind = 'audio'; audio.src = t.url; audio.play().catch(() => {});
      note(t.artist + ' · 30s preview' + (lastErr ? ` (YouTube error ${lastErr})` : cands.length ? '' : ' (full version not found)')); paintPlay();
    }
    // a blocked embed sometimes never starts and never reports an error: give each candidate 9s, then try the next
    function armWatch(my) { clearTimeout(watch); watch = setTimeout(() => { if (my === token && kind === 'yt' && (ytState === -1 || ytState === 5)) { lastErr = lastErr || 'timeout'; nextCandidate(); } }, 9000); }
    function nextCandidate() {
      const t = queue[idx]; if (!t) return;
      if (++ci < cands.length) { yt.loadVideoById(cands[ci]); armWatch(token); }
      else { clearTimeout(watch); try { yt.stopVideo(); } catch {} kind = 'none'; startPreview(t); }
    }
    async function play(list, i) {
      if (list !== queue) { hist = []; seen = new Set(); }
      queue = list; idx = i; const t = queue[i]; if (!t) return;
      seen.add(i);
      const my = ++token; stopEngines(); seeking = false; lastErr = 0; cands = [];
      paintNow(); note('Loading full song…');
      LS.set('lastTrack', t); bus.dispatchEvent(new Event('sidebar'));
      LS.set('recent', [t, ...LS.get('recent', []).filter(x => x.id !== t.id)].slice(0, 12)); paintRecent();
      updateLikes(); paintPlay(); tick();
      let d = { results: [] };
      try { d = await api('/api/music/resolve?' + new URLSearchParams({ title: t.title, artist: t.artist, sec: t.sec || '' })); } catch {}
      if (my !== token) return;
      cands = (d.results || []).map(x => x.id); ci = 0;
      if (cands.length) {
        try { await ensureYT(); if (my !== token) return; kind = 'yt'; ytState = -1; yt.setVolume(vol); yt.loadVideoById(cands[0]); armWatch(my); note(t.artist); return; }
        catch {}
      }
      if (my === token) startPreview(t);
    }
    // next position in the queue (-1 = nothing left and repeat is off); respects shuffle (each song once per round)
    function nextIndex() {
      if (!shuffle || queue.length < 2) return idx < queue.length - 1 ? idx + 1 : repeat === 1 ? 0 : -1;
      const left = queue.map((_, i) => i).filter(i => i !== idx && !seen.has(i));
      if (!left.length) { if (repeat !== 1) return -1; seen = new Set([idx]); return nextIndex(); }
      return left[Math.floor(Math.random() * left.length)];
    }
    function stopAtEnd() { kind === 'yt' ? yt.seekTo(0, false) : (audio.currentTime = 0); kind === 'yt' ? yt.pauseVideo() : audio.pause(); paintPlay(); tick(); }
    function skip(d, auto) {
      if (!queue.length) return;
      if (d > 0) {
        let n = nextIndex();
        if (n < 0) { if (auto) return stopAtEnd(); seen = new Set(); n = shuffle && queue.length > 1 ? (idx + 1 + Math.floor(Math.random() * (queue.length - 1))) % queue.length : 0; }
        if (idx >= 0) hist.push(idx);
        return play(queue, n);
      }
      if (shuffle && hist.length) return play(queue, hist.pop());
      play(queue, (idx - 1 + queue.length) % queue.length);
    }
    function ended() {
      if (repeat === 2 || (repeat === 1 && queue.length === 1)) { if (kind === 'yt') { yt.seekTo(0, true); yt.playVideo(); } else { audio.currentTime = 0; audio.play(); } return; }
      skip(1, true);
    }

    /* ---- navigation: sidebar views reset the history, albums / artists stack on top of it ---- */
    const guard = () => { const my = vtok; return () => my === vtok; };
    function show(fn) { if (curView) stack.push(curView); curView = fn; vtok++; content.scrollTop = 0; fn(); }
    function goBack() { curView = stack.pop() || home; vtok++; curView(); }
    const backBtn = () => (stack.length ? '<button class="tn-back" title="Back"><i class="fas fa-chevron-left"></i></button>' : '');
    const bindBack = () => { const b = $('.tn-back', content); if (b) b.onclick = goBack; };
    const nav = v => {
      $$('.tn-card [data-v]', root).forEach(a => a.classList.toggle('on', a.dataset.v === v));
      stack = []; curView = { home, search, albums: albumsView, liked: likedView }[v]; vtok++; content.scrollTop = 0; curView();
    };
    const openAlbum = id => show(() => albumView(id));
    const openArtist = ref => show(() => artistView(ref));
    const spinner = '<div class="loading"><span class="spin"></span></div>';
    const skeletons = n => '<div class="tn-grid">' + '<div class="song sk"><div class="skeleton sq"></div><div class="skeleton line"></div><div class="skeleton line s"></div></div>'.repeat(n) + '</div>';

    /* ---- cards and rows ---- */
    const card = (t, list, i) => {
      const d = document.createElement('div'); d.className = 'song';
      d.innerHTML = `<div class="cv"><img loading="lazy" src="${esc(t.art)}" alt=""><div class="pl"><i class="fas fa-play"></i></div></div><h4>${esc(t.title)}</h4><small><a class="lnk">${esc(t.artist)}</a></small>`;
      $('.lnk', d).onclick = e => { e.stopPropagation(); openArtist(t); };
      d.onclick = () => play(list, i); return d;
    };
    const albumCard = a => {
      const d = document.createElement('div'); d.className = 'song';
      d.innerHTML = `<div class="cv"><img loading="lazy" src="${esc(a.art)}" alt=""><div class="pl"><i class="fas fa-play"></i></div></div><h4>${esc(a.title)}</h4><small>${a.year ? esc(a.year) + ' · ' : ''}<a class="lnk">${esc(a.artist)}</a></small>`;
      $('.lnk', d).onclick = e => { e.stopPropagation(); openArtist(a); };
      d.onclick = () => openAlbum(a.id); return d;
    };
    const artistCard = a => {
      const d = document.createElement('div'); d.className = 'song ar';
      d.innerHTML = `<div class="tn-av" style="--h:${hue(a.name)}">${esc((a.name.trim()[0] || '?').toUpperCase())}</div><h4>${esc(a.name)}</h4><small>${esc(a.genre || 'Artist')}</small>`;
      d.onclick = () => openArtist({ id: a.id, name: a.name }); return d;
    };
    const gridOf = (list, mk) => { const g = document.createElement('div'); g.className = 'tn-grid'; list.forEach((x, i) => g.append(mk(x, list, i))); return g; };
    const section = (parent, title, list, mk) => { if (!list.length) return; const h = document.createElement('h3'); h.textContent = title; parent.append(h, gridOf(list, mk)); };
    const row = (title, list) => section(content, title, list, card);
    const trackRow = (t, list, i, op = {}) => {
      const d = document.createElement('div'); d.className = 'trk'; d._t = t;
      d.innerHTML = `<span class="n"><b>${i + 1}</b><i class="fas fa-play"></i><span class="eq"><s></s><s></s><s></s></span></span>${op.art ? `<img loading="lazy" src="${esc(t.art)}" alt="">` : ''}<div class="tt"><strong>${esc(t.title)}${t.explicit ? '<em class="ex">E</em>' : ''}</strong>${op.artist ? `<small><a class="lnk">${esc(t.artist)}</a></small>` : ''}</div><button class="lk" title="Like"><i class="far fa-heart"></i></button><span class="d">${t.sec ? fmt(t.sec) : ''}</span>`;
      d.onclick = e => {
        if (e.target.closest('.lk')) return toggleLike(t);
        if (e.target.closest('.lnk')) { closeNow(); return openArtist(t); }
        op.onPick ? op.onPick(i) : play(list, i);
      };
      return d;
    };
    const trackList = (list, op) => { const l = document.createElement('div'); l.className = 'tn-tl'; list.forEach((t, i) => l.append(trackRow(t, list, i, op))); return l; };

    /* ---- views ---- */
    async function home() {
      const ok = guard(), h = new Date().getHours(), hi = `<h2>Good ${h < 12 ? 'Morning' : h < 18 ? 'Afternoon' : 'Evening'}</h2>`;
      content.innerHTML = hi + spinner;
      const sets = [['Today’s Hits', 'top hits'], ['Indie Chill', 'indie chill'], ['Hip-Hop Heat', 'hip hop'], ['Throwback Rock', 'classic rock']];
      const [res, albums] = await Promise.all([
        Promise.all(sets.map(s => api('/api/music/search?q=' + enc(s[1])).catch(() => ({ results: [] })))),
        api('/api/music/albums?q=' + enc('top albums')).catch(() => ({ results: [] })),
      ]);
      if (!ok()) return;
      content.innerHTML = hi;
      const rec = LS.get('recent', []); if (rec.length) row('Recently played', rec);
      res.forEach((r, i) => r.results && r.results.length && row(sets[i][0], r.results));
      section(content, 'Popular albums', (albums.results || []).slice(0, 12), albumCard);
      updateLikes();
      if (!content.querySelector('.tn-grid')) { content.innerHTML += '<div class="err">Couldn’t load music. Check your internet connection.<br><button class="chipb" data-retry style="margin-top:14px">Try again</button></div>'; $('[data-retry]', content).onclick = home; }
    }
    function search(q = '', run = false) {
      content.innerHTML = '<h2>Search</h2><input class="tn-search" placeholder="Search songs, albums or artists and press Enter" autocomplete="off"><div class="res"></div>';
      const i = $('.tn-search', content); i.value = q; i.focus();
      const runSearch = async () => {
        if (!i.value.trim()) return;
        const ok = guard(), term = i.value.trim(), r = $('.res', content); r.innerHTML = skeletons(10);
        const [s, al, ar] = await Promise.all(['songs', 'albums', 'artists'].map(k => api(`/api/music/${k === 'songs' ? 'search' : k}?q=` + enc(term)).catch(() => ({ results: [] }))));
        if (!ok()) return;
        r.innerHTML = '';
        section(r, 'Artists', (ar.results || []).slice(0, 6), artistCard);
        section(r, 'Songs', s.results || [], card);
        section(r, 'Albums', (al.results || []).slice(0, 12), albumCard);
        if (!r.children.length) r.innerHTML = '<div class="err">No results</div>';
      };
      i.onkeydown = e => { if (e.key === 'Enter') runSearch(); };
      if (run && q.trim()) runSearch();
    }
    async function albumsView() {
      const ok = guard();
      content.innerHTML = '<h2>Albums</h2><input class="tn-search" placeholder="Search albums and press Enter" autocomplete="off"><div class="res">' + spinner + '</div>';
      const i = $('.tn-search', content), r = $('.res', content);
      i.onkeydown = async e => {
        if (e.key !== 'Enter' || !i.value.trim()) return;
        const ok2 = guard(); r.innerHTML = skeletons(10);
        const d = await api('/api/music/albums?q=' + enc(i.value.trim())).catch(() => ({ results: [] }));
        if (!ok2()) return;
        r.innerHTML = ''; section(r, 'Results', d.results || [], albumCard);
        if (!r.children.length) r.innerHTML = '<div class="err">No albums found</div>';
      };
      const sets = [['Popular albums', 'top albums'], ['Hip-Hop & R&B', 'hip hop'], ['Rock classics', 'classic rock'], ['Chill & indie', 'indie chill'], ['Pop', 'pop hits']];
      const res = await Promise.all(sets.map(s => api('/api/music/albums?q=' + enc(s[1])).catch(() => ({ results: [] }))));
      if (!ok()) return;
      r.innerHTML = '';
      res.forEach((x, k) => section(r, sets[k][0], x.results || [], albumCard));
      if (!r.children.length) r.innerHTML = '<div class="err">Couldn’t load albums. Check the internet connection.</div>';
    }
    async function albumView(id) {
      const ok = guard(); content.innerHTML = backBtn() + spinner; bindBack();
      const d = await api('/api/music/album?id=' + enc(id)).catch(() => null);
      if (!ok()) return;
      if (!d || !d.album) { content.innerHTML = backBtn() + '<div class="err">Couldn’t load this album.</div>'; return bindBack(); }
      const a = d.album, tr = d.tracks || [], mins = Math.max(1, Math.round(a.sec / 60));
      const kindName = /- single$/i.test(a.title) ? 'Single' : /- ep$/i.test(a.title) ? 'EP' : 'Album';
      content.innerHTML = `<div class="tn-hero alb" style="--art:url('${esc(a.art)}')">${backBtn()}<img class="cover" src="${esc(big(a.art, 600))}" alt="">
          <div class="meta"><small>${kindName}</small><h1>${esc(a.title)}</h1><p><a class="lnk">${esc(a.artist)}</a>${a.year ? ' · ' + esc(a.year) : ''} · ${tr.length} song${tr.length === 1 ? '' : 's'}${a.sec ? ', ' + mins + ' min' : ''}</p></div></div>
        <div class="tn-acts"><button class="pbig" title="Play"><i class="fas fa-play"></i></button><button class="chipb shuf"><i class="fas fa-shuffle"></i>&nbsp; Shuffle</button></div>`;
      bindBack();
      $('.lnk', content).onclick = () => openArtist(a);
      const multi = new Set(tr.map(t => t.artist)).size > 1;
      if (!tr.length) content.insertAdjacentHTML('beforeend', '<div class="err">No songs available for this album.</div>');
      else content.append(trackList(tr, { artist: multi }));
      if (a.copyright) content.insertAdjacentHTML('beforeend', `<p class="tn-cr">${esc(a.copyright)}</p>`);
      $('.pbig', content).onclick = () => tr.length && play(tr, shuffle ? Math.floor(Math.random() * tr.length) : 0);
      $('.shuf', content).onclick = () => { if (!tr.length) return; setShuffle(true); play(tr, Math.floor(Math.random() * tr.length)); };
      updateLikes(); markPlaying();
    }
    async function artistView(ref) {
      const ok = guard(), name = ref.artist || ref.name || '';
      content.innerHTML = backBtn() + spinner; bindBack();
      let id = ref.artistId || ref.id;
      if (!id && name) { const f = await api('/api/music/artists?q=' + enc(name)).catch(() => ({ results: [] })); id = f.results && f.results[0] && f.results[0].id; }
      const d = id ? await api('/api/music/artist?id=' + enc(id)).catch(() => null) : null;
      if (!ok()) return;
      if (!d || !d.artist) { content.innerHTML = backBtn() + `<div class="err">Couldn’t find ${esc(name || 'this artist')}.</div>`; return bindBack(); }
      const ar = d.artist, songs = d.songs || [], albums = d.albums || [], minis = d.minis || [], bio = d.bio;
      const cover = (albums[0] || minis[0] || songs[0] || {}).art || '';
      const photo = (bio && bio.image) || cover;
      content.innerHTML = `<div class="tn-hero ar" style="--art:url('${esc(cover)}')">${backBtn()}<img class="cover" alt="" src="${esc(photo)}">
          <div class="meta"><small>${esc(ar.genre || 'Artist')}</small><h1>${esc(ar.name)}</h1><p>${albums.length} album${albums.length === 1 ? '' : 's'}${minis.length ? ' · ' + minis.length + ' singles &amp; EPs' : ''}</p></div></div>
        <div class="tn-acts"><button class="pbig" title="Play"><i class="fas fa-play"></i></button><button class="chipb shuf"><i class="fas fa-shuffle"></i>&nbsp; Shuffle</button></div>`;
      bindBack();
      const img = $('.tn-hero .cover', content); img.onerror = () => { if (cover && img.src !== cover) img.src = cover; };
      if (songs.length) {
        const top = songs.slice(0, 10);
        content.insertAdjacentHTML('beforeend', '<h3>Popular</h3>');
        const tl = trackList(top, { art: true }); content.append(tl);
        [...tl.children].slice(5).forEach(r => r.classList.add('more', 'hidden'));
        if (top.length > 5) { const b = document.createElement('button'); b.className = 'chipb moreb'; b.textContent = 'Show more'; b.onclick = () => { const open = b.textContent === 'Show more'; $$('.more', tl).forEach(r => r.classList.toggle('hidden', !open)); b.textContent = open ? 'Show less' : 'Show more'; }; content.append(b); }
      }
      section(content, 'Albums', albums, albumCard);
      section(content, 'Singles & EPs', minis, albumCard);
      if (bio && bio.text) {
        const ab = document.createElement('div'); ab.className = 'tn-about';
        ab.innerHTML = `${bio.image ? `<img alt="" src="${esc(bio.image)}">` : ''}<div><h3>About</h3><p>${esc(bio.text)}</p><small>From Wikipedia${bio.url ? ` · <a href="${esc(bio.url)}" target="_blank" rel="noopener">Read more</a>` : ''}</small></div>`;
        content.append(ab);
      }
      if (!songs.length && !albums.length && !minis.length) content.insertAdjacentHTML('beforeend', '<div class="err">Nothing to show for this artist yet.</div>');
      $('.pbig', content).onclick = () => songs.length && play(songs, shuffle ? Math.floor(Math.random() * songs.length) : 0);
      $('.shuf', content).onclick = () => { if (!songs.length) return; setShuffle(true); play(songs, Math.floor(Math.random() * songs.length)); };
      updateLikes(); markPlaying();
    }
    function likedView() {
      content.innerHTML = '<h2>Liked Songs</h2>';
      if (!liked.length) return (content.innerHTML += '<div class="err">Tap the heart on a song to save it here.</div>');
      content.append(trackList(liked, { art: true, artist: true })); updateLikes(); markPlaying();
    }
    $$('.tn-card [data-v]', root).forEach(a => a.onclick = () => nav(a.dataset.v));

    /* ---- lyrics: synced line by line when LRCLIB has timings, plain text otherwise ---- */
    const lf = $('.ly-full', root), lfSeek = $('.lf-seek', lf);
    let ly = { id: null, state: 'idle', synced: [], plain: '', instr: false }, lyAct = -1, lfDrag = false;
    const lyBodies = () => $$('.ly-body', root);
    function paintLyHead() {
      const t = queue[idx], art = t ? t.art : '';
      $('.lf-t', lf).textContent = t ? t.title : 'Nothing playing'; $('.lf-a', lf).textContent = t ? t.artist : '';
      const im = $('.lf-head img', lf); if (art) im.src = big(art, 200); else im.removeAttribute('src');
      $('.lf-bg', lf).style.backgroundImage = art ? `url("${big(art, 200)}")` : '';
    }
    function lyRender() {
      let html;
      if (ly.state === 'idle') html = '<div class="ly-msg">Play a song to see its lyrics.</div>';
      else if (ly.state === 'loading') html = '<div class="ly-msg"><span class="spin"></span></div>';
      else if (ly.instr && !ly.synced.length && !ly.plain) html = '<div class="ly-msg"><i class="fas fa-music"></i><br>Instrumental</div>';
      else if (ly.synced.length) html = ly.synced.map((l, i) => `<p class="ll" data-i="${i}" title="Jump to this line">${l.text ? esc(l.text) : '<span class="ly-dots">• • •</span>'}</p>`).join('');
      else if (ly.plain) html = ly.plain.split(/\r?\n/).map(l => `<p class="ll plain">${esc(l) || '&nbsp;'}</p>`).join('');
      else html = '<div class="ly-msg"><i class="fas fa-microphone-lines-slash"></i><br>No lyrics found for this song.</div>';
      const note = ly.state === 'done' && ly.synced.length ? '<div class="ly-src">Synced lyrics · LRCLIB</div>' : ly.state === 'done' && ly.plain ? '<div class="ly-src">Lyrics · LRCLIB (not time-synced)</div>' : '';
      lyBodies().forEach(b => { b.innerHTML = '<div class="ly-pad"></div>' + html + note + '<div class="ly-pad"></div>'; b.scrollTop = 0; });
      lyAct = -1; lyTick(true);
    }
    async function loadLyrics(t) {
      if (!t) { ly = { id: null, state: 'idle', synced: [], plain: '', instr: false }; return lyRender(); }
      if (ly.id === t.id) return;
      const id = t.id; ly = { id, state: 'loading', synced: [], plain: '', instr: false }; lyRender();
      let d = null;
      try { d = await api('/api/music/lyrics?' + new URLSearchParams({ title: t.title, artist: t.artist, album: t.album || '', sec: t.sec || '' })); } catch {}
      if (ly.id !== id) return;
      ly = { id, state: 'done', synced: (d && d.synced) || [], plain: (d && d.plain) || '', instr: !!(d && d.instrumental) };
      lyRender();
    }
    function lyTick(force) {
      const shown = lyBodies().filter(b => b.offsetParent);
      if (!shown.length) return;
      const c = cur();
      if (!lfDrag && !lf.classList.contains('hidden')) {
        const d = dur(); $('.lf-cur', lf).textContent = fmt(c); $('.lf-dur', lf).textContent = fmt(d);
        const p = d ? Math.min(1000, c / d * 1000) : 0; lfSeek.value = p; lfSeek.style.background = `linear-gradient(to right,#fff ${p / 10}%,rgba(255,255,255,.22) ${p / 10}%)`;
      }
      if (!ly.synced.length) return;
      let a = -1; const at = c + .15;
      for (let i = ly.synced.length - 1; i >= 0; i--) if (ly.synced[i].t <= at) { a = i; break; }
      const changed = a !== lyAct || force; lyAct = a;
      shown.forEach(b => {
        const pad = Math.round(b.clientHeight * .42) + 'px'; if (b.style.getPropertyValue('--pad') !== pad) { b.style.setProperty('--pad', pad); force = true; }
        const lines = b.querySelectorAll('.ll[data-i]');
        if (changed || force) lines.forEach((el, i) => { el.classList.toggle('on', i === a); el.classList.toggle('past', i < a); });
        if ((changed || force) && a >= 0 && Date.now() - (b._hold || 0) > 2500) {
          const el = lines[a]; if (el) b.scrollTo({ top: el.offsetTop - b.clientHeight / 2 + el.offsetHeight / 2, behavior: force && !changed ? 'auto' : 'smooth' });
        }
      });
    }
    const lyTimer = setInterval(lyTick, 120);
    lyBodies().forEach(b => { const hold = () => { b._hold = Date.now(); }; b.addEventListener('wheel', hold, { passive: true }); b.addEventListener('touchmove', hold, { passive: true }); });
    function seekTo(t) { if (kind === 'yt' && yt) yt.seekTo(t, true); else if (kind === 'audio') audio.currentTime = t; tick(); lyTick(); }
    root.addEventListener('click', e => { const p = e.target.closest('.ll[data-i]'); if (!p) return; const l = ly.synced[+p.dataset.i]; if (l) { lyBodies().forEach(b => (b._hold = 0)); seekTo(l.t); } });
    function showLyrics(on) {
      const c = $('.np-card', root); c.classList.toggle('ly', on); if (on) { c.classList.remove('q'); npEl.classList.remove('q'); }
      $('[data-n=lyrics]', root).classList.toggle('on', on); $('.lybtn', root).classList.toggle('on', on); lyTick(true);
    }
    function openLyFull(on = true) {
      lf.classList.toggle('hidden', !on);
      if (on) { paintLyHead(); lyRender(); } else if (document.fullscreenElement === lf) document.exitFullscreen().catch(() => {});
    }
    function toggleLyFs() {
      if (document.fullscreenElement === lf) document.exitFullscreen().catch(() => {});
      else if (lf.requestFullscreen) lf.requestFullscreen().catch(() => toast('Full screen not available', 'The lyrics still fill the whole player.'));
    }
    document.addEventListener('fullscreenchange', () => { $('[data-l=fs] i', lf).className = document.fullscreenElement === lf ? 'fas fa-compress' : 'fas fa-expand'; setTimeout(() => lyTick(true), 120); });
    lf.onclick = e => { const b = e.target.closest('[data-l]'); if (!b) return; if (b.dataset.l === 'close') openLyFull(false); else toggleLyFs(); };
    lfSeek.oninput = e => { lfDrag = true; const t = dur() * e.target.value / 1000; $('.lf-cur', lf).textContent = fmt(t); };
    lfSeek.onchange = e => { seekTo(dur() * e.target.value / 1000); lfDrag = false; };
    $('.lybtn', root).onclick = () => { const c = $('.np-card', root), open = !npEl.classList.contains('hidden') && c.classList.contains('ly'); if (open) closeNow(); else { openNow(); showLyrics(true); } };

    /* ---- Now Playing screen ---- */
    function paintQueue() {
      const l = $('.np-ql', root); l.innerHTML = '';
      queue.forEach((t, i) => l.append(trackRow(t, queue, i, { art: true, artist: true, onPick: k => play(queue, k) })));
      updateLikes(); markPlaying();
      const c = $('.trk.sel', l); if (c) c.scrollIntoView({ block: 'nearest' });
    }
    function openNow() { npEl.classList.remove('hidden'); $('.np-menu', root).classList.add('hidden'); setTimeout(() => lyTick(true), 60); }
    function closeNow() { npEl.classList.add('hidden'); npEl.classList.remove('q'); $('.np-card', root).classList.remove('q'); }
    $('.tn-now img', root).onclick = $('.tn-now > div', root).onclick = $('.expand', root).onclick = openNow;
    npEl.onclick = e => {
      const n = e.target.closest('[data-n]'), menu = $('.np-menu', root);
      if (!n) { if (!e.target.closest('.np-menu')) menu.classList.add('hidden'); return; }
      const t = queue[idx], act = n.dataset.n;
      if (act !== 'menu') menu.classList.add('hidden');
      if (act === 'close') closeNow();
      else if (act === 'menu') menu.classList.toggle('hidden');
      else if (act === 'like') toggleLike(t);
      else if (act === 'video') $('.vtog', root).click();
      else if (act === 'artist' && t) { closeNow(); openArtist(t); }
      else if (act === 'album' && t) { if (t.albumId) { closeNow(); openAlbum(t.albumId); } else toast('Album unknown', 'This song was saved before album info was kept.'); }
      else if (act === 'queue') { const q = $('.np-card', root).classList.toggle('q'); npEl.classList.toggle('q', q); if (q) { paintQueue(); showLyrics(false); } }
      else if (act === 'lyrics') showLyrics(!$('.np-card', root).classList.contains('ly'));
      else if (act === 'lyfull') openLyFull(true);
    };

    /* ---- controls (bar and Now Playing share them) ---- */
    const paintRepeat = () => $$('[data-c=repeat]', root).forEach(b => { b.classList.toggle('on', repeat > 0); $('.rb', b).textContent = repeat === 2 ? '1' : ''; b.title = ['Repeat: off', 'Repeat: all songs', 'Repeat: this song'][repeat]; });
    const paintShuffle = () => $$('[data-c=shuffle]', root).forEach(b => { b.classList.toggle('on', shuffle); b.title = 'Shuffle: ' + (shuffle ? 'on' : 'off'); });
    function setShuffle(v) { shuffle = v; seen = new Set(idx >= 0 ? [idx] : []); hist = []; LS.set('shuffle', shuffle); paintShuffle(); }
    const act = {
      play() {
        if (!queue[idx]) return queue[0] ? play(queue, 0) : null;
        if (kind === 'yt') (playing() ? yt.pauseVideo() : yt.playVideo());
        else if (kind === 'audio') (audio.paused ? audio.play() : audio.pause());
        else play(queue, idx);
      },
      next: () => skip(1),
      prev: () => (cur() > 3 ? (kind === 'yt' ? yt.seekTo(0, true) : (audio.currentTime = 0)) : skip(-1)),
      repeat() { repeat = (repeat + 1) % 3; LS.set('repeat', repeat); paintRepeat(); },
      shuffle: () => setShuffle(!shuffle),
    };
    root.addEventListener('click', e => { const b = e.target.closest('[data-c]'); if (b && act[b.dataset.c]) act[b.dataset.c](); });
    $('.tn-now .heart', root).onclick = () => toggleLike(queue[idx]);
    const onSeekIn = e => { seeking = true; const t = dur() * e.target.value / 1000; $('.cur', root).textContent = $('.ncur', root).textContent = fmt(t); $('.nrem', root).textContent = '-' + fmt(Math.max(0, dur() - t)); };
    const onSeekCh = e => { const t = dur() * e.target.value / 1000; if (kind === 'yt') yt.seekTo(t, true); else if (kind === 'audio') audio.currentTime = t; seeking = false; tick(); };
    seek.oninput = nps.oninput = onSeekIn; seek.onchange = nps.onchange = onSeekCh;
    const volIn = $('.tn-vol input', root), muteB = $('.mute', root); let preMute = vol || 80;
    function setVol(v, keep = true) {
      vol = Math.max(0, Math.min(100, Math.round(v))); audio.volume = vol / 100; try { yt && yt.setVolume && yt.setVolume(vol); } catch {}
      volIn.value = vol; volIn.style.background = `linear-gradient(to right,#1db954 ${vol}%,#4d4d4d ${vol}%)`;
      $('i', muteB).className = 'fas ' + (vol === 0 ? 'fa-volume-xmark' : vol < 40 ? 'fa-volume-low' : 'fa-volume-high');
      muteB.title = vol === 0 ? 'Unmute (M)' : 'Mute (M)'; if (keep) LS.set('vol', vol);
    }
    volIn.oninput = e => { setVol(+e.target.value); if (vol) preMute = vol; };
    muteB.onclick = () => (vol ? (preMute = vol, setVol(0, false)) : setVol(preMute || 80));
    setVol(vol, false);
    const seekBy = d => { const t = Math.max(0, Math.min(dur(), cur() + d)); if (kind === 'yt') yt.seekTo(t, true); else if (kind === 'audio') audio.currentTime = t; tick(); };
    root.tabIndex = -1;
    root.addEventListener('keydown', e => {
      if (e.key === 'Escape' && !lf.classList.contains('hidden')) return openLyFull(false);
      if (e.key === 'Escape' && !npEl.classList.contains('hidden')) return closeNow();
      const tg = e.target; if (!tg || !tg.matches || tg.matches('input:not([type=range]),textarea') || e.ctrlKey || e.metaKey || e.altKey) return;
      if (e.key === ' ' && !tg.closest('button,input')) { e.preventDefault(); act.play(); }
      else if (e.key === 'ArrowRight' && tg.type !== 'range') { e.preventDefault(); seekBy(5); }
      else if (e.key === 'ArrowLeft' && tg.type !== 'range') { e.preventDefault(); seekBy(-5); }
      else if (e.key.toLowerCase() === 'm') muteB.click();
    });
    function paintRecent() {
      const list = LS.get('recent', []).slice(0, 6), box = $('.tn-recent', root); box.innerHTML = list.length ? '<h5>Recently played</h5>' : '';
      list.forEach((t, i) => { const d = document.createElement('div'); d.className = 'rc'; d.title = t.title + ' · ' + t.artist; d.innerHTML = `<img loading="lazy" src="${esc(t.art)}" alt=""><div><strong>${esc(t.title)}</strong><small>${esc(t.artist)}</small></div>`; d.onclick = () => play(list, i); box.append(d); });
    }
    const ro = window.ResizeObserver ? new ResizeObserver(() => root.classList.toggle('compact', root.clientWidth > 0 && root.clientWidth < 900)) : null; ro && ro.observe(root);
    $('.vtog', root).onclick = e => { const on = $('.tn-video', root).classList.toggle('show'); e.currentTarget.classList.toggle('on', on); };
    audio.onplay = audio.onpause = paintPlay; audio.onended = ended;

    w.onclose = () => { ro && ro.disconnect(); clearInterval(timer); clearInterval(lyTimer); try { document.fullscreenElement === lf && document.exitFullscreen(); } catch {}; token++; audio.pause(); audio.removeAttribute('src'); try { yt && yt.destroy && yt.destroy(); } catch {} };
    function searchFor(q) {
      closeNow(); openLyFull(false);
      $$('.tn-card [data-v]', root).forEach(a => a.classList.toggle('on', a.dataset.v === 'search'));
      stack = []; curView = () => search(q, true); vtok++; content.scrollTop = 0; curView();
    }
    w.opts = o => {
      const t = LS.get('lastTrack'); if (o && o.resume && t) { if (!queue.length) play([t], 0); else if (!playing()) act.play(); }
      if (o && o.q) searchFor(String(o.q));
      if (o && o.lyrics) { openNow(); showLyrics(true); if (o.lyrics === 'full') openLyFull(true); }
    };
    // controls used by the mini player (bottom right)
    w.ctl = {
      state: () => { const t = queue[idx]; return t ? { title: t.title, artist: t.artist, art: t.art, playing: playing(), p: dur() ? cur() / dur() : 0, cur: cur(), dur: dur() } : null; },
      lyrics: full => { openNow(); showLyrics(true); if (full) openLyFull(true); },
      toggle: () => act.play(),
      next: () => skip(1),
      prev: () => act.prev(),
    };
    paintRepeat(); paintShuffle(); paintRecent(); updateLikes(); curView = home; home(); w.opts(o);
  },
});

/* ============================================================
   CINEFLIX  (Netflix slot) - this is the real https://www.movy.sx/ site, not something we build.
   Desktop app: runs inside the OS in its own saved browser profile (sign-ins stick), ad popups are dropped,
   and it follows the Cine-Web proxy setting. Plain browser: opens movy.sx in a new tab.
   ============================================================ */
const MOVY_URL = 'https://www.movy.sx/';
registerApp({
  id: 'flix', name: 'CineFlix', icon: 'fa-film', img: 'icons/netflix.png', bg: 'transparent', pinned: false, store: true,
  mount(root, w) {
    root.classList.add('nf', 'nfw');
    const desktop = !!window.cine;
    root.innerHTML = `<div class="nfw-bar app-head"><img src="icons/netflix.png" alt=""><strong>movy.sx</strong>
        <button data-a="back" title="Back"><i class="fas fa-arrow-left"></i></button>
        <button data-a="fwd" title="Forward"><i class="fas fa-arrow-right"></i></button>
        <button data-a="reload" title="Reload"><i class="fas fa-rotate-right"></i></button>
        <button data-a="home" title="Home"><i class="fas fa-house"></i></button></div><div class="nfw-view"></div>`;
    const view = $('.nfw-view', root);
    let el = null, off = null;
    const safe = fn => { try { fn(); } catch {} };
    const sameSite = u => { try { return /(^|\.)movy\.sx$/i.test(new URL(u).hostname); } catch { return false; } };
    if (desktop) {
      window.cine.setProxy(LS.get('proxy', '')).catch(() => {});
      el = document.createElement('webview');
      el.setAttribute('src', MOVY_URL); el.setAttribute('partition', 'persist:movy'); el.setAttribute('allowpopups', '');
      let wcid = null; el.addEventListener('dom-ready', () => safe(() => { wcid = el.getWebContentsId(); }));
      view.append(el);
      // popups: movy.sx's own links load in the same view, everything else (ads) is dropped
      off = window.cine.onOpenUrl(({ from, url }) => { if (from === wcid && sameSite(url)) safe(() => el.loadURL(url)); });
    } else {
      view.innerHTML = `<div class="nfw-land"><img src="icons/netflix.png" alt=""><h1>CineFlix</h1>
        <p>CineFlix is the real movy.sx site. Open it in a new tab, or use the desktop app (<code>npm start</code>) to watch it right inside the OS.</p>
        <button class="btn" data-a="tab"><i class="fas fa-up-right-from-square"></i> Open movy.sx</button></div>`;
    }
    root.addEventListener('click', e => {
      const b = e.target.closest('[data-a]'); if (!b) return;
      const a = b.dataset.a;
      if (a === 'tab') window.open(MOVY_URL, '_blank', 'noopener');
      if (!el) return;
      if (a === 'back') safe(() => el.goBack());
      if (a === 'fwd') safe(() => el.goForward());
      if (a === 'reload') safe(() => el.reload());
      if (a === 'home') safe(() => el.loadURL(MOVY_URL));
    });
    if (!desktop) $$('.nfw-bar button', root).forEach(x => x.classList.add('hidden'));
    w.onclose = () => off && off();
  },
});

/* ============================================================
   CINE-PLAY  (game console style launcher + original games)
   ============================================================ */
registerApp({
  id: 'play', name: 'Cine-Play', icon: 'fa-gamepad', img: 'icons/playstation.png', bg: 'transparent', pinned: true, onOpen,
  mount(root, w, o) {
    root.classList.add('cp');
    let tab = 'home', owned = LS.get('owned', []), q = '', genre = 'All', stopGame = null;
    const TABS = [['home', 'Home', 'fa-house'], ['library', 'Library', 'fa-layer-group'], ['store', 'Play Store', 'fa-store'], ['search', 'Search', 'fa-magnifying-glass']];
    const has = id => owned.includes(id);
    const save = () => LS.set('owned', owned);
    const byId = id => GAMES.find(g => g.id === id);
    const gcard = (g, lib) => `<div class="gcard${has(g.id) ? ' own' : ''}" data-g="${g.id}"><div class="gt">${gameArt(g)}<span class="gtag">${esc(g.tag)}</span>${has(g.id) ? '<span class="gown" title="In your library"><i class="fas fa-check"></i></span>' : ''}<div class="gplay"><i class="fas fa-${has(g.id) ? 'play' : 'plus'}"></i></div>${lib ? `<button class="grm" data-a="remove" data-g="${g.id}" title="Remove from library"><i class="fas fa-xmark"></i></button>` : ''}</div><div class="gi"><div><strong>${esc(g.name)}</strong><small>${esc(g.tag)}</small></div><button class="btn get" data-a="${has(g.id) ? 'play' : 'get'}" data-g="${g.id}">${has(g.id) ? 'PLAY' : 'GET'}</button></div></div>`;
    const empty = (icon, title, text, btn) => `<div class="cp-empty"><i class="fas ${icon}"></i><strong>${title}</strong><p>${text}</p>${btn ? `<button class="btn" data-t="${btn[0]}">${btn[1]}</button>` : ''}</div>`;
    const chips = list => { const tags = ['All', ...new Set(list.map(g => g.tag))]; if (!tags.includes(genre)) genre = 'All'; return `<div class="cp-chips">${tags.map(t => `<button class="cp-chip${t === genre ? ' on' : ''}" data-genre="${esc(t)}">${esc(t)}</button>`).join('')}</div>`; };
    const filt = list => list.filter(g => genre === 'All' || g.tag === genre);

    function play(id) {
      const g = byId(id); if (!g) return;
      if (!has(id)) { owned.push(id); save(); }
      LS.set('lastGame', { id: g.id, name: g.name }); bus.dispatchEvent(new Event('sidebar'));
      stopGame && stopGame();
      const ov = document.createElement('div'); ov.className = 'cp-frame';
      ov.innerHTML = `<iframe src="${esc(g.file)}" title="${esc(g.name)}" allow="autoplay; fullscreen; gamepad; clipboard-write; cross-origin-isolated" allowfullscreen></iframe><button class="cp-exit" title="Exit game"><i class="fas fa-chevron-left"></i> <img src="${esc(g.ico)}" alt=""> ${esc(g.name)}</button>`;
      document.body.append(ov); // on <body> so it sits above the taskbar
      const f = $('iframe', ov); f.addEventListener('load', () => { try { f.contentWindow.focus(); } catch {} });
      const onKey = e => { if (e.key === 'Escape') stopGame && stopGame(); };
      addEventListener('keydown', onKey);
      stopGame = () => { removeEventListener('keydown', onKey); ov.remove(); stopGame = null; render(); };
      $('.cp-exit', ov).onclick = () => stopGame();
    }

    function hero(g, label) {
      return `<div class="cp-feat">${gameArt(g, 'hero')}<img class="cp-feat-ico" src="${g.ico}" alt=""><small>${label}</small><h1>${esc(g.name)}</h1><p>${esc(g.tag)}</p><div class="cp-feat-btns"><button class="btn" data-a="${has(g.id) ? 'play' : 'get'}" data-g="${g.id}">${has(g.id) ? '<i class="fas fa-play"></i> PLAY' : '<i class="fas fa-plus"></i> GET'}</button></div></div>`;
    }
    function body() {
      const mine = GAMES.filter(g => has(g.id)), rest = GAMES.filter(g => !has(g.id));
      if (tab === 'home') {
        const last = LS.get('lastGame'), lg = last && byId(last.id);
        const daily = GAMES[Math.floor(Date.now() / 86400000) % GAMES.length];
        return `<div class="cp-hero1">${lg && has(lg.id) ? hero(lg, 'CONTINUE PLAYING') : hero(daily, 'FEATURED TODAY')}</div>
          <h2>Your Games <span class="cnt">${mine.length}</span></h2>${mine.length ? `<div class="cp-row">${mine.map(g => gcard(g)).join('')}</div>` : empty('fa-gamepad', 'Nothing here yet', 'Grab a game from the Play Store and it shows up here.', ['store', 'Open Play Store'])}
          ${rest.length ? `<h2>Try Something New</h2><div class="cp-row">${rest.map(g => gcard(g)).join('')}</div>` : ''}`;
      }
      if (tab === 'library') {
        const list = filt(mine);
        return `<h2>Game Library <span class="cnt">${mine.length}</span></h2>${mine.length ? chips(mine) : ''}${list.length ? `<div class="cp-grid">${list.map(g => gcard(g, true)).join('')}</div>` : mine.length ? '' : empty('fa-layer-group', 'Your library is empty', 'Games you get from the Play Store live here.', ['store', 'Browse games'])}`;
      }
      if (tab === 'store') {
        const f = GAMES[Math.floor(Date.now() / 86400000) % GAMES.length], list = filt(GAMES);
        return `<div class="cp-hero">${hero(f, 'FEATURED TITLE')}<div class="cp-rand" data-a="rand"><h3><i class="fas fa-dice"></i> Random Game</h3><p>${rest.length ? 'Can’t decide? Click to instantly grab a game.' : 'You own everything. Click to play a random one.'}</p></div></div>
          <h2>All Games</h2>${chips(GAMES)}<div class="cp-grid">${list.map(g => gcard(g)).join('')}</div>`;
      }
      return `<div class="cp-sbox"><i class="fas fa-magnifying-glass"></i><input class="cp-search" placeholder="Search games or genres…" value="${esc(q)}" autocomplete="off" spellcheck="false"><button class="cp-sx${q ? '' : ' hidden'}" title="Clear"><i class="fas fa-xmark"></i></button></div><div class="cp-sres"></div>`;
    }
    function results() {
      const k = q.trim().toLowerCase(), r = GAMES.filter(g => !k || g.name.toLowerCase().includes(k) || g.tag.toLowerCase().includes(k));
      $('.cp-sres', root).innerHTML = r.length ? `<div class="cp-grid">${r.map(g => gcard(g)).join('')}</div>` : empty('fa-ghost', 'No matches', `Nothing found for “${esc(q)}”.`);
      $('.cp-sx', root).classList.toggle('hidden', !q);
    }
    function render() {
      owned = owned.filter(id => byId(id));
      const nav = TABS.map(([t, n, ic]) => `<a data-t="${t}" class="${tab === t ? 'on' : ''}"><i class="fas ${ic}"></i>${n}${t === 'library' && owned.length ? `<b>${owned.length}</b>` : ''}</a>`).join('');
      root.querySelector('.cp-main') || root.insertAdjacentHTML('beforeend', '<div class="cp-main"></div>');
      const main = $('.cp-main', root), keep = main.scrollTop;
      main.innerHTML = `<nav class="cp-nav app-head">${nav}<span class="sp"></span></nav><div class="cp-body">${body()}</div>`;
      main.scrollTop = keep;
      if (tab === 'search') {
        const s = $('.cp-search', root); results();
        s.oninput = e => { q = e.target.value; results(); };
        s.onkeydown = e => { if (e.key === 'Escape' && q) { q = ''; s.value = ''; results(); e.stopPropagation(); } };
        $('.cp-sx', root).onclick = () => { q = ''; s.value = ''; results(); s.focus(); };
        s.focus();
      }
    }
    root.addEventListener('click', e => {
      const t = e.target.closest('[data-t]'); if (t) { tab = t.dataset.t; genre = 'All'; $('.cp-main', root).scrollTop = 0; return render(); }
      const ch = e.target.closest('[data-genre]'); if (ch) { genre = ch.dataset.genre; return render(); }
      const a = e.target.closest('[data-a]');
      if (a) {
        const id = a.dataset.g, act = a.dataset.a;
        if (act === 'rand') {
          const pool = GAMES.filter(g => !has(g.id)), list = pool.length ? pool : GAMES, g = list[rand(list.length)];
          if (!has(g.id)) { owned.push(g.id); save(); toast('Got ' + g.name, 'Added to your library.'); return render(); }
          return play(g.id);
        }
        if (act === 'get') { owned.push(id); save(); toast('Added to library', byId(id).name); return render(); }
        if (act === 'remove') { owned = owned.filter(x => x !== id); save(); toast('Removed', byId(id).name + ' is no longer in your library.'); return render(); }
        if (act === 'play') return play(id);
      }
      const c = e.target.closest('.gcard'); if (c) { const id = c.dataset.g; if (has(id)) play(id); else { owned.push(id); save(); toast('Added to library', byId(id).name); render(); } }
    });
    w.onclose = () => stopGame && stopGame();
    w.opts = o => o && o.game && play(o.game);
    // splash -> (first time only) input select -> main. Click or press a key to skip.
    const splash = document.createElement('div'); splash.className = 'cp-splash';
    splash.innerHTML = '<h1><i class="fas fa-gamepad"></i>Cine-Play</h1><div class="ln"></div>'; root.append(splash);
    let done = false;
    const finish = () => { if (done) return; done = true; clearTimeout(t1); splash.classList.add('out'); setTimeout(() => splash.remove(), 280); render(); w.opts(o); };
    const pick = () => {
      if (LS.get('inputMode')) return finish();
      splash.className = 'cp-input';
      splash.innerHTML = '<h2>Select Input Method</h2><div class="opts"><div class="opt" data-m="keys"><i class="fas fa-gamepad"></i>Controller / Keys</div><div class="opt" data-m="mouse"><i class="fas fa-arrow-pointer"></i>Mouse</div></div>';
      splash.onclick = e => { const m = e.target.closest('[data-m]'); if (!m) return; LS.set('inputMode', m.dataset.m); finish(); };
    };
    const t1 = setTimeout(pick, 900);
    splash.onclick = () => { clearTimeout(t1); pick(); };
  },
});
