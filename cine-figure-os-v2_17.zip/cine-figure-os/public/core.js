// Cine/Figure OS - shared helpers
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const LS = {
  get(k, d) { try { const v = localStorage.getItem('cine.' + k); return v === null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem('cine.' + k, JSON.stringify(v)); return true; } catch { return false; } },
};
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const api = async p => { const r = await fetch(p); return r.json(); };
const APPS = [];
const iconHTML = (a, style = '') => a.img ? `<img src="${a.img}" alt="" draggable="false">` : `<i class="fas ${a.icon}"${style}></i>`;
const registerApp = a => APPS.push(a);
const bus = new EventTarget();

const settings = Object.assign(
  { fastBoot: false, loadScreen: true, optBg: false, idleLock: false, panicKey: '`', panicUrl: 'https://www.wikipedia.org', tabTitle: '' },
  LS.get('settings', {})
);
function saveSettings() { LS.set('settings', settings); applySettings(); }

function toast(title, body, ms = 5000) {
  const t = document.createElement('div');
  t.className = 'toast';
  t.innerHTML = `<b>System</b><strong>${esc(title)}</strong><small>${esc(body || '')}</small>`;
  t.style.setProperty('--ms', ms + 'ms');
  const bye = () => { if (t.classList.contains('out')) return; t.classList.add('out'); setTimeout(() => t.remove(), 300); };
  t.onclick = bye;
  $('#toasts').append(t);
  setTimeout(bye, ms);
}

// Apps flagged `store: true` must be installed from the App Store before they show up or open.
const installedList = () => LS.get('installed', []);
const isInstalled = a => !a.store || installedList().includes(a.id);
function installApp(id) { const l = installedList(); if (!l.includes(id)) { l.push(id); LS.set('installed', l); } }
function uninstallApp(id) { LS.set('installed', installedList().filter(x => x !== id)); }

/* ---------- profile (shown top right; edited in profile.js) ---------- */
const PROFILE_DEF = { name: 'Administrator', handle: 'admin', bio: '', status: 'online', avatar: null, avatarColor: '#5865f2', banner: { type: 'color', color: '#5865f2', image: null, pos: 50 }, since: 0 };
let _profile = null;
function getProfile() {
  if (_profile) return _profile;
  const p = LS.get('profile', null) || {};
  _profile = Object.assign({}, PROFILE_DEF, p, { banner: Object.assign({}, PROFILE_DEF.banner, p.banner || {}) });
  if (!_profile.since) { _profile.since = Date.now(); LS.set('profile', _profile); }
  return _profile;
}
// returns false when the browser has no storage left (big images), so the editor can warn instead of losing the change
function saveProfile(p) {
  if (!LS.set('profile', p)) return false;
  _profile = p; bus.dispatchEvent(new Event('profile')); return true;
}

// No select-all highlight: only text fields, chat text and the terminal keep selection (CSS does the rest)
const SELECTABLE = 'input,textarea,[contenteditable="true"],.ms-t,.tm-out';
addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'a' && !(e.target.closest && e.target.closest(SELECTABLE))) e.preventDefault(); }, true);
addEventListener('selectstart', e => { const t = e.target.nodeType === 1 ? e.target : e.target.parentElement; if (t && !t.closest(SELECTABLE)) e.preventDefault(); }, true);
