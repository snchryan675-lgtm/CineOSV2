// Cine-Play game catalog: each game is a standalone HTML file in public/games/
//   img = cover art, ico = square icon (both in public/icons/games/)
//   fit = how the cover art sits in a card: 'cover' (portrait/square art) or 'contain' (wide logo art on a blurred backdrop)
const rand = n => Math.floor(Math.random() * n);
const mkGame = (id, name, tag, c, file, fit, pos = '50% 12%') => ({ id, name, tag, c, file, fit, pos, img: `icons/games/${id}.webp`, ico: `icons/games/${id}-icon.png` });
const GAMES = [
  mkGame('mantle', 'Mantle', 'Games Hub', ['#3a3a44', '#09090b'], 'games/mantle.html', 'contain'),
  mkGame('skate3', 'skate. 3', 'Sports', ['#ff9f43', '#1f1f2e'], 'games/skate-3.html', 'cover'),
  mkGame('stardew', 'Stardew Valley', 'Farming', ['#7bd88f', '#1d5c3a'], 'games/stardew-valley.html', 'cover'),
  mkGame('deltarune', 'DELTARUNE', 'RPG', ['#9b5de5', '#0b0b2a'], 'games/deltarune.html', 'contain'),
  mkGame('gd', 'Geometry Dash', 'Platformer', ['#00d4ff', '#1a2a8a'], 'games/geometry-dash-webport.html', 'cover', '50% 0%'),
  mkGame('hlm2', 'Hotline Miami 2', 'Action', ['#ec327f', '#2a0a3a'], 'games/hotline-miami-2.html', 'contain'),
  mkGame('fish', 'How to Fish', 'Casual', ['#4dc3ff', '#0a2a5a'], 'games/how-to-fish.html', 'cover', '50% 0%'),
  mkGame('solar', 'Solar Smash', 'Sandbox', ['#ff6b4d', '#0a0a1e'], 'games/solar-smash.html', 'contain'),
  mkGame('sonic', 'Sonic Mania', 'Platformer', ['#2d7dff', '#0a1a4a'], 'games/sonic-mania.html', 'contain'),
  mkGame('coming', 'They Are Coming', 'Shooter', ['#8bc34a', '#1a2a0a'], 'games/theyre-coming.html', 'contain'),
  mkGame('gamble', 'Gamble With Your Friends', 'Party', ['#b600ff', '#08070b'], 'games/gamble-with-your-friends.html', 'contain'),
  mkGame('peak', 'PEAK', 'Co-op Climbing', ['#8e5cf0', '#2a1458'], 'games/peak.html', 'cover', '50% 0%'),
  mkGame('amongus', 'Among Us', 'Party', ['#c51111', '#0b0b24'], 'games/among-us.html', 'cover', '50% 0%'),
  mkGame('gangbeasts', 'Gang Beasts', 'Party', ['#ffd34d', '#c0392b'], 'games/gangbeasts.html', 'cover', '50% 0%'),
];
// <div class="gart"> block used by every game card / hero: blurred backdrop + the real cover art
const gameArt = (g, cls = '') => `<div class="gart ${g.fit} ${cls}" style="--g1:${g.c[0]};--g2:${g.c[1]};--pos:${g.pos}"><i style="background-image:url('${g.img}')"></i><img src="${g.img}" alt="${g.name}" draggable="false" loading="lazy"></div>`;
