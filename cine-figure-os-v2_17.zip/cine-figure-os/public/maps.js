// Cine-Maps: our own map app built on open data (OpenStreetMap tiles + Nominatim search + OSRM routing + Overpass places).
// No Google anything. Needs the Leaflet library (loaded in index.html) and the server's /api/geo/* routes.
registerApp({
  id: 'maps', name: 'Cine-Maps', icon: 'fa-map-location-dot', bg: 'linear-gradient(135deg,#12b886,#1c7ed6)', pinned: false, store: true, onOpen,
  mount(root, w, o) {
    root.classList.add('mp');
    const CATS = [['restaurants', 'Restaurants', 'fa-utensils'], ['cafes', 'Cafés', 'fa-mug-hot'], ['gas', 'Gas', 'fa-gas-pump'], ['charging', 'EV charging', 'fa-charging-station'],
      ['groceries', 'Groceries', 'fa-cart-shopping'], ['pharmacy', 'Pharmacy', 'fa-prescription-bottle-medical'], ['hospitals', 'Hospitals', 'fa-hospital'], ['atm', 'ATMs & banks', 'fa-building-columns'],
      ['hotels', 'Hotels', 'fa-bed'], ['parks', 'Parks', 'fa-tree'], ['parking', 'Parking', 'fa-square-parking'], ['transit', 'Transit', 'fa-bus']];
    const LAYERS = {
      street: { name: 'Street', url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', att: '© OpenStreetMap contributors', max: 19, sw: '#e8e0d0' },
      light: { name: 'Light', url: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', att: '© OpenStreetMap contributors © CARTO', sub: 'abcd', max: 20, sw: '#f1ece4' },
      dark: { name: 'Dark', url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', att: '© OpenStreetMap contributors © CARTO', sub: 'abcd', max: 20, sw: '#222831' },
      sat: { name: 'Satellite', url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', att: 'Tiles © Esri — Maxar, Earthstar Geographics', max: 19, sw: '#2d4a2f',
        labels: 'https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}' },
      terrain: { name: 'Terrain', url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', att: '© OpenStreetMap contributors, SRTM · © OpenTopoMap (CC-BY-SA)', sub: 'abc', max: 17, sw: '#c9d8b6' },
    };
    root.innerHTML = `
      <aside class="mp-side">
        <div class="mp-tabs"><button data-t="explore" class="on"><i class="fas fa-compass"></i> Explore</button><button data-t="route"><i class="fas fa-route"></i> Directions</button><button data-t="saved"><i class="fas fa-bookmark"></i> Saved</button></div>
        <div class="mp-pane" data-p="explore">
          <form class="mp-search"><i class="fas fa-search"></i><input placeholder="Search places or addresses" autocomplete="off"></form>
          <div class="mp-chips">${CATS.map(c => `<button data-cat="${c[0]}"><i class="fas ${c[2]}"></i> ${c[1]}</button>`).join('')}</div>
          <div class="mp-card hidden"></div>
          <div class="mp-list"></div>
        </div>
        <div class="mp-pane hidden" data-p="route">
          <div class="mp-ft"><div class="mp-fields">
            <div class="mp-f"><i class="fas fa-circle-dot"></i><input class="rf" placeholder="Start (or “my location”)" autocomplete="off"><button class="rme" title="Use my location"><i class="fas fa-crosshairs"></i></button></div>
            <div class="mp-f"><i class="fas fa-location-dot" style="color:#ff4d5e"></i><input class="rt" placeholder="Destination" autocomplete="off"></div></div>
            <button class="rswap" title="Swap"><i class="fas fa-arrow-right-arrow-left fa-rotate-90"></i></button></div>
          <div class="mp-modes"><button data-m="driving" class="on"><i class="fas fa-car"></i> Drive</button><button data-m="walking"><i class="fas fa-person-walking"></i> Walk</button><button data-m="cycling"><i class="fas fa-bicycle"></i> Bike</button></div>
          <button class="btn mp-go"><i class="fas fa-route"></i> Get directions</button>
          <div class="mp-sum hidden"></div><ol class="mp-steps"></ol>
        </div>
        <div class="mp-pane hidden" data-p="saved"><div class="mp-list"></div></div>
      </aside>
      <div class="mp-map"><div class="mp-canvas"></div>
        <div class="mp-tools">
          <div class="mp-lay hidden">${Object.entries(LAYERS).map(([k, l]) => `<button data-k="${k}"><span style="background:${l.sw}"></span>${l.name}</button>`).join('')}</div>
          <button data-tool="layers" title="Map style"><i class="fas fa-layer-group"></i></button>
          <button data-tool="locate" title="My location"><i class="fas fa-crosshairs"></i></button>
          <button data-tool="measure" title="Measure distance"><i class="fas fa-ruler"></i></button>
          <button data-tool="units" title="Units" class="u"></button>
        </div>
        <div class="mp-badge hidden"></div><div class="mp-coords"></div></div>`;
    const canvas = $('.mp-canvas', root);
    if (!window.L) { canvas.innerHTML = '<div class="err" style="padding-top:25vh">The map engine (Leaflet) couldn’t load.<br>Check your internet connection, then reopen Cine-Maps.</div>'; return; }

    /* ---------- map ---------- */
    const view = LS.get('mapView', { c: [25, 10], z: 2 });
    const map = L.map(canvas, { zoomControl: false, worldCopyJump: true, minZoom: 2 }).setView(view.c, view.z);
    L.control.zoom({ position: 'bottomright' }).addTo(map);
    L.control.scale({ position: 'bottomleft' }).addTo(map);
    let base = null, labels = null;
    function setLayer(k) {
      if (!LAYERS[k]) k = 'dark'; LS.set('mapLayer', k);
      base && map.removeLayer(base); labels && map.removeLayer(labels); labels = null;
      const l = LAYERS[k];
      base = L.tileLayer(l.url, { attribution: l.att, maxZoom: l.max, subdomains: l.sub || 'abc' }).addTo(map);
      if (l.labels) labels = L.tileLayer(l.labels, { maxZoom: l.max }).addTo(map);
      $$('.mp-lay [data-k]', root).forEach(b => b.classList.toggle('on', b.dataset.k === k));
    }
    const ro = new ResizeObserver(() => map.invalidateSize()); ro.observe(canvas);
    map.on('moveend', () => { const c = map.getCenter(); LS.set('mapView', { c: [c.lat, c.lng], z: map.getZoom() }); });
    map.on('mousemove', e => { $('.mp-coords', root).textContent = `${e.latlng.lat.toFixed(5)}, ${e.latlng.lng.toFixed(5)} · z${map.getZoom()}`; });

    const pin = cls => L.divIcon({ className: 'mp-pin ' + cls, html: '<i class="fas fa-location-dot"></i>', iconSize: [32, 40], iconAnchor: [16, 38], popupAnchor: [0, -34] });
    const dot = ic => L.divIcon({ className: 'mp-dot', html: `<i class="fas ${ic}"></i>`, iconSize: [26, 26], iconAnchor: [13, 13] });
    const letter = (t, c) => L.divIcon({ className: 'mp-let', html: `<b style="background:${c}">${t}</b>`, iconSize: [26, 26], iconAnchor: [13, 13] });
    const savedLayer = L.layerGroup().addTo(map), nearLayer = L.layerGroup().addTo(map), routeLayer = L.layerGroup().addTo(map), measureLayer = L.layerGroup().addTo(map);

    /* ---------- units / formatting ---------- */
    let miles = LS.get('mapMiles', /^en-US/i.test(navigator.language || ''));
    const fmtDist = m => miles ? (m < 160 ? `${Math.round(m * 3.281)} ft` : `${(m / 1609.34).toFixed(m < 16093 ? 1 : 0)} mi`) : (m < 1000 ? `${Math.round(m)} m` : `${(m / 1000).toFixed(m < 10000 ? 1 : 0)} km`);
    const fmtTime = s => { const m = Math.max(1, Math.round(s / 60)); return m < 60 ? `${m} min` : `${Math.floor(m / 60)} h ${m % 60 ? (m % 60) + ' min' : ''}`.trim(); };
    const paintUnits = () => { $('[data-tool=units]', root).textContent = miles ? 'mi' : 'km'; };

    /* ---------- tabs ---------- */
    function tab(t) { $$('.mp-tabs button', root).forEach(b => b.classList.toggle('on', b.dataset.t === t)); $$('.mp-pane', root).forEach(p => p.classList.toggle('hidden', p.dataset.p !== t)); if (t === 'saved') drawSavedList(); }
    $$('.mp-tabs button', root).forEach(b => b.onclick = () => tab(b.dataset.t));
    const fail = (msg) => toast('Cine-Maps', msg);

    /* ---------- places ---------- */
    let saved = LS.get('mapSaved', []), sel = null, selMarker = null, me = null, meLayer = null;
    const same = (a, b) => Math.abs(a.lat - b.lat) < 1e-6 && Math.abs(a.lon - b.lon) < 1e-6;
    const isSaved = p => saved.some(s => same(s, p));
    const link = p => `https://www.openstreetmap.org/?mlat=${p.lat}&mlon=${p.lon}#map=17/${p.lat}/${p.lon}`;
    function drawSavedMarkers() {
      savedLayer.clearLayers();
      saved.forEach(p => L.marker([p.lat, p.lon], { icon: dot('fa-star'), title: p.name }).on('click', () => showPlace(p, false)).addTo(savedLayer));
    }
    function drawSavedList() {
      const l = $('[data-p=saved] .mp-list', root);
      l.innerHTML = saved.length ? saved.map((p, i) => `<div class="mp-item" data-i="${i}"><i class="fas fa-star"></i><div><strong>${esc(p.name)}</strong><small>${esc(p.display || '')}</small></div><button data-del="${i}" title="Remove"><i class="fas fa-trash"></i></button></div>`).join('')
        : '<div class="err">No saved places yet.<br>Search for a place or right-click the map, then press Save.</div>';
    }
    $('[data-p=saved]', root).onclick = e => {
      const d = e.target.closest('[data-del]');
      if (d) { saved.splice(+d.dataset.del, 1); LS.set('mapSaved', saved); drawSavedMarkers(); drawSavedList(); renderCard(); return; }
      const i = e.target.closest('[data-i]'); if (i) showPlace(saved[+i.dataset.i]);
    };
    function toggleSave(p) {
      if (isSaved(p)) saved = saved.filter(s => !same(s, p));
      else saved.push({ name: p.name, display: p.display, lat: p.lat, lon: p.lon });
      LS.set('mapSaved', saved); drawSavedMarkers(); renderCard();
    }
    const card = $('.mp-card', root);
    function renderCard() {
      if (!sel) return card.classList.add('hidden');
      card.classList.remove('hidden');
      card.innerHTML = `<button class="x" data-a="close" title="Close"><i class="fas fa-xmark"></i></button><h3>${esc(sel.name)}</h3><p>${esc(sel.display || '')}</p>
        <small>${sel.lat.toFixed(5)}, ${sel.lon.toFixed(5)}${sel.type ? ' · ' + esc(sel.type) : ''}</small>
        ${sel.extra ? `<small>${esc(sel.extra)}</small>` : ''}
        <div class="mp-acts"><button data-a="to"><i class="fas fa-route"></i> Directions</button><button data-a="save" class="${isSaved(sel) ? 'on' : ''}"><i class="fas fa-bookmark"></i> ${isSaved(sel) ? 'Saved' : 'Save'}</button><button data-a="copy"><i class="fas fa-link"></i> Copy link</button></div>`;
    }
    card.onclick = async e => {
      const a = e.target.closest('[data-a]'); if (!a || !sel) return;
      if (a.dataset.a === 'close') { sel = null; selMarker && map.removeLayer(selMarker); selMarker = null; renderCard(); }
      if (a.dataset.a === 'to') setPoint('to', sel, true);
      if (a.dataset.a === 'save') toggleSave(sel);
      if (a.dataset.a === 'copy') { try { await navigator.clipboard.writeText(link(sel)); fail('Link copied.'); } catch { fail(link(sel)); } }
    };
    function showPlace(p, fly = true) {
      sel = p; selMarker && map.removeLayer(selMarker);
      selMarker = L.marker([p.lat, p.lon], { icon: pin('') }).addTo(map);
      if (fly) {
        const b = p.bbox && p.bbox.length === 4 ? p.bbox : null;
        if (b && Math.abs(b[1] - b[0]) > 0.003) map.flyToBounds([[b[0], b[2]], [b[1], b[3]]], { maxZoom: 17, duration: 0.8 });
        else map.flyTo([p.lat, p.lon], Math.max(map.getZoom(), 16), { duration: 0.8 });
      }
      renderCard(); tab('explore');
    }
    async function pinAt(lat, lon) {
      const d = await api(`/api/geo/reverse?lat=${lat}&lon=${lon}`).catch(() => null);
      return d && d.display ? { name: d.name || 'Dropped pin', display: d.display, lat, lon, type: d.type } : { name: 'Dropped pin', display: `${lat.toFixed(5)}, ${lon.toFixed(5)}`, lat, lon };
    }

    /* ---------- search + nearby ---------- */
    const list = $('[data-p=explore] .mp-list', root), box = $('.mp-search input', root);
    let found = [], active = null, st;
    const spin = '<div class="loading"><span class="spin"></span></div>';
    function renderList(items, head) {
      found = items;
      list.innerHTML = (head ? `<div class="mp-head">${head}</div>` : '') + (items.length ? items.map((p, i) => `<div class="mp-item" data-i="${i}"><i class="fas ${p.ic || 'fa-location-dot'}"></i><div><strong>${esc(p.name)}</strong><small>${esc(p.display || '')}</small></div>${p.dist != null ? `<em>${fmtDist(p.dist)}</em>` : ''}</div>`).join('') : '<div class="err">Nothing found here.</div>');
    }
    list.onclick = e => { const i = e.target.closest('[data-i]'); if (i) showPlace(found[+i.dataset.i]); };
    async function doSearch(q) {
      q = q.trim(); if (!q) return; active = null; paintChips(); nearLayer.clearLayers(); list.innerHTML = spin;
      const c = map.getCenter();
      const d = await api(`/api/geo/search?q=${encodeURIComponent(q)}&lat=${c.lat}&lon=${c.lng}`).catch(() => ({ results: [], error: 'Could not reach the server' }));
      if (d.error) return (list.innerHTML = `<div class="err">${esc(d.error)}</div>`);
      renderList(d.results.map(r => ({ ...r })), `Results for “${esc(q)}”`);
      if (d.results.length === 1) showPlace(d.results[0]);
    }
    $('.mp-search', root).onsubmit = e => { e.preventDefault(); clearTimeout(st); doSearch(box.value); };
    box.oninput = () => { clearTimeout(st); if (box.value.trim().length >= 4) st = setTimeout(() => doSearch(box.value), 700); };
    const paintChips = () => $$('.mp-chips button', root).forEach(b => b.classList.toggle('on', b.dataset.cat === active));
    async function nearby(cat) {
      if (map.getZoom() < 12) return fail('Zoom in to a neighbourhood level first, then pick a category.');
      active = cat; paintChips(); list.innerHTML = spin;
      const c = map.getCenter(), r = Math.round(Math.min(5000, Math.max(300, c.distanceTo(map.getBounds().getNorthEast()) * 0.8)));
      const meta = CATS.find(x => x[0] === cat);
      const d = await api(`/api/geo/nearby?cat=${cat}&lat=${c.lat}&lon=${c.lng}&r=${r}`).catch(() => ({ results: [], error: 'Could not reach the server' }));
      if (active !== cat) return;
      if (d.error) return (list.innerHTML = `<div class="err">${esc(d.error)}</div>`);
      nearLayer.clearLayers();
      const items = d.results.map(p => ({ name: p.name, display: p.address || p.hours || meta[1], lat: p.lat, lon: p.lon, ic: meta[2], dist: c.distanceTo([p.lat, p.lon]), extra: [p.hours, p.phone].filter(Boolean).join(' · '), type: meta[1] }))
        .sort((a, b) => a.dist - b.dist);
      items.forEach(p => L.marker([p.lat, p.lon], { icon: dot(meta[2]), title: p.name }).on('click', () => showPlace(p, false)).addTo(nearLayer));
      renderList(items, `${meta[1]} near the map centre`);
    }
    $('.mp-chips', root).onclick = e => {
      const b = e.target.closest('[data-cat]'); if (!b) return;
      if (active === b.dataset.cat) { active = null; paintChips(); nearLayer.clearLayers(); list.innerHTML = ''; } else nearby(b.dataset.cat);
    };

    /* ---------- directions ---------- */
    const rf = $('.rf', root), rt = $('.rt', root), P = { from: null, to: null };
    let mode = 'driving';
    function setPoint(k, p, open) {
      P[k] = { lat: p.lat, lon: p.lon, label: p.name }; (k === 'from' ? rf : rt).value = p.name;
      if (k === 'to' && !P.from && !rf.value && me) { P.from = { lat: me.lat, lon: me.lon, label: 'My location' }; rf.value = 'My location'; }
      if (open) tab('route'); if (P.from && P.to) route(); else (k === 'to' ? rf : rt).focus();
    }
    function locate(fly = true) {
      return new Promise(res => {
        if (!navigator.geolocation) { fail('This device can’t share its location. Search for an address instead.'); return res(null); }
        navigator.geolocation.getCurrentPosition(pos => {
          me = { lat: pos.coords.latitude, lon: pos.coords.longitude, acc: pos.coords.accuracy };
          meLayer && map.removeLayer(meLayer);
          meLayer = L.layerGroup([L.circle([me.lat, me.lon], { radius: me.acc, color: '#4d9fff', weight: 1, fillOpacity: 0.12 }), L.marker([me.lat, me.lon], { icon: L.divIcon({ className: 'mp-me', iconSize: [18, 18] }) })]).addTo(map);
          fly && map.flyTo([me.lat, me.lon], 15); res(me);
        }, () => { fail('Couldn’t get your location (allow it, or search for an address instead).'); res(null); }, { enableHighAccuracy: true, timeout: 10000 });
      });
    }
    async function resolve(k) {
      const inp = k === 'from' ? rf : rt, v = inp.value.trim();
      if (!v) throw new Error(k === 'from' ? 'Enter a starting point' : 'Enter a destination');
      if (P[k] && P[k].label === v) return P[k];
      if (/^(my|current) location$/i.test(v)) { if (!me) await locate(false); if (!me) throw new Error('Your location isn’t available'); return (P[k] = { lat: me.lat, lon: me.lon, label: v }); }
      const m = v.match(/^\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*$/); if (m) return (P[k] = { lat: +m[1], lon: +m[2], label: v });
      const c = map.getCenter();
      const d = await api(`/api/geo/search?q=${encodeURIComponent(v)}&lat=${c.lat}&lon=${c.lng}`);
      if (!d.results || !d.results.length) throw new Error(`Couldn’t find “${v}”`);
      return (P[k] = { lat: d.results[0].lat, lon: d.results[0].lon, label: v });
    }
    let lastRoute = null;
    async function route() {
      const sum = $('.mp-sum', root), steps = $('.mp-steps', root);
      sum.classList.remove('hidden'); sum.innerHTML = spin; steps.innerHTML = '';
      try {
        const [a, b] = await Promise.all([resolve('from'), resolve('to')]);
        const d = await api(`/api/geo/route?mode=${mode}&from=${a.lat},${a.lon}&to=${b.lat},${b.lon}`);
        if (d.error) throw new Error(d.error);
        lastRoute = d; routeLayer.clearLayers();
        L.polyline(d.coords, { color: '#06224f', weight: 10, opacity: 0.85 }).addTo(routeLayer);
        const line = L.polyline(d.coords, { color: '#4d9fff', weight: 6 }).addTo(routeLayer);
        L.marker([a.lat, a.lon], { icon: letter('A', '#1db954') }).addTo(routeLayer); L.marker([b.lat, b.lon], { icon: letter('B', '#ff4d5e') }).addTo(routeLayer);
        map.flyToBounds(line.getBounds(), { padding: [60, 60], duration: 0.8 });
        sum.innerHTML = `<strong>${fmtTime(d.duration)}</strong> <span>${fmtDist(d.distance)}</span> <button class="clr" title="Clear route"><i class="fas fa-xmark"></i></button>`;
        steps.innerHTML = d.steps.map((s, i) => `<li data-i="${i}"><span>${esc(s.text)}</span><small>${s.distance ? fmtDist(s.distance) : ''}</small></li>`).join('');
      } catch (e) { sum.innerHTML = `<div class="err" style="padding:14px">${esc(e.message)}</div>`; }
    }
    function clearRoute() { routeLayer.clearLayers(); lastRoute = null; $('.mp-sum', root).classList.add('hidden'); $('.mp-steps', root).innerHTML = ''; }
    $('.mp-go', root).onclick = route;
    [rf, rt].forEach(i => i.onkeydown = e => { if (e.key === 'Enter') route(); });
    $('.rme', root).onclick = async () => { const m = await locate(false); if (m) { rf.value = 'My location'; P.from = { lat: m.lat, lon: m.lon, label: 'My location' }; } };
    $('.rswap', root).onclick = () => { [rf.value, rt.value] = [rt.value, rf.value]; [P.from, P.to] = [P.to, P.from]; if (rf.value && rt.value) route(); };
    $('.mp-modes', root).onclick = e => { const b = e.target.closest('[data-m]'); if (!b) return; mode = b.dataset.m; $$('.mp-modes button', root).forEach(x => x.classList.toggle('on', x === b)); if (rf.value && rt.value) route(); };
    $('.mp-sum', root).onclick = e => { if (e.target.closest('.clr')) clearRoute(); };
    $('.mp-steps', root).onclick = e => { const li = e.target.closest('[data-i]'); if (!li || !lastRoute) return; const s = lastRoute.steps[+li.dataset.i]; map.flyTo(s.loc, 17, { duration: 0.6 }); L.popup({ closeButton: false }).setLatLng(s.loc).setContent(esc(s.text)).openOn(map); };

    /* ---------- right-click menu, locate, measure, layers ---------- */
    map.on('contextmenu', e => {
      const { lat, lng } = e.latlng, div = document.createElement('div'); div.className = 'mp-ctx';
      div.innerHTML = `<b>${lat.toFixed(5)}, ${lng.toFixed(5)}</b><button data-a="here"><i class="fas fa-circle-info"></i> What’s here?</button><button data-a="from"><i class="fas fa-circle-dot"></i> Directions from here</button><button data-a="to"><i class="fas fa-location-dot"></i> Directions to here</button><button data-a="save"><i class="fas fa-bookmark"></i> Save this spot</button>`;
      div.onclick = async ev => {
        const a = ev.target.closest('[data-a]'); if (!a) return; map.closePopup();
        const p = await pinAt(lat, lng);
        if (a.dataset.a === 'here') showPlace(p, false);
        if (a.dataset.a === 'from') setPoint('from', p, true);
        if (a.dataset.a === 'to') setPoint('to', p, true);
        if (a.dataset.a === 'save') { if (!isSaved(p)) toggleSave(p); showPlace(p, false); }
      };
      L.popup({ closeButton: false, className: 'mp-pop' }).setLatLng(e.latlng).setContent(div).openOn(map);
    });
    let measuring = false, mpts = [];
    const badge = $('.mp-badge', root);
    function drawMeasure() {
      measureLayer.clearLayers(); if (!mpts.length) return badge.classList.add('hidden');
      L.polyline(mpts, { color: '#ffd34d', weight: 4, dashArray: '8 8' }).addTo(measureLayer);
      mpts.forEach(p => L.circleMarker(p, { radius: 5, color: '#ffd34d', fillColor: '#000', fillOpacity: 1 }).addTo(measureLayer));
      let t = 0; for (let i = 1; i < mpts.length; i++) t += map.distance(mpts[i - 1], mpts[i]);
      badge.classList.remove('hidden'); badge.innerHTML = `<i class="fas fa-ruler"></i> ${fmtDist(t)} <button title="Clear">Clear</button>`;
    }
    badge.onclick = e => { if (e.target.closest('button')) { mpts = []; drawMeasure(); } };
    map.on('click', e => { if (measuring) { mpts.push([e.latlng.lat, e.latlng.lng]); drawMeasure(); } });
    $('.mp-tools', root).onclick = e => {
      const b = e.target.closest('[data-tool],[data-k]'); if (!b) return;
      if (b.dataset.k) { setLayer(b.dataset.k); return $('.mp-lay', root).classList.add('hidden'); }
      const t = b.dataset.tool;
      if (t === 'layers') $('.mp-lay', root).classList.toggle('hidden');
      if (t === 'locate') locate();
      if (t === 'units') { miles = !miles; LS.set('mapMiles', miles); paintUnits(); drawMeasure(); if (lastRoute) route(); }
      if (t === 'measure') { measuring = !measuring; b.classList.toggle('on', measuring); canvas.classList.toggle('measuring', measuring); if (!measuring) { mpts = []; drawMeasure(); } else fail('Click the map to add points. Press the ruler again to stop.'); }
    };

    w.onclose = () => { ro.disconnect(); map.remove(); };
    w.opts = o => { if (o && o.q) { box.value = o.q; tab('explore'); doSearch(o.q); } };
    setLayer(LS.get('mapLayer', 'dark')); paintUnits(); drawSavedMarkers(); w.opts(o);
  },
});
