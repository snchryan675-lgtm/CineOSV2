// Cine/Figure OS - Messages: add friends and chat (like Discord, no calling).
// Talks to the chat server in /messages-server (see README). Stays connected in the background so you get
// a pop-up and an unread badge when a friend writes, even with the app closed.
// Put your chat server's address here ONCE (for example 'https://chat.yourname.com') and nobody ever sees or types a server again.
const MSG_DEFAULT_SERVER = '';
const MSG = {
  server: MSG_DEFAULT_SERVER || LS.get('msgServer', ''), token: LS.get('msgToken', ''),
  me: null, friends: [], incoming: [], outgoing: [], msgs: {}, typing: {},
  open: null, tab: 'online', status: 'off', gen: 0, fails: 0, ctl: null, ui: null,
};
const AV_COLORS = ['#5865f2', '#eb459e', '#23a55a', '#f0b232', '#f23f43', '#9b59b6', '#1abc9c', '#e67e22'];
const EMOJI = '😀 😂 🥹 😍 😎 🤔 😭 😡 👍 👎 👏 🙏 🔥 ✨ 💯 ❤️ 💀 🎮 🎵 🍿 👀 🤝 😴 🥳 😅 🙌 💪 🤯 😈 🫡 🤣 😊'.split(' ');

/* ---------- helpers ---------- */
const mUrl = p => window.cine
  ? `/msg${p}${p.includes('?') ? '&' : '?'}server=${encodeURIComponent(MSG.server)}` // desktop app: the app forwards it
  : MSG.server.replace(/\/+$/, '') + p;                                             // browser: straight to the server
async function mreq(method, path, body) {
  let r;
  try { r = await fetch(mUrl(path), { method, headers: Object.assign({ 'content-type': 'application/json' }, MSG.token ? { authorization: 'Bearer ' + MSG.token } : {}), body: body ? JSON.stringify(body) : undefined }); }
  catch { throw new Error('Cannot reach the server. Check the address.'); }
  let j = {}; try { j = await r.json(); } catch {}
  if (!r.ok) { const e = new Error(j.error || 'Server answered ' + r.status); e.status = r.status; throw e; }
  return j;
}
const fKey = n => String(n || '').toLowerCase();
const colorOf = n => AV_COLORS[[...String(n)].reduce((a, c) => a + c.charCodeAt(0), 0) % AV_COLORS.length];
const friendOf = n => MSG.friends.find(f => fKey(f.name) === fKey(n));
const isMe = n => MSG.me && fKey(n) === fKey(MSG.me.name);
const fmtT = ts => new Date(ts).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
function fmtDay(ts) {
  const d = new Date(ts), t = new Date(), y = new Date(Date.now() - 864e5);
  if (d.toDateString() === t.toDateString()) return 'Today';
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return d.toLocaleDateString([], { month: 'long', day: 'numeric', year: 'numeric' });
}
function msAv(name, color, size = 36, online = null) {
  const own = isMe(name) && getProfile().avatar;
  const bg = own ? `background-image:url(${getProfile().avatar})` : `background-color:${color || colorOf(name)}`;
  return `<span class="ms-av" style="--s:${size}px;${bg}">${own ? '' : esc(String(name)[0].toUpperCase())}${online === null ? '' : `<i class="${online ? 'on' : ''}"></i>`}</span>`;
}
const linkify = t => esc(t).replace(/(https?:\/\/[^\s<]+[^\s<.,;:!?)\]'"])/g, '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>');
const totalUnread = () => MSG.friends.reduce((n, f) => n + (f.unread || 0), 0) + MSG.incoming.length;

/* unread badge on the taskbar icon and the home tile */
function paintBadges() {
  const n = MSG.token ? totalUnread() : 0;
  $$('#dock .dk[data-id="messages"], .hm-t[data-id="messages"]').forEach(el => {
    let b = el.querySelector(':scope > .bdg');
    if (!n) { b && b.remove(); return; }
    if (!b) { b = document.createElement('b'); b.className = 'bdg'; el.append(b); }
    b.textContent = n > 99 ? '99+' : n;
  });
}
const repaint = (...parts) => { paintBadges(); MSG.ui && parts.forEach(p => MSG.ui[p] && MSG.ui[p]()); };

/* ---------- session + live connection ---------- */
function setSession(d) {
  MSG.token = d.token; LS.set('msgToken', d.token); applyMe(d); MSG.open = null; connect();
}
function applyMe(d) {
  MSG.me = d.me; MSG.friends = d.friends; MSG.incoming = d.incoming; MSG.outgoing = d.outgoing;
  if (MSG.open && !friendOf(MSG.open)) MSG.open = null;
}
async function refresh() { try { const had = MSG.incoming.length; applyMe(await mreq('GET', '/me')); if (MSG.incoming.length > had) toast('Friend request', MSG.incoming[MSG.incoming.length - 1] + ' wants to be your friend.'); repaint('side', 'main'); } catch (e) { if (e.status === 401) signOut(true); } }
function signOut(expired) {
  if (!expired && MSG.token) mreq('POST', '/logout').catch(() => {});
  MSG.gen++; MSG.ctl && MSG.ctl.abort();
  MSG.token = ''; LS.set('msgToken', ''); MSG.me = null; MSG.friends = []; MSG.incoming = []; MSG.outgoing = []; MSG.msgs = {}; MSG.open = null; MSG.status = 'off';
  if (expired) toast('Messages', 'You were signed out. Sign in again.');
  repaint('all');
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function connect() {
  const my = ++MSG.gen; MSG.ctl && MSG.ctl.abort();
  while (my === MSG.gen && MSG.token && MSG.server) {
    MSG.status = 'connecting'; repaint('side');
    const ctl = MSG.ctl = new AbortController();
    try {
      const r = await fetch(mUrl('/events'), { headers: { authorization: 'Bearer ' + MSG.token }, signal: ctl.signal });
      if (r.status === 401) return signOut(true);
      if (!r.ok || !r.body) throw 0;
      MSG.status = 'on'; MSG.fails = 0; await refresh(); repaint('side');
      if (MSG.open) loadChat(MSG.open, true);
      const rd = r.body.getReader(), dec = new TextDecoder(); let buf = '';
      for (;;) {
        const { done, value } = await rd.read(); if (done) break;
        buf += dec.decode(value, { stream: true }); let i;
        while ((i = buf.indexOf('\n\n')) >= 0) { onEvent(buf.slice(0, i)); buf = buf.slice(i + 2); }
      }
    } catch { if (ctl.signal.aborted) return; }
    if (my !== MSG.gen) return;
    MSG.status = 'off'; repaint('side'); await sleep(Math.min(15000, 1500 * ++MSG.fails));
  }
}
function onEvent(raw) {
  let ev = '', data = '';
  raw.split('\n').forEach(l => { if (l.startsWith('event:')) ev = l.slice(6).trim(); else if (l.startsWith('data:')) data += l.slice(5).trim(); });
  let d = {}; try { d = JSON.parse(data || '{}'); } catch { return; }
  if (ev === 'friends') refresh();
  else if (ev === 'presence') { const f = friendOf(d.name); if (f) { f.online = d.online; repaint('side', 'head', 'friendsView'); } }
  else if (ev === 'typing') { MSG.typing[fKey(d.from)] = Date.now(); repaint('typing'); setTimeout(() => repaint('typing'), 3600); }
  else if (ev === 'read') { const f = friendOf(d.with); if (f) { f.unread = 0; repaint('side'); } }
  else if (ev === 'delete') { const l = MSG.msgs[fKey(d.with)]; if (l) { const i = l.findIndex(m => m.id === d.id); if (i >= 0) l.splice(i, 1); } repaint('msgs'); }
  else if (ev === 'message') onMessage(d.m, d.with);
}
function onMessage(m, who) {
  const f = friendOf(who), k = fKey(who), mine = isMe(m.from);
  const l = MSG.msgs[k]; if (l && !l.some(x => x.id === m.id)) l.push(m);
  if (f) f.last = { text: m.text.slice(0, 80), ts: m.ts, from: m.from };
  if (!mine) {
    delete MSG.typing[k];
    const w = typeof wins !== 'undefined' && wins.messages, visible = w && w.el.classList.contains('show') && document.hasFocus();
    if (visible && MSG.open && fKey(MSG.open) === k) mreq('POST', '/read', { with: who }).catch(() => {});
    else { if (f) f.unread = (f.unread || 0) + 1; toast(m.from, m.text.slice(0, 90)); }
  }
  repaint('side', 'msgs', 'typing');
}
async function loadChat(name, quiet) {
  const k = fKey(name);
  try { MSG.msgs[k] = (await mreq('GET', '/messages?with=' + encodeURIComponent(name))).messages; } catch (e) { if (!quiet) toast('Messages', e.message); MSG.msgs[k] = MSG.msgs[k] || []; }
  repaint('msgs');
}
function openChat(name) {
  MSG.open = name; const f = friendOf(name);
  if (f && f.unread) { f.unread = 0; mreq('POST', '/read', { with: name }).catch(() => {}); }
  if (!MSG.msgs[fKey(name)]) loadChat(name);
  repaint('side', 'main');
}

/* make Messages show up on the taskbar once for people who already had a saved taskbar */
if (!LS.get('msgPinned', false)) { const p = LS.get('pins', null); if (p && !p.includes('messages')) { p.push('messages'); LS.set('pins', p); } LS.set('msgPinned', true); }
if (MSG.token && MSG.server) setTimeout(connect, 1200);

/* ---------- the app window ---------- */
registerApp({
  id: 'messages', name: 'Messages', icon: 'fa-comments', img: 'icons/messages.png', bg: 'transparent', pinned: true,
  mount(root, w, o) {
    root.classList.add('ms');
    root.innerHTML = '<div class="ms-in"></div>';
    const R = $('.ms-in', root);
    const ui = MSG.ui = {};
    w.onclose = () => { if (MSG.ui === ui) MSG.ui = null; };
    const go = () => {
      if (!MSG.token) return auth();
      if (MSG.me) return shell();
      // signed in from last time but the profile has not loaded yet
      const card = h => `<div class="ms-auth"><div class="ms-card"><img src="icons/messages.png" alt="" draggable="false">${h}</div></div>`;
      R.innerHTML = card('<h1>Messages</h1><p class="ms-sub"><i class="fas fa-circle-notch fa-spin"></i> Connecting…</p>');
      mreq('GET', '/me').then(d => { applyMe(d); go(); }).catch(e => {
        if (e.status === 401) return signOut(true);
        R.innerHTML = card(`<h1>Can't connect</h1><p class="ms-sub">${esc(e.message)}</p><button class="btn ms-go" data-a="retry">Try again</button><button class="btn ms-go alt" data-a="out" style="margin-top:10px">Use another server</button>`);
        $('[data-a=retry]', R).onclick = go; $('[data-a=out]', R).onclick = () => signOut();
      });
    };
    ui.all = go;

    /* --- sign in / create account --- */
    function auth() {
      let mode = 'in';
      R.innerHTML = `<div class="ms-auth"><div class="ms-card">
        <img src="icons/messages.png" alt="" draggable="false"><h1>Messages</h1>
        <p class="ms-sub">Chat with your friends. No calls, just messages.</p>
        <div class="ms-tabs2"><button data-m="in" class="on">Sign in</button><button data-m="up">Create account</button></div>
        ${MSG_DEFAULT_SERVER ? '' : `<label>Server address<input id="a-srv" placeholder="https://your-chat-server.com" value="${esc(MSG.server)}" spellcheck="false" autocomplete="off"></label>`}
        <label>Username<input id="a-usr" maxlength="20" spellcheck="false" autocomplete="off"></label>
        <label>Password<input id="a-pw" type="password" maxlength="100"></label>
        <div class="ms-err" id="a-err"></div>
        <button class="btn ms-go" id="a-go">Sign in</button>
        ${MSG_DEFAULT_SERVER ? '' : '<small class="ms-hint">New here? You (or a friend) need to run the chat server first. It is in the <b>messages-server</b> folder. See the README.</small>'}
      </div></div>`;
      const err = t => { $('#a-err', R).textContent = t || ''; };
      $$('.ms-tabs2 button', R).forEach(b => b.onclick = () => { mode = b.dataset.m; $$('.ms-tabs2 button', R).forEach(x => x.classList.toggle('on', x === b)); $('#a-go', R).textContent = mode === 'in' ? 'Sign in' : 'Create account'; err(); });
      const submit = async () => {
        let srv = MSG_DEFAULT_SERVER || $('#a-srv', R).value.trim(); if (srv && !/^https?:\/\//i.test(srv)) srv = (/^(localhost|127\.|192\.168\.|10\.)/.test(srv) ? 'http://' : 'https://') + srv;
        const usr = $('#a-usr', R).value.trim(), pw = $('#a-pw', R).value;
        if (!srv) return err('Enter the server address.'); if (!usr || !pw) return err('Enter a username and password.');
        const btn = $('#a-go', R); btn.disabled = true; btn.textContent = 'Please wait…'; err();
        MSG.server = srv; MSG.token = '';
        try {
          setSession(await mreq('POST', mode === 'in' ? '/login' : '/register', { username: usr, password: pw }));
          LS.set('msgServer', srv); go();
        } catch (e) { err(e.message); btn.disabled = false; btn.textContent = mode === 'in' ? 'Sign in' : 'Create account'; }
      };
      $('#a-go', R).onclick = submit;
      $$('input', R).forEach(i => i.onkeydown = e => { if (e.key === 'Enter') submit(); });
    }

    /* --- main layout --- */
    function shell() {
      R.innerHTML = `<aside class="ms-side">
          <div class="ms-sh"><strong>Messages</strong></div>
          <input class="ms-find" placeholder="Find a friend" spellcheck="false">
          <button class="ms-nav" data-a="friends"><i class="fas fa-user-group"></i><span>Friends</span><b class="ms-pill hidden"></b></button>
          <h4>Direct messages</h4>
          <div class="ms-dms"></div>
          <div class="ms-me"></div>
        </aside>
        <section class="ms-main"></section>`;
      $('.ms-find', R).oninput = () => ui.side();
      $('[data-a=friends]', R).onclick = () => { MSG.open = null; ui.side(); ui.main(); };
      ui.side(); ui.main();
      if (o && o.with) openChat(o.with);
    }
    ui.side = () => {
      const dms = $('.ms-dms', R); if (!dms) return;
      const q = $('.ms-find', R).value.trim().toLowerCase();
      const list = [...MSG.friends].filter(f => !q || f.name.toLowerCase().includes(q)).sort((a, b) => ((b.last && b.last.ts) || 0) - ((a.last && a.last.ts) || 0) || a.name.localeCompare(b.name));
      dms.innerHTML = list.length ? list.map(f => `<button class="ms-dm${MSG.open && fKey(MSG.open) === fKey(f.name) ? ' on' : ''}" data-n="${esc(f.name)}">
          ${msAv(f.name, f.color, 34, f.online)}
          <span class="ms-dt"><b>${esc(f.name)}</b><small>${f.last ? (isMe(f.last.from) ? 'You: ' : '') + esc(f.last.text) : (f.online ? 'Online' : 'Offline')}</small></span>
          ${f.unread ? `<i class="ms-badge">${f.unread > 99 ? '99+' : f.unread}</i>` : ''}</button>`).join('')
        : `<p class="ms-none">${q ? 'No friend matches.' : 'No friends yet. Open Friends and add someone by their username.'}</p>`;
      $$('.ms-dm', dms).forEach(b => b.onclick = () => openChat(b.dataset.n));
      const nav = $('[data-a=friends]', R); nav.classList.toggle('on', !MSG.open);
      const pill = $('.ms-pill', nav); pill.textContent = MSG.incoming.length; pill.classList.toggle('hidden', !MSG.incoming.length);
      const st = { on: ['Connected', '#23a55a'], connecting: ['Connecting…', '#f0b232'], off: ['Offline. Retrying…', '#80848e'] }[MSG.status];
      $('.ms-me', R).innerHTML = `${msAv(MSG.me.name, MSG.me.color, 34)}<span class="ms-dt"><b>${esc(MSG.me.name)}</b><small><i style="background:${st[1]}"></i>${st[0]}</small></span>
        <button class="ms-ic" data-a="set" title="Settings"><i class="fas fa-gear"></i></button>`;
      $('[data-a=set]', R).onclick = settings;
    };
    ui.head = () => { const h = $('.ms-head', R); if (h && MSG.open) { const f = friendOf(MSG.open); h.querySelector('.ms-hs').textContent = f && f.online ? 'Online' : 'Offline'; h.querySelector('.ms-av i') && h.querySelector('.ms-av i').classList.toggle('on', !!(f && f.online)); } };
    ui.main = () => { // rebuild only when the page changes, so a half-typed message is never lost
      const m = $('.ms-main', R); if (!m) return;
      if (MSG.open) { if (m.dataset.chat === fKey(MSG.open)) return ui.head(); return chatView(); }
      if (m.dataset.chat === '' && $('.ms-tabs', m)) { const n = MSG.incoming.length; $('[data-t=pending]', m).textContent = 'Pending' + (n ? ' · ' + n : ''); return ui.friendsView && ui.friendsView(); }
      friendsView();
    };

    /* --- friends page --- */
    let confirmRm = null;
    function friendsView() {
      const m = $('.ms-main', R); if (!m) return;
      const n = MSG.incoming.length; m.dataset.chat = '';
      m.innerHTML = `<header class="ms-top"><i class="fas fa-user-group"></i><strong>Friends</strong>
          <nav class="ms-tabs">${[['online', 'Online'], ['all', 'All'], ['pending', 'Pending' + (n ? ' · ' + n : '')], ['add', 'Add friend']].map(([k, t]) => `<button data-t="${k}" class="${MSG.tab === k ? 'on' : ''}${k === 'add' ? ' add' : ''}">${t}</button>`).join('')}</nav></header>
        <div class="ms-body" id="ms-fv"></div>`;
      $$('.ms-tabs button', m).forEach(b => b.onclick = () => { MSG.tab = b.dataset.t; friendsView(); });
      ui.friendsView = () => { if (MSG.tab !== 'add') drawTab(); }; drawTab();
    }
    function drawTab() {
      const box = $('#ms-fv', R); if (!box) return;
      const row = (name, color, sub, online, acts) => `<div class="ms-row">${msAv(name, color, 40, online)}<span class="ms-dt"><b>${esc(name)}</b><small>${sub}</small></span><span class="ms-acts">${acts}</span></div>`;
      const btn = (a, n, ic, tip, cls = '') => `<button class="ms-ic ${cls}" data-a="${a}" data-n="${esc(n)}" title="${tip}"><i class="fas ${ic}"></i></button>`;
      const frow = f => row(f.name, f.color, f.online ? 'Online' : 'Offline', f.online, btn('chat', f.name, 'fa-message', 'Message') + btn('rm', f.name, confirmRm === fKey(f.name) ? 'fa-check' : 'fa-user-minus', confirmRm === fKey(f.name) ? 'Click again to remove' : 'Remove friend', confirmRm === fKey(f.name) ? 'bad' : ''));
      if (MSG.tab === 'add') {
        box.innerHTML = `<div class="ms-add"><h2>Add a friend</h2><p>Type your friend's username to send a friend request.</p>
          <div class="ms-addrow"><input id="ms-addin" placeholder="Username" maxlength="20" spellcheck="false" autocomplete="off"><button class="btn" id="ms-addgo">Send request</button></div>
          <div class="ms-addmsg" id="ms-addmsg"></div></div>`;
        const input = $('#ms-addin', R), say = (t, bad) => { const e = $('#ms-addmsg', R); e.textContent = t; e.className = 'ms-addmsg' + (bad ? ' bad' : ' good'); };
        const send = async () => {
          const u = input.value.trim(); if (!u) return;
          try { const r = await mreq('POST', '/friends/add', { username: u }); input.value = ''; say(r.name ? `Done! Request sent to ${r.name}.` : 'Done!'); refresh(); }
          catch (e) { say(e.message, true); }
        };
        $('#ms-addgo', R).onclick = send; input.onkeydown = e => { if (e.key === 'Enter') send(); }; input.focus(); return;
      }
      let html = '';
      if (MSG.tab === 'pending') {
        html += MSG.incoming.map(n => row(n, null, 'Wants to be your friend', null, btn('acc', n, 'fa-check', 'Accept', 'good') + btn('dec', n, 'fa-xmark', 'Decline', 'bad'))).join('');
        html += MSG.outgoing.map(n => row(n, null, 'Request sent', null, btn('dec', n, 'fa-xmark', 'Cancel request', 'bad'))).join('');
        if (!html) html = '<p class="ms-empty"><i class="fas fa-hourglass-half"></i>No pending requests.</p>';
      } else {
        const list = MSG.friends.filter(f => MSG.tab === 'all' || f.online).sort((a, b) => b.online - a.online || a.name.localeCompare(b.name));
        html = list.length ? `<h4 class="ms-lh">${MSG.tab === 'all' ? 'All friends' : 'Online'} · ${list.length}</h4>` + list.map(frow).join('')
          : `<p class="ms-empty"><i class="fas fa-user-group"></i>${MSG.tab === 'all' ? 'No friends yet. Use “Add friend” to send a request.' : 'Nobody is online right now.'}</p>`;
      }
      box.innerHTML = html;
      $$('[data-a]', box).forEach(b => b.onclick = async () => {
        const a = b.dataset.a, n = b.dataset.n;
        try {
          if (a === 'chat') return openChat(n);
          if (a === 'rm') { if (confirmRm !== fKey(n)) { confirmRm = fKey(n); drawTab(); setTimeout(() => { if (confirmRm === fKey(n)) { confirmRm = null; ui.friendsView && ui.friendsView(); } }, 3000); return; } confirmRm = null; await mreq('POST', '/friends/remove', { username: n }); }
          if (a === 'acc') await mreq('POST', '/friends/accept', { username: n });
          if (a === 'dec') await mreq('POST', '/friends/decline', { username: n });
          refresh();
        } catch (e) { toast('Messages', e.message); }
      });
    }

    /* --- a chat --- */
    function chatView() {
      const m = $('.ms-main', R); if (!m || !MSG.open) return;
      const f = friendOf(MSG.open); if (!f) { MSG.open = null; return friendsView(); }
      ui.friendsView = null; m.dataset.chat = fKey(MSG.open);
      m.innerHTML = `<header class="ms-top ms-head">${msAv(f.name, f.color, 30, f.online)}<strong>${esc(f.name)}</strong><span class="ms-hs">${f.online ? 'Online' : 'Offline'}</span></header>
        <div class="ms-list"></div>
        <div class="ms-typing"></div>
        <div class="ms-comp"><div class="ms-box"><textarea rows="1" maxlength="2000" placeholder="Message ${esc(f.name)}" spellcheck="true"></textarea>
          <button class="ms-ic" data-a="emo" title="Emoji"><i class="far fa-face-smile"></i></button>
          <button class="ms-ic send" data-a="send" title="Send"><i class="fas fa-paper-plane"></i></button></div></div>`;
      const ta = $('textarea', m); let lastType = 0;
      const grow = () => { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 160) + 'px'; };
      const send = async () => {
        const text = ta.value.trim(); if (!text) return; ta.value = ''; grow();
        try { await mreq('POST', '/messages', { to: f.name, text }); } catch (e) { ta.value = text; grow(); toast('Message not sent', e.message); }
      };
      ta.oninput = () => { grow(); if (Date.now() - lastType > 2500 && ta.value) { lastType = Date.now(); mreq('POST', '/typing', { to: f.name }).catch(() => {}); } };
      ta.onkeydown = e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } };
      $('[data-a=send]', m).onclick = send;
      $('[data-a=emo]', m).onclick = e => {
        const old = $('.ms-emo', m); if (old) return old.remove();
        const p = document.createElement('div'); p.className = 'ms-emo';
        p.innerHTML = EMOJI.map(x => `<button type="button">${x}</button>`).join('');
        p.onclick = ev => { const b = ev.target.closest('button'); if (!b) return; const s = ta.selectionStart; ta.setRangeText(b.textContent, s, ta.selectionEnd, 'end'); ta.focus(); grow(); };
        $('.ms-comp', m).append(p);
        setTimeout(() => document.addEventListener('click', function h(ev) { if (!p.contains(ev.target)) { p.remove(); document.removeEventListener('click', h); } }), 0);
      };
      $('.ms-list', m).onclick = async e => {
        const b = e.target.closest('[data-del]'); if (!b) return;
        try { await mreq('POST', '/messages/delete', { with: f.name, id: b.dataset.del }); } catch (er) { toast('Messages', er.message); }
      };
      ui.msgs = drawMsgs; ui.typing = drawTyping; drawMsgs(true); drawTyping(); ta.focus();
    }
    function drawMsgs(first) {
      const list = $('.ms-list', R); if (!list || !MSG.open) return;
      const f = friendOf(MSG.open), arr = MSG.msgs[fKey(MSG.open)];
      const near = first || list.scrollHeight - list.scrollTop - list.clientHeight < 140;
      if (!arr) { list.innerHTML = '<div class="ms-load"><i class="fas fa-circle-notch fa-spin"></i></div>'; return; }
      let html = `<div class="ms-start">${msAv(f.name, f.color, 72)}<h2>${esc(f.name)}</h2><p>This is the start of your chat with <b>${esc(f.name)}</b>.</p></div>`, prev = null;
      arr.forEach(m => {
        const day = fmtDay(m.ts), newDay = !prev || fmtDay(prev.ts) !== day;
        const group = !newDay && prev.from === m.from && m.ts - prev.ts < 5 * 60000;
        if (newDay) html += `<div class="ms-day"><span>${day}</span></div>`;
        const mine = isMe(m.from);
        html += group
          ? `<div class="ms-m cont" title="${esc(new Date(m.ts).toLocaleString())}"><span class="ms-tm">${fmtT(m.ts)}</span><div class="ms-t">${linkify(m.text)}</div>${mine ? `<button class="ms-x" data-del="${m.id}" title="Delete"><i class="fas fa-trash"></i></button>` : ''}</div>`
          : `<div class="ms-m">${msAv(m.from, mine ? MSG.me.color : f.color, 40)}<div class="ms-mb"><div class="ms-mh"><b style="color:${mine ? 'var(--txt)' : '#c9cdfb'}">${esc(m.from)}</b><time>${day === 'Today' ? 'Today at ' : day + ' '}${fmtT(m.ts)}</time></div><div class="ms-t">${linkify(m.text)}</div></div>${mine ? `<button class="ms-x" data-del="${m.id}" title="Delete"><i class="fas fa-trash"></i></button>` : ''}</div>`;
        prev = m;
      });
      list.innerHTML = html;
      if (near) list.scrollTop = list.scrollHeight;
    }
    function drawTyping() {
      const el = $('.ms-typing', R); if (!el || !MSG.open) return;
      const on = Date.now() - (MSG.typing[fKey(MSG.open)] || 0) < 3500;
      el.innerHTML = on ? `<span class="ms-dots"><i></i><i></i><i></i></span><b>${esc(MSG.open)}</b> is typing…` : '';
    }

    /* --- settings (server address, sign out) --- */
    function settings() {
      const old = $('.ms-pop', R); if (old) return old.remove();
      const p = document.createElement('div'); p.className = 'ms-pop';
      p.innerHTML = `<div class="ms-popbox"><h3>Messages settings</h3>
        ${MSG_DEFAULT_SERVER ? '' : `<label>Server<input readonly value="${esc(MSG.server)}"></label>`}
        <label>Avatar colour<div class="ms-sw">${AV_COLORS.map(c => `<button data-c="${c}" style="background:${c}" class="${MSG.me.color === c ? 'on' : ''}"></button>`).join('')}</div></label>
        <div class="ms-popact"><button class="btn alt" data-a="close">Close</button><button class="btn red" data-a="out"><i class="fas fa-right-from-bracket"></i> Sign out</button></div></div>`;
      p.onclick = async e => {
        if (e.target === p || e.target.closest('[data-a=close]')) return p.remove();
        if (e.target.closest('[data-a=out]')) { p.remove(); return signOut(); }
        const c = e.target.closest('[data-c]'); if (c) { try { applyMe(await mreq('POST', '/profile', { color: c.dataset.c })); $$('[data-c]', p).forEach(x => x.classList.toggle('on', x === c)); repaint('side', 'msgs'); } catch (er) { toast('Messages', er.message); } }
      };
      R.append(p);
    }

    go();
  },
  onOpen(w, o) { if (o && o.with) { MSG.open = o.with; MSG.ui && MSG.ui.side && (MSG.ui.side(), MSG.ui.main()); } },
});
