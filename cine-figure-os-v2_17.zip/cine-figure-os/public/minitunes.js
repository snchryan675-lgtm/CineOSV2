// Cine/Figure OS - mini music player (bottom right)
(function () {
  const el = $('#mini');
  let last = '';
  el.innerHTML = `<img alt="" title="Open Cine-Tunes"><div class="mi-t" title="Open Cine-Tunes"><strong></strong><small></small></div>
    <div class="mi-b"><button data-c="prev" title="Previous"><i class="fas fa-backward-step"></i></button>
    <button class="pp" data-c="toggle" title="Play / pause"><i class="fas fa-play"></i></button>
    <button data-c="next" title="Next"><i class="fas fa-forward-step"></i></button>
    <button data-c="stop" title="Close player"><i class="fas fa-xmark"></i></button></div>
    <div class="mi-bar"><i></i></div>`;
  const open = () => launchApp('tunes');
  $('img', el).onclick = $('.mi-t', el).onclick = open;
  el.onclick = e => {
    const b = e.target.closest('button'); if (!b) return;
    const w = wins.tunes; if (!w || !w.ctl) return;
    const c = b.dataset.c;
    if (c === 'stop') return closeApp('tunes');
    w.ctl[c]();
  };
  function paint() {
    const w = wins.tunes, s = w && w.ctl && w.ctl.state();
    // show only while a song is loaded and Cine-Tunes itself isn't on screen
    const visible = !!s && !w.el.classList.contains('show');
    el.classList.toggle('hidden', !visible);
    if (!visible) return;
    const key = s.title + '|' + s.art;
    if (key !== last) { last = key; $('img', el).src = s.art; $('strong', el).textContent = s.title; $('small', el).textContent = s.artist; }
    $('.pp i', el).className = s.playing ? 'fas fa-pause' : 'fas fa-play';
    $('.mi-bar i', el).style.width = Math.min(100, s.p * 100) + '%';
  }
  setInterval(paint, 300); paint();
})();
