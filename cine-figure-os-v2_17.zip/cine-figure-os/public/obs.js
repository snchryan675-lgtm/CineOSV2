// Cine/Figure OS - OBS Studio (v2.17)
// An OBS-style studio that lives inside the OS. Scenes, sources, a live preview canvas, an audio mixer and recording.
// The "OS Capture" source records ONLY the Cine/Figure OS itself (its own window), never your PC's screen or other apps:
//   desktop app  -> main.js hands the page its own window (setDisplayMediaRequestHandler), no picker, nothing else is offered
//   plain browser -> getDisplayMedia({ preferCurrentTab }) so the only tab on offer is the OS tab
registerApp({
  id: 'obs', name: 'OBS Studio', icon: 'fa-circle-dot', bg: 'linear-gradient(135deg,#454a57,#14161b)', pinned: true,
  mount(root, w) {
    root.classList.add('ob');
    const desktop = !!window.cine;
    const uid = () => Math.random().toString(36).slice(2, 9);
    const TYPES = { os: ['OS Capture', 'fa-display'], image: ['Image', 'fa-image'], color: ['Color Source', 'fa-fill-drip'], text: ['Text', 'fa-font'], cam: ['Video Capture Device', 'fa-video'] };
    const DEF = { w: 1280, h: 720, fps: 30, mbps: 6, fmt: 'auto', hide: true, autosave: true, osAudio: false, trans: 'cut' };
    const MIMES = {
      auto: ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm', 'video/mp4'],
      webm: ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'],
      mp4: ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4'],
    };
    const pad = n => String(n).padStart(2, '0');
    const fmtTime = ms => { const s = Math.floor(ms / 1000); return pad(Math.floor(s / 3600)) + ':' + pad(Math.floor(s / 60) % 60) + ':' + pad(s % 60); };
    const fmtSize = b => b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB';
    const stamp = () => { const d = new Date(); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + '-' + pad(d.getMinutes()) + '-' + pad(d.getSeconds()); };

    /* ---------------- state (saved) ---------------- */
    const mkOs = () => ({ id: uid(), type: 'os', name: 'OS Capture', x: 0, y: 0, w: 1280, h: 720, vis: true, lock: false, op: 100, fit: 'fit', cl: 0, ct: 0, cr: 0, cb: 0 });
    function load() {
      const d = LS.get('obs', null) || {};
      const scenes = Array.isArray(d.scenes) && d.scenes.length ? d.scenes : [{ id: uid(), name: 'Scene', sources: [mkOs()] }];
      return { cfg: Object.assign({}, DEF, d.cfg), scenes, cur: scenes.some(s => s.id === d.cur) ? d.cur : scenes[0].id, sel: null };
    }
    const st = load();
    const save = () => { if (!LS.set('obs', { cfg: st.cfg, scenes: st.scenes, cur: st.cur })) toast('OBS Studio', 'Could not save: the browser storage is full (big images?).'); };
    const scene = () => st.scenes.find(s => s.id === st.cur) || st.scenes[0];
    const selSrc = () => scene().sources.find(s => s.id === st.sel) || null;

    /* ---------------- layout ---------------- */
    root.innerHTML = `
      <div class="ob-top app-head"><i class="fas fa-circle-dot ob-logo"></i><strong>OBS Studio</strong><span class="ob-prof">Profile: Cine OS · Scene Collection: Untitled</span>
        <span class="ob-chip" id="ob-chip">Ready</span></div>
      <div class="ob-main">
        <div class="ob-stage"><div class="ob-cvw" id="ob-cvw"><canvas id="ob-cv"></canvas><div class="ob-ov" id="ob-ov"></div></div></div>
      </div>
      <div class="ob-docks">
        <section class="ob-dock"><h4>Scenes</h4><ul class="ob-list" id="ob-scenes"></ul>
          <footer><button data-a="scene-add" title="Add scene"><i class="fas fa-plus"></i></button><button data-a="scene-del" title="Remove scene"><i class="fas fa-minus"></i></button><button data-a="scene-up" title="Move up"><i class="fas fa-chevron-up"></i></button><button data-a="scene-down" title="Move down"><i class="fas fa-chevron-down"></i></button></footer></section>
        <section class="ob-dock"><h4>Sources</h4><ul class="ob-list" id="ob-srcs"></ul>
          <footer><button data-a="src-add" title="Add source"><i class="fas fa-plus"></i></button><button data-a="src-del" title="Remove source"><i class="fas fa-minus"></i></button><button data-a="src-props" title="Properties"><i class="fas fa-gear"></i></button><button data-a="src-up" title="Move up"><i class="fas fa-chevron-up"></i></button><button data-a="src-down" title="Move down"><i class="fas fa-chevron-down"></i></button></footer></section>
        <section class="ob-dock"><h4>Audio Mixer</h4><div class="ob-mix" id="ob-mix"></div></section>
        <section class="ob-dock ob-ctl"><h4>Controls</h4>
          <button class="ob-big rec" id="ob-rec" data-a="rec"><i class="fas fa-circle"></i><span>Start Recording</span></button>
          <button class="ob-big" id="ob-pause" data-a="pause" disabled><i class="fas fa-pause"></i><span>Pause Recording</span></button>
          <button class="ob-big" data-a="cap"><i class="fas fa-display"></i><span id="ob-cap-t">Start OS Capture</span></button>
          <div class="ob-row2"><button class="ob-sm" data-a="shot"><i class="fas fa-camera"></i>Screenshot</button><button class="ob-sm" data-a="recs"><i class="fas fa-film"></i>Recordings<b id="ob-rn"></b></button></div>
          <div class="ob-row2"><button class="ob-sm" data-a="cfg"><i class="fas fa-sliders"></i>Settings</button>
            <select class="ob-tsel" id="ob-trans" title="Scene transition"><option value="cut">Cut</option><option value="fade">Fade</option></select></div>
        </section>
      </div>
      <footer class="ob-stat"><span id="ob-s-rec"><i class="fas fa-circle"></i> REC 00:00:00</span><span id="ob-s-size">0 KB</span><span id="ob-s-fps">0.0 fps</span><span id="ob-s-res"></span><span class="ob-hint">Ctrl+Shift+R record · Ctrl+Shift+P pause · records only the OS</span></footer>`;
    const cv = $('#ob-cv', root), ctx = cv.getContext('2d'), ov = $('#ob-ov', root), cvw = $('#ob-cvw', root);
    const layer = document.createElement('canvas'), lctx = layer.getContext('2d');
    const scratch = document.createElement('canvas').getContext('2d');

    /* ---------------- OS capture ---------------- */
    const cap = { stream: null, video: null, busy: false };
    async function startCapture() {
      if (cap.stream) return true;
      if (cap.busy) return false;
      if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) { toast('OS Capture', 'This browser cannot capture the screen. Use the desktop app or a recent Chrome / Edge.'); return false; }
      cap.busy = true;
      try {
        const s = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: { ideal: 60 }, displaySurface: 'browser' }, audio: !!st.cfg.osAudio, preferCurrentTab: true, selfBrowserSurface: 'include', surfaceSwitching: 'exclude', systemAudio: 'exclude' });
        const v = document.createElement('video'); v.muted = true; v.playsInline = true; v.srcObject = s;
        await v.play().catch(() => {});
        cap.stream = s; cap.video = v;
        s.getVideoTracks()[0].addEventListener('ended', () => stopCapture(true));
        attachAudio('os', s);
        syncUI(); toast('OS Capture', 'Capturing the OS only.', 2500);
        return true;
      } catch (e) {
        toast('OS Capture', e && e.name === 'NotAllowedError' ? 'Capture was cancelled.' : 'Capture failed: ' + String((e && e.message) || e).slice(0, 100));
        return false;
      } finally { cap.busy = false; }
    }
    function stopCapture(ended) {
      if (rec.mr && ended) stopRecording();
      if (cap.stream) cap.stream.getTracks().forEach(t => t.stop());
      detachAudio('os'); cap.stream = null; cap.video = null; syncUI();
    }

    /* ---------------- audio mixer ---------------- */
    let ac = null, dest = null;
    const chans = { os: { name: 'OS Audio', src: null, gain: null, an: null, vol: 100, mute: false }, mic: { name: 'Mic/Aux', src: null, gain: null, an: null, vol: 100, mute: false, stream: null } };
    const audioCtx = () => { if (!ac) { ac = new (window.AudioContext || window.webkitAudioContext)(); dest = ac.createMediaStreamDestination(); } if (ac.state === 'suspended') ac.resume().catch(() => {}); return ac; };
    function attachAudio(k, stream) {
      if (!stream.getAudioTracks().length) { renderMix(); return; }
      const c = chans[k]; audioCtx(); detachAudio(k, true);
      c.src = ac.createMediaStreamSource(stream); c.gain = ac.createGain(); c.an = ac.createAnalyser(); c.an.fftSize = 512;
      c.src.connect(c.gain); c.gain.connect(c.an); c.an.connect(dest); applyGain(k); renderMix();
    }
    function detachAudio(k, keep) {
      const c = chans[k];
      try { c.src && c.src.disconnect(); c.gain && c.gain.disconnect(); c.an && c.an.disconnect(); } catch {}
      c.src = c.gain = c.an = null; if (!keep) renderMix();
    }
    const applyGain = k => { const c = chans[k]; if (c.gain) c.gain.gain.value = c.mute ? 0 : c.vol / 100; };
    async function toggleMic() {
      const c = chans.mic;
      if (c.stream) { c.stream.getTracks().forEach(t => t.stop()); c.stream = null; detachAudio('mic'); return; }
      try { c.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); attachAudio('mic', c.stream); }
      catch (e) { toast('Mic/Aux', 'No microphone available or access was denied.'); }
    }
    function renderMix() {
      const el = $('#ob-mix', root); if (!el) return;
      el.innerHTML = Object.entries(chans).map(([k, c]) => {
        const live = !!c.an;
        const off = k === 'os' ? (cap.stream ? (live ? '' : 'No audio in this capture (Settings → OS audio)') : 'Start OS capture first') : (live ? '' : 'Click to enable');
        return `<div class="ob-ch${live ? '' : ' off'}" data-k="${k}"><div class="ob-ch-h"><b>${c.name}</b><button data-m="mute" title="Mute" class="${c.mute ? 'on' : ''}"><i class="fas ${c.mute ? 'fa-volume-xmark' : 'fa-volume-high'}"></i></button>${k === 'mic' ? `<button data-m="mic" title="${live ? 'Disable' : 'Enable'}"><i class="fas ${live ? 'fa-microphone' : 'fa-microphone-slash'}"></i></button>` : ''}</div>
          <div class="ob-meter"><i></i></div><input type="range" min="0" max="200" value="${c.vol}" data-m="vol"><small>${off || c.vol + '%'}</small></div>`;
      }).join('');
    }
    const buf = new Uint8Array(512);
    function meters() {
      $$('.ob-ch', root).forEach(row => {
        const c = chans[row.dataset.k]; let lv = 0;
        if (c.an && !c.mute) { c.an.getByteTimeDomainData(buf); let m = 0; for (let i = 0; i < buf.length; i++) m = Math.max(m, Math.abs(buf[i] - 128)); lv = Math.min(1, (m / 128) * (c.vol / 100) * 1.6); }
        const i = $('.ob-meter i', row); if (i) i.style.transform = `scaleX(${lv.toFixed(3)})`;
      });
    }
    $('#ob-mix', root).addEventListener('input', e => { const row = e.target.closest('.ob-ch'); if (!row || e.target.dataset.m !== 'vol') return; const k = row.dataset.k; chans[k].vol = +e.target.value; applyGain(k); const sm = $('small', row); if (sm && chans[k].an) sm.textContent = chans[k].vol + '%'; });
    $('#ob-mix', root).addEventListener('click', e => {
      const b = e.target.closest('button'); const row = e.target.closest('.ob-ch'); if (!b || !row) return; const k = row.dataset.k;
      if (b.dataset.m === 'mute') { chans[k].mute = !chans[k].mute; applyGain(k); renderMix(); }
      if (b.dataset.m === 'mic') toggleMic();
    });
    $('#ob-mix', root).addEventListener('click', e => { if (e.target.closest('.ob-ch[data-k="mic"]') && !e.target.closest('button,input') && !chans.mic.an) toggleMic(); });

    /* ---------------- sources: runtime media ---------------- */
    const imgs = {}, cams = {};
    function imgFor(s) {
      let r = imgs[s.id]; if (r && r.src === s.src) return r.img;
      const img = new Image(); img.src = s.src || ''; imgs[s.id] = { src: s.src, img }; return img;
    }
    function camFor(s) {
      let r = cams[s.id];
      if (r && r.dev === (s.dev || '')) return r.video;
      if (r) r.stream && r.stream.getTracks().forEach(t => t.stop());
      const video = document.createElement('video'); video.muted = true; video.playsInline = true;
      r = cams[s.id] = { dev: s.dev || '', video, stream: null };
      navigator.mediaDevices.getUserMedia({ video: s.dev ? { deviceId: { exact: s.dev } } : true }).then(stream => { r.stream = stream; video.srcObject = stream; video.play().catch(() => {}); })
        .catch(() => { r.failed = true; });
      return video;
    }
    const dropRuntime = s => { delete imgs[s.id]; const r = cams[s.id]; if (r) { r.stream && r.stream.getTracks().forEach(t => t.stop()); delete cams[s.id]; } };

    /* ---------------- compositing ---------------- */
    function fitText(s) {
      scratch.font = `${s.bold ? '700 ' : ''}${s.size || 48}px ${s.font || 'Inter, sans-serif'}`;
      const lines = String(s.text || '').split('\n'); let m = 10;
      lines.forEach(l => { m = Math.max(m, scratch.measureText(l).width); });
      s.w = Math.ceil(m + 20); s.h = Math.ceil(lines.length * (s.size || 48) * 1.25 + 14);
    }
    function note(c, s, txt) {
      c.fillStyle = '#16171b'; c.fillRect(s.x, s.y, s.w, s.h);
      c.fillStyle = '#80848e'; c.font = '600 ' + Math.max(14, Math.min(30, s.h / 14)) + 'px Inter, sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.fillText(txt, s.x + s.w / 2, s.y + s.h / 2); c.textAlign = 'left'; c.textBaseline = 'alphabetic';
    }
    function drawMedia(c, s, v) {
      const vw = v.videoWidth || v.naturalWidth || v.width, vh = v.videoHeight || v.naturalHeight || v.height; if (!vw || !vh) return false;
      const sx = vw * (s.cl || 0) / 100, sy = vh * (s.ct || 0) / 100, sw = Math.max(1, vw * (1 - ((s.cl || 0) + (s.cr || 0)) / 100)), sh = Math.max(1, vh * (1 - ((s.ct || 0) + (s.cb || 0)) / 100));
      c.save(); c.beginPath(); c.rect(s.x, s.y, s.w, s.h); c.clip();
      if (s.fit === 'stretch') c.drawImage(v, sx, sy, sw, sh, s.x, s.y, s.w, s.h);
      else { const k = (s.fit === 'fill' ? Math.max : Math.min)(s.w / sw, s.h / sh), dw = sw * k, dh = sh * k; c.drawImage(v, sx, sy, sw, sh, s.x + (s.w - dw) / 2, s.y + (s.h - dh) / 2, dw, dh); }
      c.restore(); return true;
    }
    function drawSrc(c, s) {
      if (!s.vis) return;
      c.save(); c.globalAlpha = (s.op == null ? 100 : s.op) / 100;
      if (s.type === 'os') { if (!(cap.video && drawMedia(c, s, cap.video))) note(c, s, 'OS Capture · press “Start OS Capture”'); }
      else if (s.type === 'cam') { const v = camFor(s); if (!drawMedia(c, s, v)) note(c, s, cams[s.id] && cams[s.id].failed ? 'No camera available' : 'Starting camera…'); }
      else if (s.type === 'image') { const im = imgFor(s); if (!(s.src && im.complete && im.naturalWidth && drawMedia(c, Object.assign({}, s, { fit: s.fit || 'fit' }), im))) note(c, s, s.src ? 'Loading image…' : 'Image · choose a file in Properties'); }
      else if (s.type === 'color') { c.fillStyle = s.color || '#5865f2'; c.fillRect(s.x, s.y, s.w, s.h); }
      else if (s.type === 'text') {
        if (s.bg) { c.globalAlpha *= (s.bgop == null ? 60 : s.bgop) / 100; c.fillStyle = s.bgc || '#000000'; c.fillRect(s.x, s.y, s.w, s.h); c.globalAlpha = (s.op == null ? 100 : s.op) / 100; }
        c.fillStyle = s.color || '#ffffff'; c.font = `${s.bold ? '700 ' : ''}${s.size || 48}px ${s.font || 'Inter, sans-serif'}`; c.textBaseline = 'top';
        String(s.text || '').split('\n').forEach((l, i) => c.fillText(l, s.x + 10, s.y + 7 + i * (s.size || 48) * 1.25));
      }
      c.restore();
    }
    const drawScene = (c, sc) => sc.sources.forEach(s => drawSrc(c, s));
    let trans = null;
    function frame() {
      const { w: cw, h: ch } = st.cfg;
      if (cv.width !== cw || cv.height !== ch) { cv.width = cw; cv.height = ch; layer.width = cw; layer.height = ch; cvw.style.aspectRatio = cw + '/' + ch; $('#ob-s-res', root).textContent = cw + '×' + ch; }
      ctx.fillStyle = '#000'; ctx.fillRect(0, 0, cw, ch);
      const sc = scene();
      const old = trans && st.scenes.find(s => s.id === trans.from);
      if (trans && old) {
        const p = Math.min(1, (performance.now() - trans.t0) / 350);
        drawScene(ctx, old); lctx.clearRect(0, 0, cw, ch); drawScene(lctx, sc);
        ctx.globalAlpha = p; ctx.drawImage(layer, 0, 0); ctx.globalAlpha = 1;
        if (p >= 1) trans = null;
      } else { trans = null; drawScene(ctx, sc); }
      frames++;
    }
    let frames = 0, lastT = performance.now(), fps = 0;
    function statTick() {
      const now = performance.now(); fps = frames * 1000 / (now - lastT); frames = 0; lastT = now;
      $('#ob-s-fps', root).textContent = fps.toFixed(1) + ' fps';
      if (rec.mr) {
        const el = Date.now() - rec.t0 - rec.paused - (rec.pAt ? Date.now() - rec.pAt : 0);
        $('#ob-s-rec', root).innerHTML = `<i class="fas fa-circle ${rec.pAt ? 'pz' : 'live'}"></i> ${rec.pAt ? 'PAUSED' : 'REC'} ${fmtTime(el)}`;
        $('#ob-s-size', root).textContent = fmtSize(rec.bytes);
      }
    }
    let loop = null;
    const startLoop = () => { clearInterval(loop); loop = setInterval(frame, 1000 / st.cfg.fps); }; // timers, not rAF: keeps drawing when the OS window is behind another app

    /* ---------------- recording ---------------- */
    const rec = { mr: null, chunks: [], bytes: 0, t0: 0, paused: 0, pAt: 0, list: [], mime: '' };
    const pickMime = () => (MIMES[st.cfg.fmt] || MIMES.auto).find(m => window.MediaRecorder && MediaRecorder.isTypeSupported(m)) || '';
    async function startRecording() {
      if (rec.mr) return;
      if (!window.MediaRecorder) return toast('OBS Studio', 'Recording is not supported here.');
      if (scene().sources.some(s => s.type === 'os' && s.vis) || st.scenes.some(sc => sc.sources.some(s => s.type === 'os'))) { if (!(await startCapture())) return; }
      const vs = cv.captureStream(st.cfg.fps), tracks = [...vs.getVideoTracks()];
      if (dest && (chans.os.an || chans.mic.an)) tracks.push(...dest.stream.getAudioTracks());
      const mime = pickMime(); rec.mime = mime;
      let mr; try { mr = new MediaRecorder(new MediaStream(tracks), Object.assign({ videoBitsPerSecond: Math.round(st.cfg.mbps * 1e6) }, mime ? { mimeType: mime } : {}, tracks.length > 1 ? { audioBitsPerSecond: 160000 } : {})); }
      catch (e) { return toast('OBS Studio', 'Could not start recording: ' + String(e.message || e).slice(0, 100)); }
      rec.chunks = []; rec.bytes = 0; rec.paused = 0; rec.pAt = 0; rec.t0 = Date.now(); rec.mr = mr;
      mr.ondataavailable = e => { if (e.data && e.data.size) { rec.chunks.push(e.data); rec.bytes += e.data.size; } };
      mr.onstop = () => finishRecording(mr);
      mr.onerror = () => toast('OBS Studio', 'Recording error.');
      mr.start(1000);
      document.body.classList.add('obs-rec'); syncUI();
      if (st.cfg.hide && typeof minimize === 'function') minimize('obs'); // so the recording is the OS itself, not the studio window
      toast('Recording started', st.cfg.hide ? 'OBS Studio is hidden. Ctrl+Shift+R or the red taskbar icon stops it.' : 'Recording the OS only.', 3500);
    }
    function stopRecording() { if (!rec.mr) return; try { if (rec.mr.state !== 'inactive') rec.mr.stop(); } catch {} }
    function finishRecording(mr) {
      if (rec.mr !== mr) return;
      const type = (rec.mime || 'video/webm').split(';')[0], ext = type.includes('mp4') ? 'mp4' : 'webm';
      const blob = new Blob(rec.chunks, { type }), item = { name: 'Cine-OS ' + stamp() + '.' + ext, blob, url: URL.createObjectURL(blob), dur: Date.now() - rec.t0 - rec.paused, at: Date.now() };
      rec.mr = null; rec.chunks = []; rec.pAt = 0; document.body.classList.remove('obs-rec');
      rec.list.unshift(item); syncUI();
      $('#ob-s-rec', root).innerHTML = '<i class="fas fa-circle"></i> REC 00:00:00';
      toast('Recording saved', item.name + ' · ' + fmtSize(blob.size) + (st.cfg.autosave ? ' · saving…' : ''), 5000);
      if (st.cfg.autosave) download(item);
    }
    function download(item) { const a = document.createElement('a'); a.href = item.url; a.download = item.name; document.body.append(a); a.click(); a.remove(); }
    function togglePause() {
      if (!rec.mr) return;
      if (rec.mr.state === 'recording') { rec.mr.pause(); rec.pAt = Date.now(); }
      else if (rec.mr.state === 'paused') { rec.mr.resume(); rec.paused += Date.now() - rec.pAt; rec.pAt = 0; }
      syncUI();
    }
    function screenshot() {
      cv.toBlob(b => { if (!b) return; const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'Cine-OS ' + stamp() + '.png'; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); toast('Screenshot saved', a.download, 3000); }, 'image/png');
    }

    /* ---------------- UI sync ---------------- */
    function syncUI() {
      const on = !!rec.mr;
      const rb = $('#ob-rec', root); rb.classList.toggle('on', on); $('span', rb).textContent = on ? 'Stop Recording' : 'Start Recording'; $('i', rb).className = 'fas ' + (on ? 'fa-stop' : 'fa-circle');
      const pb = $('#ob-pause', root); pb.disabled = !on; const paused = on && rec.mr.state === 'paused'; $('span', pb).textContent = paused ? 'Resume Recording' : 'Pause Recording'; $('i', pb).className = 'fas ' + (paused ? 'fa-play' : 'fa-pause');
      $('#ob-cap-t', root).textContent = cap.stream ? 'Stop OS Capture' : 'Start OS Capture';
      const chip = $('#ob-chip', root); chip.textContent = on ? (paused ? 'Paused' : 'Recording') : cap.stream ? 'Capturing OS' : 'Ready'; chip.className = 'ob-chip' + (on ? ' rec' : cap.stream ? ' cap' : '');
      $('#ob-rn', root).textContent = rec.list.length ? rec.list.length : '';
      renderMix();
    }
    function renderScenes() {
      $('#ob-scenes', root).innerHTML = st.scenes.map(s => `<li data-id="${s.id}" class="${s.id === st.cur ? 'on' : ''}">${esc(s.name)}</li>`).join('');
    }
    function renderSrcs() {
      const sc = scene(), el = $('#ob-srcs', root);
      el.innerHTML = [...sc.sources].reverse().map(s => `<li data-id="${s.id}" class="${s.id === st.sel ? 'on' : ''}"><i class="fas ${TYPES[s.type][1]} ty"></i><span>${esc(s.name)}</span>
        <button data-v="lock" title="Lock" class="${s.lock ? 'on' : ''}"><i class="fas ${s.lock ? 'fa-lock' : 'fa-lock-open'}"></i></button><button data-v="vis" title="Show / hide" class="${s.vis ? '' : 'off'}"><i class="fas ${s.vis ? 'fa-eye' : 'fa-eye-slash'}"></i></button></li>`).join('') || '<li class="empty">No sources. Press + to add one.</li>';
      renderOv();
    }
    function renderOv() {
      const s = selSrc(); ov.innerHTML = '';
      if (!s) return;
      const b = document.createElement('div'); b.className = 'ob-sel' + (s.lock ? ' lock' : '');
      b.style.cssText = `left:${s.x / st.cfg.w * 100}%;top:${s.y / st.cfg.h * 100}%;width:${s.w / st.cfg.w * 100}%;height:${s.h / st.cfg.h * 100}%`;
      if (!s.lock) b.innerHTML = '<i class="h" data-h="1"></i>';
      ov.append(b);
    }

    /* ---------------- preview interaction (select / move / resize) ---------------- */
    let drag = null;
    const toCanvas = e => { const r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left) * cv.width / r.width, y: (e.clientY - r.top) * cv.height / r.height, k: cv.width / r.width }; };
    ov.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      const p = toCanvas(e), sc = scene(), cur = selSrc();
      if (e.target.dataset.h && cur && !cur.lock) { drag = { mode: 'size', s: cur, p, o: { w: cur.w, h: cur.h, r: cur.w / cur.h } }; }
      else {
        const hit = [...sc.sources].reverse().find(s => s.vis && p.x >= s.x && p.x <= s.x + s.w && p.y >= s.y && p.y <= s.y + s.h);
        st.sel = hit ? hit.id : null; renderSrcs();
        if (hit && !hit.lock) drag = { mode: 'move', s: hit, p, o: { x: hit.x, y: hit.y } };
      }
      if (drag) { ov.setPointerCapture(e.pointerId); e.preventDefault(); }
    });
    ov.addEventListener('pointermove', e => {
      if (!drag) return; const p = toCanvas(e), s = drag.s, dx = p.x - drag.p.x, dy = p.y - drag.p.y;
      if (drag.mode === 'move') { s.x = Math.round(drag.o.x + dx); s.y = Math.round(drag.o.y + dy); }
      else { const keep = s.type !== 'color' && s.type !== 'text' ? !e.shiftKey : e.shiftKey; s.w = Math.max(16, Math.round(drag.o.w + dx)); s.h = keep ? Math.max(16, Math.round(s.w / drag.o.r)) : Math.max(16, Math.round(drag.o.h + dy)); }
      renderOv();
    });
    const endDrag = () => { if (drag) { drag = null; save(); } };
    ov.addEventListener('pointerup', endDrag); ov.addEventListener('pointercancel', endDrag);
    ov.addEventListener('dblclick', () => { const s = selSrc(); if (s) props(s); });

    /* ---------------- modals ---------------- */
    function modal(title, body, onMount, cls = '') {
      const m = document.createElement('div'); m.className = 'ob-modal';
      m.innerHTML = `<div class="ob-mbox ${cls}" role="dialog" aria-label="${esc(title)}"><header><b>${esc(title)}</b><button class="ob-x" title="Close"><i class="fas fa-xmark"></i></button></header><div class="ob-mb">${body}</div></div>`;
      root.append(m); const close = () => { m.remove(); }; $('.ob-x', m).onclick = close; m.addEventListener('mousedown', e => { if (e.target === m) close(); });
      onMount && onMount($('.ob-mb', m), close); return close;
    }
    function ask(title, value, ok) {
      modal(title, `<form class="ob-form"><input class="ob-in" value="${esc(value)}" maxlength="40" autofocus><div class="ob-act"><button class="btn" type="submit">OK</button></div></form>`, (b, close) => {
        const i = $('input', b); setTimeout(() => { i.focus(); i.select(); }, 30);
        $('form', b).onsubmit = e => { e.preventDefault(); const v = i.value.trim(); if (v) { close(); ok(v); } };
      });
    }
    const uniqName = (base, list) => { let n = base, i = 2; while (list.some(x => x.name === n)) n = base + ' ' + i++; return n; };
    function addSource(type) {
      const sc = scene(), { w: cw, h: ch } = st.cfg, name = uniqName(TYPES[type][0], sc.sources);
      const base = { id: uid(), type, name, x: 0, y: 0, w: cw, h: ch, vis: true, lock: false, op: 100 };
      const s = Object.assign(base, type === 'os' ? { fit: 'fit', cl: 0, ct: 0, cr: 0, cb: 0 }
        : type === 'cam' ? { fit: 'fit', w: Math.round(cw / 3), h: Math.round(ch / 3), x: cw - Math.round(cw / 3) - 20, y: ch - Math.round(ch / 3) - 20, cl: 0, ct: 0, cr: 0, cb: 0, dev: '' }
        : type === 'image' ? { fit: 'fit', src: '', w: Math.round(cw / 3), h: Math.round(ch / 3), x: 40, y: 40, cl: 0, ct: 0, cr: 0, cb: 0 }
        : type === 'color' ? { color: '#5865f2' }
        : { text: 'Hello from Cine OS', size: 64, color: '#ffffff', bold: true, font: 'Inter, sans-serif', bg: false, bgc: '#000000', bgop: 60, x: 60, y: 60 });
      if (type === 'text') fitText(s);
      sc.sources.push(s); st.sel = s.id; save(); renderSrcs();
      if (type === 'os') startCapture(); else props(s);
    }
    function props(s) {
      const F = (k, label, type, extra = '') => `<label class="ob-f"><span>${label}</span><input class="ob-in" data-k="${k}" type="${type}" ${extra}></label>`;
      const sel = (k, label, opts) => `<label class="ob-f"><span>${label}</span><select class="ob-in" data-k="${k}">${opts.map(o => `<option value="${esc(o[0])}">${esc(o[1])}</option>`).join('')}</select></label>`;
      let html = F('name', 'Name', 'text', 'maxlength="40"');
      if (s.type === 'image') html += `<label class="ob-f"><span>Image file</span><input class="ob-in" data-file="1" type="file" accept="image/*"></label>`;
      if (s.type === 'color') html += F('color', 'Color', 'color');
      if (s.type === 'text') html += `<label class="ob-f"><span>Text</span><textarea class="ob-in" data-k="text" rows="3"></textarea></label>` + F('size', 'Size (px)', 'number', 'min="8" max="400"') + F('color', 'Color', 'color')
        + sel('font', 'Font', [['Inter, sans-serif', 'Inter'], ['Georgia, serif', 'Serif'], ['"Courier New", monospace', 'Monospace'], ['Impact, sans-serif', 'Impact']]) + `<label class="ob-f chk"><input data-k="bold" type="checkbox"><span>Bold</span></label><label class="ob-f chk"><input data-k="bg" type="checkbox"><span>Background</span></label>` + F('bgc', 'Background color', 'color') + F('bgop', 'Background opacity', 'range', 'min="0" max="100"');
      if (s.type === 'os' || s.type === 'cam' || s.type === 'image') html += sel('fit', 'Scaling', [['fit', 'Fit inside box'], ['fill', 'Fill box (crop)'], ['stretch', 'Stretch']])
        + `<div class="ob-grid4">${F('cl', 'Crop left %', 'number', 'min="0" max="90"')}${F('ct', 'Crop top %', 'number', 'min="0" max="90"')}${F('cr', 'Crop right %', 'number', 'min="0" max="90"')}${F('cb', 'Crop bottom %', 'number', 'min="0" max="90"')}</div>`;
      if (s.type === 'cam') html += sel('dev', 'Camera', [['', 'Default camera']]);
      html += `<div class="ob-grid4">${F('x', 'X', 'number')}${F('y', 'Y', 'number')}${s.type === 'text' ? '' : F('w', 'Width', 'number', 'min="16"')}${s.type === 'text' ? '' : F('h', 'Height', 'number', 'min="16"')}</div>` + F('op', 'Opacity', 'range', 'min="0" max="100"');
      if (s.type === 'os') html += `<div class="ob-note"><i class="fas fa-shield-halved"></i>This source captures only the Cine/Figure OS window. Your desktop and other apps are never offered.</div>`;
      modal('Properties for “' + s.name + '”', `<div class="ob-form">${html}</div>`, (b, close) => {
        $$('[data-k]', b).forEach(i => { const v = s[i.dataset.k]; if (i.type === 'checkbox') i.checked = !!v; else i.value = v == null ? '' : v; });
        const numeric = new Set(['x', 'y', 'w', 'h', 'op', 'size', 'bgop', 'cl', 'ct', 'cr', 'cb']);
        const upd = i => {
          const k = i.dataset.k; let v = i.type === 'checkbox' ? i.checked : i.value;
          if (numeric.has(k)) { v = parseFloat(v); if (!isFinite(v)) return; }
          s[k] = v; if (k === 'name') { if (!String(v).trim()) s.name = TYPES[s.type][0]; renderSrcs(); } if (s.type === 'text' && ['text', 'size', 'bold', 'font'].includes(k)) fitText(s);
          save(); renderOv();
        };
        b.addEventListener('input', e => { if (e.target.dataset.k) upd(e.target); });
        b.addEventListener('change', e => { if (e.target.dataset.k) upd(e.target); });
        const f = $('[data-file]', b);
        if (f) f.onchange = () => { const file = f.files && f.files[0]; if (!file) return; const rd = new FileReader(); rd.onload = () => { const im = new Image(); im.onload = () => {
          const k = Math.min(1, 1600 / Math.max(im.naturalWidth, im.naturalHeight)), c = document.createElement('canvas'); c.width = Math.round(im.naturalWidth * k); c.height = Math.round(im.naturalHeight * k); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
          s.src = c.toDataURL(file.type === 'image/png' ? 'image/png' : 'image/jpeg', .9); const r = Math.min(st.cfg.w * .6 / c.width, st.cfg.h * .6 / c.height); s.w = Math.round(c.width * r); s.h = Math.round(c.height * r); save(); renderOv(); $$('[data-k="w"]', b).forEach(i => i.value = s.w); $$('[data-k="h"]', b).forEach(i => i.value = s.h); }; im.src = rd.result; }; rd.readAsDataURL(file); };
        if (s.type === 'cam' && navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
          const dv = $('[data-k="dev"]', b);
          navigator.mediaDevices.enumerateDevices().then(l => { l.filter(d => d.kind === 'videoinput').forEach((d, n) => dv.append(new Option(d.label || 'Camera ' + (n + 1), d.deviceId))); dv.value = s.dev || ''; }).catch(() => {});
        }
      });
    }
    function settings() {
      const c = st.cfg;
      modal('Settings', `<div class="ob-form">
        <label class="ob-f"><span>Canvas / output resolution</span><select class="ob-in" data-c="res"><option value="1920x1080">1920 × 1080</option><option value="1280x720">1280 × 720</option><option value="854x480">854 × 480</option><option value="2560x1440">2560 × 1440</option></select></label>
        <label class="ob-f"><span>Frame rate</span><select class="ob-in" data-c="fps"><option>24</option><option>30</option><option>60</option></select></label>
        <label class="ob-f"><span>Video bitrate (Mbps)</span><input class="ob-in" data-c="mbps" type="number" min="1" max="50" step="0.5"></label>
        <label class="ob-f"><span>Recording format</span><select class="ob-in" data-c="fmt"><option value="auto">Automatic</option><option value="webm">WebM</option><option value="mp4">MP4 (if supported)</option></select></label>
        <label class="ob-f chk"><input data-c="hide" type="checkbox"><span>Hide OBS Studio when recording starts</span></label>
        <label class="ob-f chk"><input data-c="autosave" type="checkbox"><span>Save the file when recording stops</span></label>
        <label class="ob-f chk"><input data-c="osAudio" type="checkbox"><span>Capture OS audio <em>${desktop ? '(desktop app: this records all PC sound, not just the OS)' : '(browser: tab audio)'}</em></span></label>
        <div class="ob-note"><i class="fas fa-circle-info"></i>Changing OS audio applies the next time OS capture starts. Resolution changes resize the canvas; sources keep their positions.</div></div>`, b => {
        $('[data-c="res"]', b).value = c.w + 'x' + c.h; $('[data-c="fps"]', b).value = c.fps; $('[data-c="mbps"]', b).value = c.mbps; $('[data-c="fmt"]', b).value = c.fmt;
        ['hide', 'autosave', 'osAudio'].forEach(k => { $('[data-c="' + k + '"]', b).checked = !!c[k]; });
        b.addEventListener('change', e => {
          const k = e.target.dataset.c; if (!k) return; if (rec.mr && (k === 'res' || k === 'fps')) { toast('OBS Studio', 'Stop recording to change this.'); return syncCfg(b); }
          if (k === 'res') { const [nw, nh] = e.target.value.split('x').map(Number), kx = nw / c.w, ky = nh / c.h; st.scenes.forEach(sc => sc.sources.forEach(s => { s.x = Math.round(s.x * kx); s.y = Math.round(s.y * ky); if (s.type !== 'text') { s.w = Math.round(s.w * kx); s.h = Math.round(s.h * ky); } })); c.w = nw; c.h = nh; renderOv(); }
          else if (k === 'fps') { c.fps = +e.target.value; startLoop(); }
          else if (k === 'mbps') c.mbps = Math.min(50, Math.max(1, parseFloat(e.target.value) || 6));
          else if (k === 'fmt') c.fmt = e.target.value;
          else c[k] = e.target.checked;
          save();
        });
      });
      function syncCfg(b) { $('[data-c="res"]', b).value = c.w + 'x' + c.h; $('[data-c="fps"]', b).value = c.fps; }
    }
    function recordings() {
      modal('Recordings', '<div class="ob-recs"></div>', b => {
        const draw = () => {
          $('.ob-recs', b).innerHTML = rec.list.length ? rec.list.map((r, i) => `<div class="ob-rc" data-i="${i}"><video src="${r.url}" controls preload="metadata"></video><div><strong>${esc(r.name)}</strong><small>${fmtTime(r.dur)} · ${fmtSize(r.blob.size)}</small>
            <div class="ob-act"><button class="btn" data-r="save"><i class="fas fa-download"></i>Save</button><button class="btn ghost" data-r="del"><i class="fas fa-trash"></i>Delete</button></div></div></div>`).join('')
            : '<div class="ob-empty"><i class="fas fa-film"></i><span>No recordings yet. Press Start Recording.</span><small>Recordings stay here until you close OBS Studio, so save the ones you want to keep.</small></div>';
        };
        draw();
        b.addEventListener('click', e => { const bt = e.target.closest('[data-r]'); if (!bt) return; const i = +bt.closest('.ob-rc').dataset.i, r = rec.list[i]; if (bt.dataset.r === 'save') download(r); else { URL.revokeObjectURL(r.url); rec.list.splice(i, 1); draw(); syncUI(); } });
      }, 'wide');
    }

    /* ---------------- buttons ---------------- */
    root.addEventListener('click', e => {
      const sl = e.target.closest('#ob-scenes li'), sr = e.target.closest('#ob-srcs li');
      if (sl) { const id = sl.dataset.id; if (id !== st.cur) { if (st.cfg.trans === 'fade') trans = { from: st.cur, t0: performance.now() }; st.cur = id; st.sel = null; save(); renderScenes(); renderSrcs(); } return; }
      if (sr && sr.dataset.id) {
        const s = scene().sources.find(x => x.id === sr.dataset.id), v = e.target.closest('button[data-v]');
        if (s && v) { if (v.dataset.v === 'vis') s.vis = !s.vis; else s.lock = !s.lock; save(); renderSrcs(); return; }
        st.sel = sr.dataset.id; renderSrcs(); return;
      }
      const b = e.target.closest('[data-a]'); if (!b) return; const a = b.dataset.a, sc = scene();
      if (a === 'rec') rec.mr ? stopRecording() : startRecording();
      else if (a === 'pause') togglePause();
      else if (a === 'cap') cap.stream ? stopCapture() : startCapture();
      else if (a === 'shot') screenshot();
      else if (a === 'recs') recordings();
      else if (a === 'cfg') settings();
      else if (a === 'scene-add') ask('Scene name', uniqName('Scene', st.scenes), n => { st.scenes.push({ id: uid(), name: uniqName(n, st.scenes), sources: [] }); st.cur = st.scenes[st.scenes.length - 1].id; st.sel = null; save(); renderScenes(); renderSrcs(); });
      else if (a === 'scene-del') { if (st.scenes.length < 2) return toast('OBS Studio', 'You need at least one scene.'); sc.sources.forEach(dropRuntime); st.scenes = st.scenes.filter(s => s !== sc); st.cur = st.scenes[0].id; st.sel = null; save(); renderScenes(); renderSrcs(); }
      else if (a === 'scene-up' || a === 'scene-down') { const i = st.scenes.indexOf(sc), j = i + (a === 'scene-up' ? -1 : 1); if (j >= 0 && j < st.scenes.length) { [st.scenes[i], st.scenes[j]] = [st.scenes[j], st.scenes[i]]; save(); renderScenes(); } }
      else if (a === 'src-add') {
        const r = b.getBoundingClientRect();
        modal('Add source', `<div class="ob-add">${Object.entries(TYPES).map(([k, t]) => `<button data-t="${k}"><i class="fas ${t[1]}"></i><span>${t[0]}</span></button>`).join('')}</div>`, (m, close) => { m.onclick = ev => { const t = ev.target.closest('[data-t]'); if (t) { close(); addSource(t.dataset.t); } }; });
      }
      else if (a === 'src-del') { const s = selSrc(); if (!s) return; dropRuntime(s); sc.sources = sc.sources.filter(x => x !== s); st.sel = null; save(); renderSrcs(); }
      else if (a === 'src-props') { const s = selSrc(); if (s) props(s); }
      else if (a === 'src-up' || a === 'src-down') { const s = selSrc(); if (!s) return; const i = sc.sources.indexOf(s), j = i + (a === 'src-up' ? 1 : -1); if (j >= 0 && j < sc.sources.length) { [sc.sources[i], sc.sources[j]] = [sc.sources[j], sc.sources[i]]; save(); renderSrcs(); } }
    });
    root.addEventListener('dblclick', e => {
      const sl = e.target.closest('#ob-scenes li'); if (sl) { const s = st.scenes.find(x => x.id === sl.dataset.id); ask('Rename scene', s.name, n => { s.name = n; save(); renderScenes(); }); return; }
      const sr = e.target.closest('#ob-srcs li'); if (sr && sr.dataset.id && !e.target.closest('button')) { const s = scene().sources.find(x => x.id === sr.dataset.id); if (s) props(s); }
    });
    $('#ob-trans', root).value = st.cfg.trans;
    $('#ob-trans', root).onchange = e => { st.cfg.trans = e.target.value; save(); };

    // hotkeys (only while the OS is focused): Ctrl+Shift+R record, Ctrl+Shift+P pause
    const keys = e => {
      if (!(e.ctrlKey || e.metaKey) || !e.shiftKey || !w.el.isConnected) return;
      const k = e.key.toLowerCase();
      if (k === 'r') { e.preventDefault(); rec.mr ? stopRecording() : startRecording(); }
      if (k === 'p' && rec.mr) { e.preventDefault(); togglePause(); }
    };
    addEventListener('keydown', keys, true);

    w.onclose = () => {
      removeEventListener('keydown', keys, true);
      clearInterval(loop); clearInterval(tick);
      if (rec.mr) { try { rec.mr.onstop = null; rec.mr.stop(); } catch {} const had = rec.chunks.length; if (had && st.cfg.autosave) { const blob = new Blob(rec.chunks, { type: (rec.mime || 'video/webm').split(';')[0] }); download({ url: URL.createObjectURL(blob), name: 'Cine-OS ' + stamp() + (blob.type.includes('mp4') ? '.mp4' : '.webm') }); } rec.mr = null; document.body.classList.remove('obs-rec'); }
      if (cap.stream) cap.stream.getTracks().forEach(t => t.stop());
      if (chans.mic.stream) chans.mic.stream.getTracks().forEach(t => t.stop());
      Object.values(cams).forEach(r => r.stream && r.stream.getTracks().forEach(t => t.stop()));
      rec.list.forEach(r => URL.revokeObjectURL(r.url));
      try { ac && ac.close(); } catch {}
    };
    // exposed for tests / Visual Code tinkering
    w.obs = { st, rec, cap, startRecording, stopRecording, startCapture, addSource, frame };

    renderScenes(); renderSrcs(); syncUI(); startLoop();
    const tick = setInterval(() => { statTick(); meters(); }, 250);
  },
});
