// Cine/Figure OS - shell: boot, lock, dock, start menu, drawer, windows, wallpapers
const wins = {};

/* ---------- wallpapers ---------- */
// five painted scenes, built as SVG so they stay sharp at any size
const rng = seed => { let s = seed; return () => (s = (s * 16807) % 2147483647) / 2147483647; };
const svgWall = body => `url("data:image/svg+xml,${encodeURIComponent(`<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1600 900' preserveAspectRatio='xMidYMid slice'>${body}</svg>`)}") center/cover no-repeat`;
const starField = (n, seed, h = 900, big = 1.7) => { const r = rng(seed); let o = ''; for (let i = 0; i < n; i++) o += `<circle cx='${(r() * 1600) | 0}' cy='${(r() * h) | 0}' r='${(0.4 + r() * big).toFixed(1)}' fill='#fff' opacity='${(0.2 + r() * 0.8).toFixed(2)}'/>`; return o; };
const ridge = (seed, y0, amp, fill, steps = 36) => { const r = rng(seed); let d = 'M0 900 L0 ' + y0; for (let i = 0; i <= steps; i++) { const x = (1600 / steps) * i; d += ` L${x.toFixed(0)} ${(y0 - amp * (0.35 * Math.sin(i * 0.55 + seed) + 0.65 * r())).toFixed(0)}`; } return `<path d='${d} L1600 900 Z' fill='${fill}'/>`; };
const pineRow = (n, seed, base, hMin, hMax, fill) => { const r = rng(seed); let o = ''; for (let i = 0; i < n; i++) { const x = r() * 1700 - 50, h = hMin + r() * (hMax - hMin), w = h * 0.3, y = k => (base - h * k).toFixed(0), X = k => (x + w * k).toFixed(0);
  o += `<polygon fill='${fill}' points='${X(0)},${y(1)} ${X(.45)},${y(.62)} ${X(.22)},${y(.62)} ${X(.7)},${y(.32)} ${X(.4)},${y(.32)} ${X(1)},${base} ${X(-1)},${base} ${X(-.4)},${y(.32)} ${X(-.7)},${y(.32)} ${X(-.22)},${y(.62)} ${X(-.45)},${y(.62)}'/>`; } return o; };
const stripes = (() => { let o = ''; for (let i = 0; i < 9; i++) o += `<rect x='500' y='${470 + i * 26}' width='600' height='${4 + i * 2.6}' fill='#000'/>`; return o; })();
const gridLines = (() => { let o = ''; for (let i = 1; i < 12; i++) o += `<line x1='0' x2='1600' y1='${(560 + i * i * 2.6).toFixed(0)}' y2='${(560 + i * i * 2.6).toFixed(0)}'/>`; for (let i = -9; i <= 9; i++) o += `<line x1='800' y1='560' x2='${800 + i * 300}' y2='900'/>`; return o; })();
const moonGlints = (() => { const r = rng(5); let o = ''; for (let i = 0; i < 26; i++) { const wd = 150 - i * 4.2 + r() * 20; o += `<rect x='${(1150 - wd / 2 + (r() - .5) * 30).toFixed(0)}' y='${(575 + i * 12.5).toFixed(0)}' width='${wd.toFixed(0)}' height='3' rx='1.5' fill='#f4f1de' opacity='${(0.75 - i * 0.025).toFixed(2)}'/>`; } return o; })();
const SCENES = {
  galaxy: svgWall(`<defs><radialGradient id='a'><stop offset='0' stop-color='#8a4bff' stop-opacity='.7'/><stop offset='1' stop-color='#8a4bff' stop-opacity='0'/></radialGradient><radialGradient id='b'><stop offset='0' stop-color='#17c3d6' stop-opacity='.5'/><stop offset='1' stop-color='#17c3d6' stop-opacity='0'/></radialGradient><radialGradient id='c'><stop offset='0' stop-color='#ff4fa3' stop-opacity='.45'/><stop offset='1' stop-color='#ff4fa3' stop-opacity='0'/></radialGradient></defs>
    <rect width='1600' height='900' fill='#04020d'/><ellipse cx='520' cy='360' rx='700' ry='230' fill='url(#a)' transform='rotate(-24 520 360)'/><ellipse cx='1120' cy='560' rx='620' ry='200' fill='url(#b)' transform='rotate(-24 1120 560)'/><ellipse cx='840' cy='470' rx='420' ry='120' fill='url(#c)' transform='rotate(-24 840 470)'/>${starField(520, 7)}${starField(40, 21, 900, 3)}`),
  sunset: svgWall(`<defs><linearGradient id='s' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#140b3a'/><stop offset='.45' stop-color='#6a2a74'/><stop offset='.72' stop-color='#ff6f59'/><stop offset='1' stop-color='#ffd08a'/></linearGradient><radialGradient id='g'><stop offset='0' stop-color='#fff1b8' stop-opacity='.9'/><stop offset='1' stop-color='#ff9a5a' stop-opacity='0'/></radialGradient></defs>
    <rect width='1600' height='900' fill='url(#s)'/>${starField(90, 3, 380, 1.2)}<circle cx='800' cy='560' r='330' fill='url(#g)'/><circle cx='800' cy='560' r='120' fill='#fff3c4'/>${ridge(11, 600, 120, '#7a3170')}${ridge(23, 680, 150, '#4a1f55')}${ridge(37, 770, 160, '#241039')}`),
  moon: svgWall(`<defs><linearGradient id='k' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#040818'/><stop offset='1' stop-color='#15386a'/></linearGradient><linearGradient id='w' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#123a6b'/><stop offset='1' stop-color='#030a18'/></linearGradient><radialGradient id='m'><stop offset='0' stop-color='#cfe3ff' stop-opacity='.55'/><stop offset='1' stop-color='#cfe3ff' stop-opacity='0'/></radialGradient></defs>
    <rect width='1600' height='560' fill='url(#k)'/>${starField(260, 9, 540, 1.3)}<circle cx='1150' cy='220' r='320' fill='url(#m)'/><circle cx='1150' cy='220' r='70' fill='#f4f1de'/><circle cx='1128' cy='204' r='13' fill='#dcd7bd'/><circle cx='1172' cy='238' r='9' fill='#dcd7bd'/>
    <rect y='560' width='1600' height='340' fill='url(#w)'/>${moonGlints}${ridge(5, 565, 40, '#050c1c', 50)}`),
  synth: svgWall(`<defs><linearGradient id='y' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#120029'/><stop offset='.6' stop-color='#5a0f6e'/><stop offset='1' stop-color='#ff3d81'/></linearGradient><linearGradient id='u' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#ffe14d'/><stop offset='1' stop-color='#ff2d86'/></linearGradient><mask id='mk'><rect width='1600' height='900' fill='#fff'/>${stripes}</mask></defs>
    <rect width='1600' height='560' fill='url(#y)'/>${starField(120, 4, 420, 1.2)}<circle cx='800' cy='470' r='230' fill='url(#u)' mask='url(#mk)'/>${ridge(14, 560, 90, '#1a0436', 30)}
    <rect y='560' width='1600' height='340' fill='#10002a'/><g stroke='#ff3d81' stroke-width='2' opacity='.75'>${gridLines}</g><rect y='560' width='1600' height='6' fill='#ff7ab0' opacity='.7'/>`),
  northern: svgWall(`<defs><linearGradient id='n' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#02060f'/><stop offset='1' stop-color='#0b2234'/></linearGradient><linearGradient id='r' gradientUnits='userSpaceOnUse' x1='0' x2='1600' y1='0' y2='0'><stop offset='0' stop-color='#37ff9a'/><stop offset='.5' stop-color='#22d3ee'/><stop offset='1' stop-color='#a855f7'/></linearGradient><filter id='f' x='-20%' y='-50%' width='140%' height='200%'><feGaussianBlur stdDeviation='34'/></filter></defs>
    <rect width='1600' height='900' fill='url(#n)'/>${starField(300, 13, 700, 1.4)}<g filter='url(#f)' fill='none' stroke='url(#r)' stroke-linecap='round'><path d='M-100 380 C300 130 620 470 920 230 S1400 110 1700 310' stroke-width='110' opacity='.75'/><path d='M-100 520 C260 330 640 600 980 380 S1420 300 1700 470' stroke-width='70' opacity='.5'/><path d='M200 250 C520 60 860 300 1180 120' stroke-width='50' opacity='.4'/></g>
    <rect y='720' width='1600' height='180' fill='#03121a'/>${pineRow(46, 31, 790, 170, 300, '#04141c')}${pineRow(34, 77, 900, 240, 420, '#010608')}`),
};
const WALLS = [
  { id: 'rainforest', name: 'Rainforest (animated)', css: '#02130a' },
  { id: 'aurora', name: 'Aurora', css: 'linear-gradient(120deg,#05060f,#10224d,#0b4a52,#2a0f4d,#05060f)', anim: 1 },
  { id: 'ember', name: 'Ember', css: 'linear-gradient(120deg,#0a0204,#3a0a12,#7a1f10,#2b0614,#0a0204)', anim: 1 },
  { id: 'leaf', name: 'Deep Forest', css: 'radial-gradient(circle at 30% 20%,#1d6b3a,transparent 45%),radial-gradient(circle at 75% 70%,#0c3d26,transparent 50%),#02130a' },
  { id: 'void', name: 'Void', css: 'radial-gradient(circle at 50% 40%,#1a1a24,#000 70%)' },
  { id: 'neon', name: 'Neon Grid', css: 'linear-gradient(120deg,#0a0014,#26004d,#003d5c,#14002b,#0a0014)', anim: 1 },
  { id: 'dusk', name: 'Dusk', css: 'linear-gradient(180deg,#0b0d1f,#2a1b4a 55%,#6b2c4d)' },
  { id: 'galaxy', name: 'Galaxy', css: SCENES.galaxy },
  { id: 'sunset', name: 'Sunset Peaks', css: SCENES.sunset },
  { id: 'moon', name: 'Moonlit Sea', css: SCENES.moon },
  { id: 'synth', name: 'Synthwave', css: SCENES.synth },
  { id: 'northern', name: 'Northern Lights', css: SCENES.northern },
  { id: 'cinematic', name: 'Cinematic (video)', css: 'url("wallpapers/cinematic.jpg") center/cover no-repeat', video: 'wallpapers/cinematic.mp4' },
];
function wallCss(id) {
  if (id && id.startsWith('data:')) return { css: `url(${id})`, anim: 0 };
  const w = WALLS.find(x => x.id === id) || WALLS[0];
  return { css: w.css, anim: w.anim, video: w.video };
}
// video wallpapers: a muted, looping <video> inside #bg / #lock-bg (the poster image is the CSS background underneath)
function setWallVideo(el, src) {
  let v = el.querySelector('video.wp-vid');
  if (!src) { if (v) v.remove(); return; }
  if (!v) {
    v = document.createElement('video'); v.className = 'wp-vid';
    v.muted = true; v.loop = true; v.autoplay = true; v.playsInline = true; v.disablePictureInPicture = true; v.setAttribute('muted', '');
    el.prepend(v);
  }
  if (v.getAttribute('src') !== src) v.src = src;
}
// play the video only while it is on screen and "Optimized Background" is off
function wallVideoState() {
  for (const [sel, lockSide] of [['#bg', false], ['#lock-bg', true]]) {
    const v = document.querySelector(sel + ' video.wp-vid'); if (!v) continue;
    let lk = true; try { lk = locked; } catch {}
    const shouldPlay = !settings.optBg && lk === lockSide && !document.hidden;
    if (shouldPlay) v.play().catch(() => {}); else v.pause();
  }
}
document.addEventListener('visibilitychange', wallVideoState);
const WP_DEF = { home: 'rainforest', lock: 'rainforest' };
function applyWalls() {
  const wp = LS.get('wp2', WP_DEF);
  for (const [sel, id] of [['#bg', wp.home], ['#lock-bg', wp.lock]]) {
    const el = $(sel), w = wallCss(id);
    el.style.background = w.css;
    el.style.backgroundSize = w.anim ? '' : 'cover';
    el.style.backgroundPosition = 'center';
    el.classList.toggle('anim', !!w.anim);
    setWallVideo(el, w.video);
  }
  fxSet(wp);
  wallVideoState();
}
function pickWall(id, mode) {
  const wp = LS.get('wp2', WP_DEF);
  if (mode !== 'lock') wp.home = id;
  if (mode !== 'home') wp.lock = id;
  LS.set('wp2', wp); applyWalls();
}
// fills a grid element with wallpaper tiles (used by the wallpaper popup and by Config > Personalization)
function fillWallGrid(grid, getMode) {
  grid.innerHTML = '';
  const wp = LS.get('wp2', WP_DEF);
  const add = (id, css, label) => {
    const t = document.createElement('div'); t.className = 'wp-tile';
    t.style.background = css; t.style.backgroundSize = 'cover'; t.style.backgroundPosition = 'center';
    const on = [wp.home === id && 'Home', wp.lock === id && 'Lock'].filter(Boolean).join(' + ');
    t.classList.toggle('sel', !!on); t.innerHTML = `<span>${esc(label)}</span>${on ? `<em>${on}</em>` : ''}`;
    t.onclick = () => { pickWall(id, getMode()); fillWallGrid(grid, getMode); };
    grid.append(t);
  };
  WALLS.forEach(w => add(w.id, w.css, w.name));
  const custom = LS.get('customWall');
  if (custom) add(custom, `url(${custom})`, 'Your image');
}
function readWallFile(file, done) {
  if (!file) return;
  const r = new FileReader();
  r.onload = () => {
    if (r.result.length > 3.5e6) return toast('Image too large', 'Pick one under ~2.5 MB.');
    LS.set('customWall', r.result); done();
  };
  r.readAsDataURL(file);
}
function openWallpaperMenu() {
  const refresh = () => fillWallGrid($('#wp-grid'), () => ($('input[name=wpm]:checked') || {}).value || 'both');
  refresh(); $('#wp-menu').classList.add('open');
}
$('#wp-close').onclick = () => $('#wp-menu').classList.remove('open');
$('#wp-file').onchange = e => readWallFile(e.target.files[0], openWallpaperMenu);

/* ---------- settings side effects ---------- */
function applySettings() {
  document.body.classList.toggle('no-anim', !!settings.optBg);
  document.title = settings.tabTitle || 'Cine-OS';
  wallVideoState();
}

/* ---------- app loading screen: glitchy bar + LOADING, shown inside a window the first time an app opens ---------- */
function showLoader(w) {
  if (settings.loadScreen === false) return;
  const calm = document.body.classList.contains('no-anim') || matchMedia('(prefers-reduced-motion: reduce)').matches, ms = calm ? 450 : 1600;
  const ld = document.createElement('div'); ld.className = 'ld' + (calm ? ' calm' : ''); ld.style.setProperty('--t', ms + 'ms');
  ld.innerHTML = `<div class="ld-box"><div class="ld-bar">
      <svg class="ld-frame" viewBox="0 0 400 80" preserveAspectRatio="none" aria-hidden="true"><rect class="f1" x="3" y="3" width="394" height="74" pathLength="100"/><rect class="f2" x="3" y="3" width="394" height="74" pathLength="100"/></svg>
      <i class="ld-fill"></i><b class="gl g1"></b><b class="gl g2"></b><b class="gl g3"></b></div>
    <div class="ld-txt" data-t="LOADING">LOADING</div></div><div class="ld-scan"></div>`;
  w.el.append(ld); w.loader = ld;
  setTimeout(() => { ld.classList.add('out'); setTimeout(() => { ld.remove(); if (w.loader === ld) w.loader = null; }, 320); }, ms);
}

/* ---------- windows ---------- */
function launchApp(id, opts = {}) {
  const app = APPS.find(a => a.id === id); if (!app) return;
  if (!isInstalled(app)) { toast('Get ' + app.name, 'Install it from the App Store first.'); return launchApp('appstore', { q: app.name }); }
  hideMenus();
  let w = wins[id];
  if (!w) {
    const el = document.createElement('section'); el.className = 'win';
    const ctl = document.createElement('div'); ctl.className = 'win-ctl';
    ctl.innerHTML = '<button title="Minimize"><i class="fas fa-minus"></i></button><button class="x" title="Close"><i class="fas fa-times"></i></button>';
    const root = document.createElement('div'); root.className = 'app';
    el.append(root, ctl); $('#windows').append(el);
    w = wins[id] = { el, root, onclose: null };
    showLoader(w);
    ctl.children[0].onclick = () => minimize(id);
    ctl.children[1].onclick = () => (app.keepAlive && wins[id] && wins[id].ctl && wins[id].ctl.state() && wins[id].ctl.state().playing ? minimize(id) : closeApp(id)); // music keeps playing in the mini player
    try { app.mount(root, w, opts); }
    catch (err) { // a broken app must not leave a ghost window / taskbar icon behind
      console.error(app.name, err); try { w.onclose && w.onclose(); } catch {}
      el.remove(); delete wins[id]; renderDock();
      return toast(app.name + " couldn't open", String((err && err.message) || err).slice(0, 140));
    }
  } else if (app.onOpen) { try { app.onOpen(w, opts); } catch (err) { console.error(app.name, err); toast(app.name + ' had a problem', String((err && err.message) || err).slice(0, 140)); } }
  Object.entries(wins).forEach(([k, x]) => x.el.classList.toggle('show', k === id));
  renderDock();
}
function minimize(id) { wins[id]?.el.classList.remove('show'); renderDock(); }
function closeApp(id) {
  const w = wins[id]; if (!w) return;
  try { w.onclose && w.onclose(); } catch {}
  delete wins[id]; renderDock();
  const el = w.el; el.classList.remove('show'); el.classList.add('closing'); setTimeout(() => el.remove(), 200); // slide-out, then remove
}
function showDesktop() { Object.values(wins).forEach(w => w.el.classList.remove('show')); hideMenus(); renderDock(); }

/* ---------- dock / menus ---------- */
const getPins = () => LS.get('pins', APPS.filter(a => a.pinned).map(a => a.id)).filter(id => { const a = APPS.find(x => x.id === id); return a && isInstalled(a); });
function iconEl(a, cls = 'ico') {
  const d = document.createElement('div'); d.className = cls;
  d.style.background = a.bg; d.innerHTML = iconHTML(a); d.classList.toggle('has-img', !!a.img); return d;
}
function renderDock() {
  const d = $('#dock'); d.innerHTML = '';
  const mk = (cls, html, tip, fn) => { const b = document.createElement('button'); b.className = cls; b.innerHTML = html; b.dataset.tip = tip; b.setAttribute('aria-label', tip); b.onclick = fn; return b; };
  const start = mk('dk dk-start', 'CF', 'Search & apps', e => { e.stopPropagation(); toggleStart(); });
  const sep = () => Object.assign(document.createElement('div'), { className: 'dk-sep' });
  start.style.setProperty('--i', 0); d.append(start, sep());
  const pins = getPins();
  // pinned apps stay on the taskbar; an unpinned app shows up while it is open and leaves again when it is closed
  [...pins, ...Object.keys(wins).filter(i => !pins.includes(i))].forEach(id => {
    const a = APPS.find(x => x.id === id); if (!a || (!wins[id] && !pins.includes(id))) return;
    const pinned = pins.includes(id), shown = !!wins[id]?.el.classList.contains('show');
    const b = mk('dk' + (wins[id] ? ' run' : '') + (shown ? ' on' : '') + (pinned ? '' : ' temp') + (!dockSeen.has(id) ? ' pop' : ''), iconHTML(a, ' style="color:#fff"'), a.name, () => (wins[id]?.el.classList.contains('show') ? minimize(id) : launchApp(id)));
    b.style.background = a.bg; b.classList.toggle('has-img', !!a.img); b.dataset.id = id;
    b.onauxclick = e => { if (e.button === 1) { e.preventDefault(); wins[id] ? closeApp(id) : launchApp(id); } };
    b.oncontextmenu = e => { e.preventDefault(); e.stopPropagation(); ctxMenu(e, [
      [wins[id] ? 'fa-up-right-from-square' : 'fa-play', wins[id] ? 'Show' : 'Open', () => launchApp(id)],
      ...(wins[id] ? [['fa-xmark', 'Close', () => closeApp(id)]] : []),
      pinned ? ['fa-unlink', 'Unpin from taskbar', () => togglePin(id, false)] : ['fa-thumbtack', 'Pin to taskbar', () => togglePin(id, true)]]); };
    if (pinned) { // drag a pinned icon up or down to reorder the taskbar
      b.draggable = true;
      b.ondragstart = e => { dragId = id; e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', id); b.classList.add('drag'); };
      b.ondragend = () => { dragId = null; $$('#dock .dk').forEach(x => x.classList.remove('drag', 'over')); };
      b.ondragover = e => { if (dragId && dragId !== id) { e.preventDefault(); b.classList.add('over'); } };
      b.ondragleave = () => b.classList.remove('over');
      b.ondrop = e => { e.preventDefault(); if (!dragId || dragId === id) return; const p = pins.filter(x => x !== dragId); p.splice(p.indexOf(id), 0, dragId); dragId = null; LS.set('pins', p); renderDock(); renderStart(); };
    }
    b.style.setProperty('--i', d.children.length); d.append(b);
  });
  Object.keys(wins).forEach(i => dockSeen.add(i)); pins.forEach(i => dockSeen.add(i));
  [...dockSeen].forEach(i => { if (!wins[i] && !pins.includes(i)) dockSeen.delete(i); });
  const all = mk('dk dk-end', '<i class="fas fa-grip"></i>', 'All apps', e => { e.stopPropagation(); toggleDrawer(); });
  const wp = mk('dk', '<i class="fas fa-image"></i>', 'Wallpapers', e => { e.stopPropagation(); hideMenus(); openWallpaperMenu(); });
  all.style.setProperty('--i', d.children.length); wp.style.setProperty('--i', d.children.length + 1); d.append(all, wp);
  paintTopbar(); renderHome();
}
let dragId = null; const dockSeen = new Set();
/* top bar title: shows the app that is on screen (or Home) */
function paintTopbar() {
  const id = Object.keys(wins).find(k => wins[k].el.classList.contains('show')), a = id && APPS.find(x => x.id === id);
  $('#tb-title').innerHTML = a ? `<span class="ti" style="background:${a.img ? 'transparent' : a.bg}">${iconHTML(a, ' style="color:#fff"')}</span>${esc(a.name)}` : '<span class="ti home"><i class="fas fa-house"></i></span>Home';
  document.body.classList.toggle('app-open', !!a);
  const key = a ? a.id : 'home';
  if (paintTopbar.last !== key) { paintTopbar.last = key; const t = $('#tb-title'); t.classList.remove('swap'); void t.offsetWidth; t.classList.add('swap'); }
}
/* home screen: big app + game tiles with the real game icons */
function renderHome() {
  const apps = $('#hm-apps'), games = $('#hm-games'); if (!apps || !games) return;
  apps.innerHTML = ''; games.innerHTML = '';
  getPins().map(id => APPS.find(a => a.id === id)).filter(Boolean).forEach(a => {
    const t = document.createElement('button'); t.className = 'hm-t'; t.append(iconEl(a, 'ico')); t.append(Object.assign(document.createElement('span'), { textContent: a.name }));
    t.dataset.id = a.id; t.style.setProperty('--i', apps.children.length); t.onclick = () => launchApp(a.id); apps.append(t);
  });
  const owned = LS.get('owned', []), last = (LS.get('lastGame') || {}).id;
  const list = [...GAMES].sort((x, y) => (y.id === last) - (x.id === last) || owned.includes(y.id) - owned.includes(x.id)).slice(0, 8);
  list.forEach(g => {
    const t = document.createElement('button'); t.className = 'hm-t game'; t.innerHTML = `<img src="${g.ico}" alt="" draggable="false"><span>${esc(g.name)}</span>`;
    t.style.setProperty('--i', apps.children.length + games.children.length); t.onclick = () => launchApp('play', { game: g.id }); games.append(t);
  });
  if (typeof paintBadges === 'function') paintBadges(); // Messages unread count
}
function togglePin(id, on) {
  let p = getPins().filter(x => x !== id); if (on) p.push(id);
  LS.set('pins', p); renderDock(); renderStart(); if ($('#drawer').classList.contains('open')) renderDrawer($('#drawer-search').value);
}
function appTile(a) {
  const t = document.createElement('div'); t.className = 'ap';
  t.append(iconEl(a)); t.append(Object.assign(document.createElement('span'), { textContent: a.name }));
  t.onclick = () => launchApp(a.id);
  t.oncontextmenu = e => { e.preventDefault(); e.stopPropagation(); const pinned = getPins().includes(a.id);
    ctxMenu(e, [[pinned ? 'fa-unlink' : 'fa-thumbtack', pinned ? 'Unpin from taskbar' : 'Pin to taskbar', () => togglePin(a.id, !pinned)]]); };
  return t;
}
/* ---------- search modes: Everything / Cine-Tunes / FigureTube / Web ---------- */
const SMODES = {
  all:   { label: 'Everything', bar: 'Search apps, games or the web', ph: 'Search apps and games…', ico: 'fa-search' },
  tunes: { label: 'Cine-Tunes', bar: 'Search music in Cine-Tunes', ph: 'Search songs, albums or artists in Cine-Tunes…', ico: 'fa-music' },
  tube:  { label: 'FigureTube', bar: 'Search videos in FigureTube', ph: 'Search videos on FigureTube…', ico: 'fa-play' },
  web:   { label: 'Web', bar: 'Search the web', ph: 'Search the web or type a URL…', ico: 'fa-globe' },
};
const SORDER = Object.keys(SMODES);
let smode = LS.get('searchMode', 'all'); if (!SMODES[smode]) smode = 'all';
function runSearch(mode, q) {
  if (mode === 'tunes') launchApp('tunes', { q });
  else if (mode === 'tube') launchApp('figuretube', { q });
  else launchApp('web', { url: q });
}
function setSMode(m, save = true) {
  if (!SMODES[m]) return; smode = m; if (save) LS.set('searchMode', m);
  const d = SMODES[m];
  $$('#sm-modes [data-m]').forEach(b => b.classList.toggle('on', b.dataset.m === m));
  $('#start-search').placeholder = d.ph;
  [['#tb-search', ''], ['#hm-search', '…']].forEach(([sel, tail]) => {
    const b = $(sel); SORDER.forEach(k => b.classList.toggle('m-' + k, k === m));
    $('span', b).textContent = d.bar + tail; $('i', b).className = 'fas ' + d.ico;
  });
}
function renderStart(filter = '') {
  const g = $('#pinned-grid'); g.innerHTML = ''; const f = filter.trim(), lf = f.toLowerCase();
  g.classList.toggle('list', !!f); $('#pal-title').textContent = f ? 'Results' : 'Pinned';
  if (!f) { const pa = getPins().map(id => APPS.find(a => a.id === id)).filter(Boolean); pa.forEach(a => g.append(appTile(a))); if (!pa.length) g.innerHTML = '<div class="err" style="grid-column:1/-1;padding:18px;text-align:center">Nothing pinned. Open the app drawer (bottom of the taskbar) and right-click an app to pin it.</div>'; return; }
  const row = (icon, title, sub, fn) => { const r = document.createElement('div'); r.className = 'pal-row'; r.innerHTML = `${icon}<div><strong>${esc(title)}</strong><small>${esc(sub)}</small></div><i class="fas fa-arrow-turn-down pal-go"></i>`; r.onclick = () => { hideMenus(); fn(); }; g.append(r); };
  const web = () => row('<span class="pi web"><i class="fas fa-globe"></i></span>', 'Search the web for “' + f + '”', 'Cine-Web', () => runSearch('web', f));
  const tunes = () => row('<span class="pi tn"><i class="fas fa-music"></i></span>', 'Search music for “' + f + '”', 'Cine-Tunes · songs, albums, artists', () => runSearch('tunes', f));
  const tube = () => row('<span class="pi ft"><i class="fas fa-play"></i></span>', 'Search videos for “' + f + '”', 'FigureTube', () => runSearch('tube', f));
  // a specific mode puts that search first; the others stay one click away
  if (smode === 'tunes') { tunes(); tube(); web(); return; }
  if (smode === 'tube') { tube(); tunes(); web(); return; }
  if (smode === 'web') { web(); tunes(); tube(); return; }
  APPS.filter(a => isInstalled(a) && a.name.toLowerCase().includes(lf)).forEach(a => row(`<span class="pi" style="background:${a.img ? 'transparent' : a.bg}">${iconHTML(a, ' style="color:#fff"')}</span>`, a.name, 'App', () => launchApp(a.id)));
  GAMES.filter(x => (x.name + ' ' + x.tag).toLowerCase().includes(lf)).forEach(x => row(`<img class="pi game" src="${x.ico}" alt="">`, x.name, 'Game · ' + x.tag, () => launchApp('play', { game: x.id })));
  tunes(); tube(); web();
}
function renderDrawer(filter = '') {
  const g = $('#drawer-grid'); g.innerHTML = '';
  APPS.filter(a => isInstalled(a) && a.name.toLowerCase().includes(filter.toLowerCase())).forEach(a => g.append(appTile(a)));
}
function hideMenus() { $('#start-menu').classList.remove('open'); $('#drawer').classList.remove('open'); $('#ctx').style.display = 'none'; $('#pf-pop').classList.remove('open'); }
function toggleStart() { const o = !$('#start-menu').classList.contains('open'); hideMenus(); if (o) { renderStart(); $('#start-search').value = ''; $('#start-menu').classList.add('open'); $('#start-search').focus(); } }
function toggleDrawer() { const o = !$('#drawer').classList.contains('open'); hideMenus(); if (o) { renderDrawer(); $('#drawer-search').value = ''; $('#drawer').classList.add('open'); $('#drawer-search').focus(); } }
function ctxMenu(e, items) {
  const c = $('#ctx'); c.innerHTML = '';
  items.forEach(([ic, label, fn]) => { const li = document.createElement('li'); li.innerHTML = `<i class="fas ${ic}"></i> ${label}`; li.onclick = () => { c.style.display = 'none'; fn(); }; c.append(li); });
  c.style.display = 'block';
  c.style.left = Math.min(e.clientX, innerWidth - 210) + 'px';
  c.style.top = Math.min(e.clientY, innerHeight - items.length * 40 - 10) + 'px';
}
$('#start-search').oninput = e => renderStart(e.target.value);
$('#start-search').onkeydown = e => {
  if (e.key === 'Tab') { e.preventDefault(); setSMode(SORDER[(SORDER.indexOf(smode) + (e.shiftKey ? SORDER.length - 1 : 1)) % SORDER.length]); renderStart($('#start-search').value); return; }
  if (e.key === 'Escape') { hideMenus(); e.stopPropagation(); }
  if (e.key === 'Enter') { const first = $('#pinned-grid .pal-row, #pinned-grid .ap'); first && first.click(); }
};
$('#sm-modes').onclick = e => { const b = e.target.closest('[data-m]'); if (!b) return; e.stopPropagation(); setSMode(b.dataset.m); renderStart($('#start-search').value); $('#start-search').focus(); };
setSMode(smode, false);
$('#tb-search').onclick = $('#hm-search').onclick = e => { e.stopPropagation(); toggleStart(); };
$('#tb-lock').onclick = () => lockNow();
$('#start-user').onclick = e => { e.stopPropagation(); hideMenus(); openProfilePopover(); };
$('#drawer-search').oninput = e => renderDrawer(e.target.value);
$('#drawer').onclick = e => { if (e.target.id === 'drawer') hideMenus(); };
$('#pwr').onclick = () => location.reload();
document.addEventListener('click', e => { if (!e.target.closest('#start-menu,#dock,#ctx,#tb-search,#hm-search')) { $('#start-menu').classList.remove('open'); } $('#ctx').style.display = 'none'; });
document.addEventListener('contextmenu', e => {
  if (e.target.closest('.win,.ap,.dk,#start-menu,#wp-menu')) return;
  e.preventDefault();
  ctxMenu(e, [['fa-image', 'Change wallpaper', openWallpaperMenu], ['fa-gear', 'Config', () => launchApp('config')], ['fa-rotate', 'Refresh system', () => location.reload()]]);
});

/* ---------- sidebar ---------- */
$$('#right-sidebar .sb-card').forEach((c, i) => c.style.setProperty('--i', i));
function refreshSidebar() {
  const g = LS.get('lastGame'); $('#sb-game-name').textContent = g ? g.name : 'No Recent Game';
  const gm = g && GAMES.find(x => x.id === g.id), im = $('#sb-game-img'); im.src = gm ? gm.ico : 'icons/playstation.png'; im.classList.toggle('gico', !!gm);
  const t = LS.get('lastTrack'); $('#sb-music-name').textContent = t ? t.title : 'Not Playing';
}
$('#sb-game').onclick = () => { const g = LS.get('lastGame'); g ? launchApp('play', { game: g.id }) : launchApp('play'); };
$('#sb-music').onclick = () => launchApp('tunes', { resume: true });
$('#sb-update').onclick = () => $('#modal').classList.add('open');
$('#modal-x').onclick = () => $('#modal').classList.remove('open');
bus.addEventListener('sidebar', () => { refreshSidebar(); renderHome(); });

/* ---------- clock / lock / boot ---------- */
const DAYS = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const MONTHS = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'];
function tick() {
  const n = new Date(), p = x => String(x).padStart(2, '0'), h = n.getHours();
  $('#lock-day').textContent = $('#hud-day').textContent = `${DAYS[n.getDay()]} · ${p(n.getDate())} ${MONTHS[n.getMonth()]} ${n.getFullYear()}`;
  $('#lock-date').textContent = '';
  $('#lock-time').textContent = `${p(h)}:${p(n.getMinutes())}`;
  $('#tb-clock').textContent = n.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  const hi = h < 5 ? 'Still up' : h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
  $('#hm-greet').textContent = `${hi}, ${getProfile().name}`;
}
setInterval(tick, 1000); tick();

let locked = true, lastActive = Date.now(), bootDone = false;
function unlock() {
  if (!locked || !bootDone) return;
  locked = false; $('#lock').classList.add('up'); wallVideoState();
  document.body.classList.add('revealing'); clearTimeout(unlock.t); unlock.t = setTimeout(() => document.body.classList.remove('revealing'), 2400);
  if (!unlock.once) { unlock.once = 1; setTimeout(() => toast('Welcome back, ' + getProfile().name, 'Press Ctrl K to search. Click your profile (top right) to customize it.'), 900); }
}
function lockNow() { showDesktop(); locked = true; $('#lock').classList.remove('up'); wallVideoState(); }
$('#lock').onclick = unlock;
addEventListener('keydown', e => { if (locked && !e.target.closest('input')) unlock(); });
['mousemove', 'keydown', 'mousedown', 'touchstart'].forEach(ev => addEventListener(ev, () => (lastActive = Date.now()), { passive: true }));
setInterval(() => { if (settings.idleLock && !locked && Date.now() - lastActive > 180000) lockNow(); }, 5000);

function finishBoot() { bootDone = true; const b = $('#boot'); if (!b) return; b.classList.add('done'); setTimeout(() => b.remove(), 800); }
$('#boot-btn').onclick = () => {
  $('#boot-btn').style.display = 'none';
  if (settings.fastBoot) return finishBoot();
  $('#boot-bar').classList.add('go'); setTimeout(finishBoot, 2800);
};

/* ---------- keyboard ---------- */
addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); if (!locked) toggleStart(); return; }
  if (e.target.closest('input,textarea,select')) return;
  if (settings.panicKey && e.key === settings.panicKey) { location.replace(settings.panicUrl || 'https://www.wikipedia.org'); return; }
  if (e.key === 'Escape') { const open = $('#start-menu.open,#drawer.open,#wp-menu.open,#pf-pop.open'); open ? (hideMenus(), $('#wp-menu').classList.remove('open')) : showDesktop(); }
});

/* ---------- tooltips ---------- */
document.addEventListener('mouseover', e => {
  const tip = $('#tip'), t = e.target.closest('[data-tip]');
  if (!t) return tip.classList.remove('show');
  const r = t.getBoundingClientRect(), below = t.dataset.tipPos === 'bottom';
  tip.textContent = t.dataset.tip; tip.classList.toggle('below', below); tip.classList.add('show');
  tip.style.left = (below ? r.left + r.width / 2 : r.right + 12) + 'px'; tip.style.top = (below ? r.bottom + 8 : r.top + r.height / 2) + 'px';
});
document.addEventListener('mousedown', () => $('#tip').classList.remove('show'));

/* ---------- fps ---------- */
(function fps() { let f = 0, t = performance.now(); (function l(n) { f++; if (n - t >= 1000) { $('#fps-val').textContent = f; f = 0; t = n; } requestAnimationFrame(l); })(t); })();

/* ---------- animated wallpaper: leaves, rain, floating air ---------- */
const FX = { items: [], scene: null, w: 0, h: 0, drops: [], motes: [], mode: { home: false, lock: false }, sig: '', started: false };
function fxBuild() {
  FX.w = Math.ceil(innerWidth * 0.75); FX.h = Math.ceil(innerHeight * 0.75);
  const u = FX.w / 1400;
  const layer = (n, smin, smax, cols, alpha, blur) => {
    const c = document.createElement('canvas'); c.width = FX.w; c.height = FX.h;
    const x = c.getContext('2d'); if (blur) x.filter = `blur(${blur}px)`;
    for (let i = 0; i < n; i++) {
      const s = (smin + Math.random() * (smax - smin)) * u;
      x.save(); x.translate(Math.random() * FX.w, Math.random() * FX.h); x.rotate(Math.random() * 6.28); x.globalAlpha = alpha;
      const g = x.createLinearGradient(0, -s, 0, s); g.addColorStop(0, cols[0]); g.addColorStop(1, cols[1]);
      x.fillStyle = g; x.beginPath(); x.moveTo(0, -s);
      x.bezierCurveTo(s * .75, -s * .35, s * .65, s * .55, 0, s);
      x.bezierCurveTo(-s * .65, s * .55, -s * .75, -s * .35, 0, -s); x.fill();
      x.strokeStyle = 'rgba(190,255,205,.22)'; x.lineWidth = Math.max(1, s / 45);
      x.beginPath(); x.moveTo(0, -s * .9); x.lineTo(0, s);
      for (let k = 0; k < 4; k++) { const y0 = -s * .5 + k * s * .3; x.moveTo(0, y0); x.lineTo(s * .45, y0 - s * .18); x.moveTo(0, y0); x.lineTo(-s * .45, y0 - s * .18); }
      x.stroke(); x.restore();
    }
    return c;
  };
  FX.scene = {
    back: layer(80, 70, 150, ['#0b3d22', '#04180d'], .9, 3),
    mid: layer(50, 90, 190, ['#14602f', '#073a1d'], .9, 1.5),
    front: layer(34, 110, 230, ['#2f9a4d', '#0d5a2c'], .92, 0),
  };
  FX.drops = Array.from({ length: 140 }, () => ({ x: Math.random() * FX.w, y: Math.random() * FX.h, l: 8 + Math.random() * 14, v: 380 + Math.random() * 360 }));
  FX.motes = Array.from({ length: 70 }, () => ({ x: Math.random() * FX.w, y: Math.random() * FX.h, r: .8 + Math.random() * 2, a: .15 + Math.random() * .4, s: .5 + Math.random() * 1.5, p: Math.random() * 6, vx: 4 + Math.random() * 10, vy: -3 - Math.random() * 8 }));
  FX.sig = '';
}
function fxSet(wp) {
  FX.mode.home = wp.home === 'rainforest'; FX.mode.lock = wp.lock === 'rainforest';
  FX.items = [{ cv: $('#fx-bg'), key: 'home' }, { cv: $('#fx-lock'), key: 'lock' }];
  if (!FX.scene) fxBuild();
  FX.sig = '';
  if (!FX.started) { FX.started = true; let last = performance.now(); requestAnimationFrame(function f(t) { requestAnimationFrame(f); const dt = Math.min(.05, (t - last) / 1000); last = t; fxFrame(t / 1000, dt); }); }
}
function fxFrame(tt, dt) {
  const it = FX.items[locked ? 1 : 0]; if (!it || !FX.scene) return;
  const still = !!settings.optBg, sig = it.key + FX.mode[it.key] + still;
  if (still && sig === FX.sig) return; FX.sig = sig;
  if (still) tt = 0;
  const c = it.cv, x = c.getContext('2d');
  if (c.width !== FX.w || c.height !== FX.h) { c.width = FX.w; c.height = FX.h; }
  x.clearRect(0, 0, FX.w, FX.h);
  if (FX.mode[it.key]) {
    x.fillStyle = '#02130a'; x.fillRect(0, 0, FX.w, FX.h);
    [[FX.scene.back, 6, .25, 0], [FX.scene.mid, 10, .35, 1.3], [FX.scene.front, 16, .5, 2.6]].forEach(([l, amp, sp, ph]) => {
      x.save(); x.translate(FX.w / 2 + Math.sin(tt * sp + ph) * amp, FX.h / 2 + Math.sin(tt * sp * .8 + ph + 1) * amp * .6);
      x.rotate(Math.sin(tt * sp + ph) * .006); x.scale(1.07, 1.07); x.drawImage(l, -FX.w / 2, -FX.h / 2); x.restore();
    });
    const g = x.createRadialGradient(FX.w / 2, FX.h / 2, FX.h * .2, FX.w / 2, FX.h / 2, FX.h * .95);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,.65)'); x.fillStyle = g; x.fillRect(0, 0, FX.w, FX.h);
    if (!still) {
      x.strokeStyle = 'rgba(200,255,220,.28)'; x.lineWidth = 1; x.beginPath();
      FX.drops.forEach(d => { d.y += d.v * dt; d.x -= d.v * .2 * dt; if (d.y > FX.h) { d.y = -20; d.x = Math.random() * FX.w * 1.2; } x.moveTo(d.x, d.y); x.lineTo(d.x - d.l * .2, d.y + d.l); });
      x.stroke();
    }
  }
  if (!still) {
    x.fillStyle = 'rgba(220,255,235,1)';
    FX.motes.forEach(m => {
      m.x += (m.vx + Math.sin(tt * m.s + m.p) * 6) * dt; m.y += m.vy * dt;
      if (m.x > FX.w + 5) m.x = -5; if (m.y < -5) m.y = FX.h + 5;
      x.globalAlpha = m.a * (.6 + .4 * Math.sin(tt * m.s + m.p)); x.beginPath(); x.arc(m.x, m.y, m.r, 0, 7); x.fill();
    });
    x.globalAlpha = 1;
  }
}
let fxResizeT; addEventListener('resize', () => { clearTimeout(fxResizeT); fxResizeT = setTimeout(fxBuild, 250); });

/* ---------- errors: show a short toast instead of failing silently ---------- */
(function errorToasts() {
  let last = 0;
  const say = m => { const n = Date.now(); if (n - last < 4000) return; last = n; m = String(m || 'Unknown error').slice(0, 140); if (!/ResizeObserver/.test(m)) toast('Something went wrong', m); };
  addEventListener('error', e => say(e.message));
  addEventListener('unhandledrejection', e => say(e.reason && e.reason.message || e.reason));
})();

/* ---------- init ---------- */
// apps added in later versions get pinned for existing users too (once)
(function migratePins() {
  const pins = LS.get('pins', null), seen = LS.get('seenApps', ['web', 'figuretube', 'tunes', 'flix', 'play', 'config']);
  if (pins) {
    const fresh = APPS.filter(a => a.pinned && !seen.includes(a.id) && !pins.includes(a.id)).map(a => a.id);
    if (fresh.length) { const i = pins.indexOf('config'); pins.splice(i < 0 ? pins.length : i, 0, ...fresh); LS.set('pins', pins); }
  }
  LS.set('seenApps', APPS.map(a => a.id));
})();
applySettings(); applyWalls(); renderDock(); refreshSidebar();
