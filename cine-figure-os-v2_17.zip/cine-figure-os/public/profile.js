// Cine/Figure OS - profile system
//   top-right button -> popover card -> "Edit Profile" (picture, banner colour / image, name, bio, status)
(function () {
  const COLORS = ['#5865f2', '#23a55a', '#f23f43', '#f0b232', '#eb459e', '#9b59b6', '#1abc9c', '#e67e22', '#00b0f4', '#ff7a59', '#2b2d31', '#111214'];
  const STATUS = { online: ['Online', '#23a55a'], idle: ['Idle', '#f0b232'], dnd: ['Do Not Disturb', '#f23f43'], invisible: ['Invisible', '#80848e'] };
  const initial = p => ((p.name || '').trim()[0] || '?').toUpperCase();
  const avStyle = p => p.avatar ? `background-image:url(${p.avatar})` : `background-color:${p.avatarColor}`;
  const bannerStyle = p => p.banner.type === 'image' && p.banner.image
    ? `background-image:url(${p.banner.image});background-size:cover;background-position:50% ${p.banner.pos}%`
    : `background:${p.banner.color}`;

  // avatar bubble with an optional status dot (also used by the lock screen and start menu)
  window.avHTML = (p, size = 32, ring = 'var(--bg1)', dot = true) =>
    `<span class="av" style="--s:${size}px;--ring:${ring};${avStyle(p)}">${p.avatar ? '' : esc(initial(p))}${dot ? `<i class="st" style="background:${STATUS[p.status][1]}"></i>` : ''}</span>`;

  const cardHTML = p => `
    <div class="pc-banner" style="${bannerStyle(p)}"></div>
    <div class="pc-av">${avHTML(p, 84, 'var(--card)')}</div>
    <div class="pc-body">
      <div class="pc-name">${esc(p.name)}</div>
      <div class="pc-handle">@${esc(p.handle)}<span class="dotsep">•</span><span style="color:${STATUS[p.status][1]}">${STATUS[p.status][0]}</span></div>
      <div class="pc-sec"><h5>About me</h5><p class="pc-bio">${p.bio.trim() ? esc(p.bio) : '<i>No bio yet.</i>'}</p></div>
      <div class="pc-sec"><h5>Cine member since</h5><p>${new Date(p.since).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}</p></div>
    </div>`;

  /* ---------- paint the places the profile shows up ---------- */
  function paint() {
    const p = getProfile();
    $('#tb-profile').innerHTML = `${avHTML(p, 30, 'var(--bg1)')}<span class="tp-name">${esc(p.name)}</span><i class="fas fa-chevron-down tp-car"></i>`;
    $('#start-av').innerHTML = avHTML(p, 32, 'var(--bg1)');
    $('#start-name').textContent = p.name;
    $('#lock-av').innerHTML = avHTML(p, 96, '#000', false);
    $('#lock-name').textContent = p.name;
    tick();
    if ($('#pf-pop').classList.contains('open')) fillPop();
  }
  bus.addEventListener('profile', paint);

  /* ---------- popover ---------- */
  const pop = $('#pf-pop');
  function fillPop() {
    const p = getProfile(), apps = APPS.filter(isInstalled).length, games = LS.get('owned', []).length;
    pop.innerHTML = `<div class="pc">${cardHTML(p)}
      <div class="pc-stats"><div><b>${apps}</b><span>Apps</span></div><div><b>${games}</b><span>Games</span></div></div>
      <div class="pc-status">${Object.entries(STATUS).map(([k, v]) => `<button data-st="${k}" class="${p.status === k ? 'on' : ''}" title="${v[0]}"><i style="background:${v[1]}"></i>${v[0]}</button>`).join('')}</div>
      <div class="pc-act"><button class="btn" id="pc-edit"><i class="fas fa-pen"></i> Edit Profile</button></div></div>`;
    $('#pc-edit', pop).onclick = () => { closePop(); openProfileEditor(); };
    $$('[data-st]', pop).forEach(b => b.onclick = () => { const q = getProfile(); saveProfile(Object.assign({}, q, { status: b.dataset.st })); });
  }
  function closePop() { pop.classList.remove('open'); }
  window.openProfilePopover = () => { hideMenus(); fillPop(); pop.classList.add('open'); };
  $('#tb-profile').onclick = e => { e.stopPropagation(); pop.classList.contains('open') ? closePop() : openProfilePopover(); };
  addEventListener('mousedown', e => { if (!e.target.closest('#pf-pop,#tb-profile,#start-user')) closePop(); });

  /* ---------- image helpers: shrink before saving so browser storage doesn't fill up ---------- */
  const loadImage = file => new Promise((ok, no) => {
    const u = URL.createObjectURL(file), im = new Image();
    im.onload = () => { URL.revokeObjectURL(u); ok(im); }; im.onerror = () => { URL.revokeObjectURL(u); no(new Error('bad image')); }; im.src = u;
  });
  async function avatarFrom(file) {
    const im = await loadImage(file), s = Math.min(im.naturalWidth, im.naturalHeight), c = document.createElement('canvas');
    c.width = c.height = 256; c.getContext('2d').drawImage(im, (im.naturalWidth - s) / 2, (im.naturalHeight - s) / 2, s, s, 0, 0, 256, 256);
    const w = c.toDataURL('image/webp', .9); return w.startsWith('data:image/webp') ? w : c.toDataURL('image/png');
  }
  async function bannerFrom(file) {
    const im = await loadImage(file), k = Math.min(1, 1200 / im.naturalWidth, 800 / im.naturalHeight), c = document.createElement('canvas'), x = c.getContext('2d');
    c.width = Math.round(im.naturalWidth * k); c.height = Math.round(im.naturalHeight * k);
    x.fillStyle = '#232428'; x.fillRect(0, 0, c.width, c.height); x.drawImage(im, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', .85);
  }

  /* ---------- editor ---------- */
  const modal = $('#pf-modal'), box = $('.pf-box', modal);
  let d = null; // draft copy of the profile while editing
  const swatches = (sel, cur) => COLORS.map(c => `<button class="sw-c ${c.toLowerCase() === String(cur).toLowerCase() ? 'on' : ''}" data-c="${c}" style="background:${c}" aria-label="${c}"></button>`).join('')
    + `<label class="sw-c custom ${COLORS.some(c => c.toLowerCase() === String(cur).toLowerCase()) ? '' : 'on'}" title="Custom colour"><input type="color" data-custom="${sel}" value="${/^#[0-9a-f]{6}$/i.test(cur) ? cur : '#5865f2'}"><i class="fas fa-eyedropper"></i></label>`;

  function drawPreview() { $('#pf-card', box).innerHTML = cardHTML(d); }
  function drawControls() {
    $('#pf-av-sw', box).innerHTML = swatches('av', d.avatarColor);
    $('#pf-bn-sw', box).innerHTML = swatches('bn', d.banner.color);
    $('#pf-av-rm', box).disabled = !d.avatar;
    $('#pf-bn-rm', box).disabled = !(d.banner.type === 'image' && d.banner.image);
    $('#pf-pos-row', box).classList.toggle('hidden', !(d.banner.type === 'image' && d.banner.image));
    $('#pf-pos', box).value = d.banner.pos;
    $('#pf-st', box).innerHTML = Object.entries(STATUS).map(([k, v]) => `<button data-st="${k}" class="${d.status === k ? 'on' : ''}"><i style="background:${v[1]}"></i>${v[0]}</button>`).join('');
  }

  window.openProfileEditor = () => {
    hideMenus();
    const p = getProfile(); d = JSON.parse(JSON.stringify(p));
    box.innerHTML = `
      <header><h2>Edit Profile</h2><button class="x" id="pf-x" aria-label="Close"><i class="fas fa-xmark"></i></button></header>
      <div class="pf-cols">
        <div class="pf-form">
          <label class="f">Display name<input id="pf-name" maxlength="32" value="${esc(d.name)}" autocomplete="off"></label>
          <label class="f">Username<div class="at"><span>@</span><input id="pf-handle" maxlength="20" value="${esc(d.handle)}" autocomplete="off"></div></label>
          <label class="f">About me<textarea id="pf-bio" maxlength="190" rows="3" placeholder="Tell people about yourself">${esc(d.bio)}</textarea><small class="cnt" id="pf-cnt"></small></label>
          <h4>Profile picture</h4>
          <div class="pf-row"><button class="btn" id="pf-av-up"><i class="fas fa-image"></i> Change picture</button><button class="btn ghost" id="pf-av-rm">Remove</button><input type="file" id="pf-av-file" accept="image/*" hidden></div>
          <div class="pf-sub">Picture colour (used when there's no picture)</div><div class="pf-sw" id="pf-av-sw"></div>
          <h4>Banner</h4>
          <div class="pf-sub">Colour</div><div class="pf-sw" id="pf-bn-sw"></div>
          <div class="pf-row"><button class="btn" id="pf-bn-up"><i class="fas fa-upload"></i> Upload banner image</button><button class="btn ghost" id="pf-bn-rm">Remove image</button><input type="file" id="pf-bn-file" accept="image/*" hidden></div>
          <label class="f pf-pos" id="pf-pos-row">Image position<input type="range" id="pf-pos" min="0" max="100"></label>
          <h4>Status</h4><div class="pf-st" id="pf-st"></div>
        </div>
        <div class="pf-prev"><h4>Preview</h4><div class="pc" id="pf-card"></div><p class="pf-hint">Images are resized and saved on this device only. Animated GIFs become still pictures.</p></div>
      </div>
      <footer><button class="btn ghost" id="pf-cancel">Cancel</button><button class="btn" id="pf-save"><i class="fas fa-check"></i> Save changes</button></footer>`;
    modal.classList.add('open'); drawControls(); drawPreview();
    const cnt = () => $('#pf-cnt', box).textContent = `${d.bio.length}/190`; cnt();

    $('#pf-name', box).oninput = e => { d.name = e.target.value; drawPreview(); };
    $('#pf-handle', box).oninput = e => { d.handle = e.target.value.replace(/[^\w.\-]/g, '').toLowerCase(); e.target.value = d.handle; drawPreview(); };
    $('#pf-bio', box).oninput = e => { d.bio = e.target.value; cnt(); drawPreview(); };
    $('#pf-pos', box).oninput = e => { d.banner.pos = +e.target.value; drawPreview(); };

    const pick = async (inp, make, apply) => {
      const f = inp.files[0]; inp.value = ''; if (!f) return;
      if (!f.type.startsWith('image/')) return toast('Not an image', 'Pick a PNG, JPG, WebP or GIF file.');
      if (f.size > 15e6) return toast('Image too large', 'Pick one under 15 MB.');
      try { apply(await make(f)); drawControls(); drawPreview(); } catch { toast('Could not read that image', 'Try a different file.'); }
    };
    $('#pf-av-up', box).onclick = () => $('#pf-av-file', box).click();
    $('#pf-av-file', box).onchange = e => pick(e.target, avatarFrom, url => { d.avatar = url; });
    $('#pf-av-rm', box).onclick = () => { d.avatar = null; drawControls(); drawPreview(); };
    $('#pf-bn-up', box).onclick = () => $('#pf-bn-file', box).click();
    $('#pf-bn-file', box).onchange = e => pick(e.target, bannerFrom, url => { d.banner.type = 'image'; d.banner.image = url; d.banner.pos = 50; });
    $('#pf-bn-rm', box).onclick = () => { d.banner.type = 'color'; d.banner.image = null; drawControls(); drawPreview(); };

    const setColor = (which, c) => { if (which === 'av') d.avatarColor = c; else { d.banner.color = c; d.banner.type = 'color'; d.banner.image = null; } drawControls(); drawPreview(); };
    box.onclick = e => {
      const sw = e.target.closest('.sw-c[data-c]'); if (sw) return setColor(sw.parentElement.id === 'pf-av-sw' ? 'av' : 'bn', sw.dataset.c);
      const st = e.target.closest('#pf-st [data-st]'); if (st) { d.status = st.dataset.st; drawControls(); drawPreview(); }
    };
    // the colour picker stays open while dragging, so update in place instead of redrawing the swatches
    box.oninput = e => {
      const c = e.target.closest('[data-custom]'); if (!c) return;
      if (c.dataset.custom === 'av') d.avatarColor = c.value; else { d.banner.color = c.value; d.banner.type = 'color'; d.banner.image = null; $('#pf-bn-rm', box).disabled = true; $('#pf-pos-row', box).classList.add('hidden'); }
      $$('.sw-c', c.closest('.pf-sw')).forEach(x => x.classList.toggle('on', x === c.parentElement)); drawPreview();
    };
    $('#pf-cancel', box).onclick = $('#pf-x', box).onclick = closeEditor;
    $('#pf-save', box).onclick = () => {
      d.name = d.name.trim() || 'Administrator'; d.handle = d.handle.trim() || 'admin'; d.bio = d.bio.trim();
      if (!saveProfile(d)) return toast('Could not save', 'Browser storage is full. Use a smaller image or clear your custom wallpaper in Config.');
      const nm = d.name; closeEditor(); toast('Profile saved', 'Looking good, ' + nm + '.');
    };
    setTimeout(() => $('#pf-name', box).focus(), 50);
  };
  function closeEditor() { modal.classList.remove('open'); d = null; }
  addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    if (modal.classList.contains('open')) { closeEditor(); e.stopPropagation(); } else if (pop.classList.contains('open')) { closePop(); e.stopPropagation(); }
  }, true);

  paint();
})();
