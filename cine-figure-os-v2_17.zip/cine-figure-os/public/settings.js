// Config / Settings app, organised into tabs
registerApp({
  id: 'config', name: 'Config', icon: 'fa-gear', bg: '#3a3a44', pinned: true, onOpen,
  mount(root) {
    root.classList.add('cf');
    const TABS = [['perf', 'Performance', 'fa-gauge-high'], ['look', 'Personalization', 'fa-palette'], ['keys', 'Shortcuts', 'fa-keyboard'], ['host', 'Localhost', 'fa-server'], ['data', 'Data', 'fa-database'], ['about', 'About', 'fa-circle-info']];
    let tab = LS.get('cfTab', 'perf'); if (!TABS.some(t => t[0] === tab)) tab = 'perf';
    root.innerHTML = `<h1>SYSTEM CONFIGURATION</h1>
      <div class="cf-tabs">${TABS.map(t => `<button data-tab="${t[0]}"><i class="fas ${t[2]}"></i> ${t[1]}</button>`).join('')}</div>
      <div class="cf-body"></div>`;
    const body = $('.cf-body', root);

    const sw = (k, ic, t, d) => `<div class="cf-card"><div><strong><i class="fas ${ic}"></i>&nbsp; ${t}</strong><small>${d}</small></div><label class="sw"><input type="checkbox" data-k="${k}" ${settings[k] ? 'checked' : ''}><span></span></label></div>`;
    const row = (ic, t, d, ctl) => `<div class="cf-card"><div><strong><i class="fas ${ic}"></i>&nbsp; ${t}</strong><small>${d}</small></div>${ctl}</div>`;
    const lsBytes = () => { let n = 0; try { for (const k of Object.keys(localStorage)) if (k.startsWith('cine.')) n += k.length + localStorage.getItem(k).length; } catch {} return n; };
    const wipe = (...keys) => { keys.forEach(k => { try { localStorage.removeItem('cine.' + k); } catch {} }); };

    const VIEWS = {
      perf: () => `<h4>Performance</h4>
        ${sw('optBg', 'fa-film', 'Optimized Background', 'Turns off animated wallpapers to save resources')}
        ${sw('loadScreen', 'fa-bars-progress', 'App Loading Screen', 'Shows the glitch loading screen when an app opens')}
        ${sw('fastBoot', 'fa-bolt', 'Fast Boot', 'Skips the startup sequence next time')}
        ${sw('idleLock', 'fa-lock', 'Idle Lock Screen', 'Locks the system after 3 minutes away')}`,
      look: () => `<h4>Profile</h4>
        <div class="cf-card"><div class="cf-profile">${avHTML(getProfile(), 48)}<div><strong>${esc(getProfile().name)}</strong><small>@${esc(getProfile().handle)} · picture, banner, bio and status</small></div></div><button class="btn" id="cf-prof"><i class="fas fa-pen"></i> Edit Profile</button></div>
        <h4>Wallpaper</h4>
        <div class="wp-row"><div class="seg"><label><input type="radio" name="cfwpm" value="both" checked><span>Both</span></label><label><input type="radio" name="cfwpm" value="home"><span>Homescreen</span></label><label><input type="radio" name="cfwpm" value="lock"><span>Lockscreen</span></label></div>
          <label class="upload-btn"><i class="fas fa-upload"></i> Upload image<input type="file" id="cf-file" accept="image/*" hidden></label></div>
        <div class="wp-grid" id="cf-grid"></div>
        <h4>Browser tab</h4>
        ${row('fa-pen', 'Tab Title', 'Rename this browser tab (blank = Cine-OS)', `<input type="text" id="cf-title" value="${esc(settings.tabTitle)}" placeholder="Cine-OS">`)}`,
      keys: () => `<h4>Panic key</h4>
        ${row('fa-triangle-exclamation', 'Panic Key', 'Press it anywhere to jump to the page below', `<input type="text" class="k" id="cf-pk" maxlength="1" value="${esc(settings.panicKey)}">`)}
        ${row('fa-link', 'Panic Destination', 'Where the panic key sends you', `<input type="text" id="cf-pu" value="${esc(settings.panicUrl)}">`)}
        <h4>Terminal commands</h4>
        <div class="cf-card cf-code"><code>sudo RS desktop</code><small>restart the desktop</small><code>sudo task main 'FigureTube'</code><small>open an app</small><code>sudo kill task 'FigureTube'</code><small>close an app</small></div>`,
      host: () => `<h4>Localhost</h4>
        <div class="cf-card cf-host"><div><strong><i class="fas fa-server"></i>&nbsp; Run Cine-OS as a localhost site</strong><small id="cf-hs">${window.cine ? 'Checking…' : 'Only available in the desktop app. In a browser you are already on a web version (npm run dev).'}</small></div>${window.cine ? '<button class="btn" id="cf-hb" disabled>…</button>' : ''}</div>
        <div class="cf-card cf-host-url hidden" id="cf-hu"><div><strong><i class="fas fa-link"></i>&nbsp; <span id="cf-hl"></span></strong><small>Only this PC can open it. It stops when you turn it off or close the app. The browser version keeps its own settings and installed apps, separate from this window.</small></div><span><button class="btn ghost" id="cf-ho"><i class="fas fa-up-right-from-square"></i> Open</button> <button class="btn ghost" id="cf-hc"><i class="fas fa-copy"></i> Copy</button></span></div>`,
      data: () => `<h4>Clear individual data</h4>
        ${row('fa-heart', 'Liked songs', 'Removes your Cine-Tunes likes', '<button class="btn ghost" data-wipe="liked,lastTrack">Clear</button>')}
        ${row('fa-bookmark', 'Saved map places', 'Removes your Cine-Maps bookmarks', '<button class="btn ghost" data-wipe="mapSaved">Clear</button>')}
        ${row('fa-terminal', 'Terminal history', 'Forgets the commands you typed', '<button class="btn ghost" data-wipe="termHist">Clear</button>')}
        <h4>Everything</h4>
        ${row('fa-trash', 'Reset Cine-OS', 'Clears saved games, likes, pins, places and settings', '<button class="btn ghost" id="cf-reset">Reset</button>')}`,
      about: () => `<h4>About</h4>
        <div class="cf-card"><div><strong>Cine/Figure OS v2.16</strong><small>${APPS.length} apps installed · ${(lsBytes() / 1024).toFixed(1)} KB of saved data</small></div></div>
        <div class="cf-card cf-apps">${APPS.map(a => `<span class="cf-app"><i class="ico ${a.img ? 'has-img' : ''}" style="background:${a.bg}">${iconHTML(a)}</i>${esc(a.name)}</span>`).join('')}</div>`,
    };

    function render() {
      $$('.cf-tabs button', root).forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
      body.innerHTML = VIEWS[tab]();
      $$('[data-k]', body).forEach(i => i.onchange = () => { settings[i.dataset.k] = i.checked; saveSettings(); });
      $$('[data-wipe]', body).forEach(b => b.onclick = () => { wipe(...b.dataset.wipe.split(',')); toast('Cleared', 'Reopen the app to see the change.'); });
      const g = $('#cf-grid', body);
      if (g) {
        const draw = () => fillWallGrid(g, () => ($('input[name=cfwpm]:checked', body) || {}).value || 'both');
        draw(); $('#cf-file', body).onchange = e => readWallFile(e.target.files[0], draw);
      }
      if ($('#cf-hb', body)) {
        const hb = $('#cf-hb', body), hs = $('#cf-hs', body), hu = $('#cf-hu', body);
        const paint = st => {
          hb.disabled = false; hb.innerHTML = st.on ? '<i class="fas fa-power-off"></i> Turn off' : '<i class="fas fa-play"></i> Turn on';
          hs.textContent = st.on ? 'Running. Open the link below in any browser on this PC.' : 'Off. Turn it on to get a http://localhost link.';
          hu.classList.toggle('hidden', !st.on); $('#cf-hl', body).textContent = st.url || '';
          $('#cf-ho', body).onclick = () => window.open(st.url, '_blank');
          $('#cf-hc', body).onclick = () => { try { navigator.clipboard.writeText(st.url); toast('Copied', st.url); } catch {} };
          hb.onclick = async () => { hb.disabled = true; const r = await window.cine.host.set(!st.on).catch(e => ({ ok: false, error: String(e.message || e) })); if (!r.ok) toast('Localhost', r.error || 'Could not change it.'); else toast('Localhost', r.on ? 'Running at ' + r.url : 'Turned off.'); paint(r); };
        };
        window.cine.host.state().then(paint).catch(() => { hs.textContent = 'Could not read the localhost status.'; });
      }
      const ep = $('#cf-prof', body); if (ep) ep.onclick = () => openProfileEditor();
      const t = $('#cf-title', body); if (t) t.oninput = e => { settings.tabTitle = e.target.value; saveSettings(); };
      const pk = $('#cf-pk', body); if (pk) pk.oninput = e => { settings.panicKey = e.target.value; saveSettings(); };
      const pu = $('#cf-pu', body); if (pu) pu.oninput = e => { settings.panicUrl = e.target.value.trim(); saveSettings(); };
      const rs = $('#cf-reset', body); if (rs) rs.onclick = () => { if (confirm('Reset all Cine-OS data?')) { Object.keys(localStorage).filter(k => k.startsWith('cine.')).forEach(k => localStorage.removeItem(k)); location.reload(); } };
    }
    $('.cf-tabs', root).onclick = e => { const b = e.target.closest('[data-tab]'); if (!b) return; tab = b.dataset.tab; LS.set('cfTab', tab); render(); };
    render();
  },
});
