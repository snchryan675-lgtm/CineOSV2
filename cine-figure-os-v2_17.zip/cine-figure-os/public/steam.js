// Cine/Figure OS - Steam
// Desktop app: the real Steam Store and Steam Community run inside the OS in their own saved browser profile, so your
// Steam sign-in sticks. Library tab: (1) the games that ship with the OS, playable right here, and (2) your Steam games,
// which start in the real Steam client on this PC (steam://run/<id>) - the store page shows PLAY / INSTALL buttons too.
// Plain browser: Library works, Store / Community open in a new tab.
const STEAM_STORE = 'https://store.steampowered.com/';
const STEAM_COMM = 'https://steamcommunity.com/';
const STEAM_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';
const STEAM_CDN = 'https://cdn.akamai.steamstatic.com/steam/apps/';
const STEAM_APP_RE = /^https?:\/\/store\.steampowered\.com\/app\/(\d+)/i;
const STEAM_FREE = [[730, 'Counter-Strike 2'], [570, 'Dota 2'], [440, 'Team Fortress 2'], [1172470, 'Apex Legends'], [230410, 'Warframe'], [1085660, 'Destiny 2'], [2767030, 'Marvel Rivals'], [238960, 'Path of Exile'], [291550, 'Brawlhalla'], [578080, 'PUBG: BATTLEGROUNDS']];

// Ask the real Steam client to do something (steam://run/730, steam://install/730, steam://open/main)
async function steamLaunch(url, okText) {
  if (window.cine && window.cine.openSteam) {
    const r = await window.cine.openSteam(url).catch(() => ({ ok: false, error: 'Could not reach the app.' }));
    return r.ok ? toast('Steam', okText) : toast('Steam client needed', (r.error || 'Could not open Steam.') + ' Install it from store.steampowered.com/about');
  }
  const a = document.createElement('a'); a.href = url; document.body.append(a); a.click(); a.remove();
  toast('Steam', okText + ' If nothing opens, install the Steam client first.');
}

// ---- Sync readers: these two functions run INSIDE the Steam web pages (via executeJavaScript), so they can't use anything from the OS ----
// 1) Steam Community: read the games page you see when signed in. Steam's old ?xml=1 list is gone; the page now carries the list as
//    JSON in a data-profile-gameslist attribute (older layouts used `var rgGames = [...]`, the oldest the XML), so try all three.
async function steamReadCommunity() {
  const out = { status: 0, loggedIn: null, games: [], via: '', error: '' };
  try {
    const r = await fetch('/my/games/?tab=all', { credentials: 'include' }); out.status = r.status;
    const t = await r.text();
    out.loggedIn = /g_steamID\s*=\s*"\d{10,}"/.test(t) ? true : /g_steamID\s*=\s*false/.test(t) ? false : null;
    const pick = a => Array.isArray(a) ? a.map(g => ({ id: +(g.appid || g.id), name: String(g.name || '').trim() })).filter(g => g.id && g.name) : [];
    const m = /data-profile-gameslist="([^"]*)"/.exec(t);
    if (m) { const ta = document.createElement('textarea'); ta.innerHTML = m[1]; try { const j = JSON.parse(ta.value); out.games = pick(j.rgGames || j.games || (j.response && j.response.games)); out.via = 'page data'; } catch (e) {} }
    if (!out.games.length) { const o = /var\s+rgGames\s*=\s*(\[[\s\S]*?\]);\s*\n/.exec(t); if (o) { try { out.games = pick(JSON.parse(o[1])); out.via = 'page script'; } catch (e) {} } }
    if (!out.games.length) {
      const x = await fetch('/my/games/?tab=all&xml=1', { credentials: 'include' }).then(r2 => r2.text()).catch(() => '');
      if (/<game>/i.test(x)) { const d = new DOMParser().parseFromString(x, 'text/xml'); out.games = [...d.querySelectorAll('game')].map(g => ({ id: +((g.querySelector('appID') || {}).textContent), name: (((g.querySelector('name') || {}).textContent) || '').trim() })).filter(g => g.id && g.name); out.via = 'xml'; }
    }
  } catch (e) { out.error = String((e && e.message) || e); }
  return out;
}
// 2) Steam Store (backup): the store knows which apps your account owns; look up the names of the newest 150 and keep only real games.
async function steamReadStore() {
  const out = { owned: 0, games: [] };
  try {
    const u = await fetch('/dynamicstore/userdata/', { credentials: 'include' }).then(r => r.json());
    const ids = Array.isArray(u.rgOwnedApps) ? u.rgOwnedApps : []; out.owned = ids.length;
    const todo = ids.slice().reverse().slice(0, 150); let i = 0;
    const worker = async () => { while (i < todo.length) { const id = todo[i++]; try { const j = await fetch('/api/appdetails?appids=' + id + '&filters=basic', { credentials: 'include' }).then(r => r.json()); const d = j && j[id] && j[id].success && j[id].data; if (d && d.type === 'game' && d.name) out.games.push({ id, name: String(d.name) }); } catch (e) {} } };
    await Promise.all([worker(), worker(), worker(), worker()]);
  } catch (e) {}
  return out;
}

registerApp({
  id: 'steam', name: 'Steam', icon: 'fa-steam', img: 'icons/steam.png', bg: 'transparent', pinned: false, store: true, onOpen,
  mount(root, w, o) {
    root.classList.add('stm');
    const desktop = !!window.cine;
    const safe = fn => { try { return fn(); } catch {} };
    const webs = {};                    // 'store' | 'community' -> { el, wcid, url, title }
    let tab = 'store', sel = null, q = '', stopGame = null, cur = null, off = null, modal = false;
    const getLib = () => LS.get('steam.lib', []);
    const setLib = l => LS.set('steam.lib', l);
    const inLib = id => getLib().some(g => g.id === id);
    const osGame = id => GAMES.find(g => g.id === id);

    root.innerHTML = `<div class="stm-bar app-head"><img src="icons/steam.png" alt=""><strong>STEAM</strong>
        <nav class="stm-tabs">${[['store', 'STORE'], ['library', 'LIBRARY'], ['community', 'COMMUNITY']].map(([t, n]) => `<button data-tab="${t}">${n}</button>`).join('')}</nav><span class="sp"></span>
        <span class="stm-nav"><button class="ib" data-a="back" title="Back"><i class="fas fa-arrow-left"></i></button><button class="ib" data-a="reload" title="Reload"><i class="fas fa-rotate-right"></i></button><button class="ib" data-a="home" title="Home"><i class="fas fa-house"></i></button></span>
        <button class="stm-client" data-a="client" title="Open the Steam client on this PC"><i class="fas fa-desktop"></i> Steam client</button></div>
      <div class="stm-view">
        <section class="stm-pane" data-p="store"><div class="stm-gbar hidden"></div><div class="stm-web"></div></section>
        <section class="stm-pane" data-p="community"><div class="stm-web"></div></section>
        <section class="stm-pane" data-p="library"><aside class="stm-side"><label class="stm-sq"><i class="fas fa-magnifying-glass"></i><input placeholder="Search your games" autocomplete="off" spellcheck="false"></label>
          <div class="stm-sbtns"><button data-a="add"><i class="fas fa-plus"></i> Add a game</button><button data-a="sync" title="Read the game list from your signed-in Steam account"><i class="fas fa-arrows-rotate"></i> Sync</button></div>
          <div class="stm-list"></div></aside><div class="stm-detail"></div><div class="stm-modal hidden"></div></section>
      </div>`;
    const pane = k => $(`[data-p="${k}"]`, root);

    /* ---------- Store / Community (real Steam web) ---------- */
    function landing(kind) {
      const url = kind === 'store' ? STEAM_STORE : STEAM_COMM, nm = kind === 'store' ? 'Steam Store' : 'Steam Community';
      return `<div class="stm-land"><img src="icons/steam.png" alt=""><h1>${nm}</h1>
        <p>The real ${nm} runs inside the desktop app (<code>npm start</code>) with your sign-in saved. In a plain browser it opens in a new tab. Your Library still works here.</p>
        <button class="stm-b blue" data-a="tab" data-url="${url}"><i class="fas fa-up-right-from-square"></i> Open ${nm}</button></div>`;
    }
    function ensureWeb(kind) {
      if (webs[kind]) return webs[kind];
      const host = $('.stm-web', pane(kind));
      if (!desktop) { host.innerHTML = landing(kind); return (webs[kind] = { el: null }); }
      window.cine.setProxy(LS.get('proxy', '')).catch(() => {});
      const el = document.createElement('webview');
      el.setAttribute('src', kind === 'store' ? STEAM_STORE : STEAM_COMM);
      el.setAttribute('partition', 'persist:steam'); // one saved profile for Store + Community, so your sign-in sticks
      el.setAttribute('useragent', STEAM_UA);
      el.setAttribute('allowpopups', '');
      const rec = (webs[kind] = { el, wcid: null, url: '', title: '' });
      el.addEventListener('dom-ready', () => safe(() => { rec.wcid = el.getWebContentsId(); }));
      const nav = e => { rec.url = (e && e.url) || safe(() => el.getURL()) || rec.url; if (kind === 'store') gameBar(); };
      el.addEventListener('did-navigate', nav); el.addEventListener('did-navigate-in-page', nav);
      el.addEventListener('page-title-updated', e => { rec.title = e.title || ''; if (kind === 'store') gameBar(); });
      host.append(el);
      return rec;
    }
    if (desktop) off = window.cine.onOpenUrl(({ from, url }) => { const r = Object.values(webs).find(x => x.wcid === from); if (r) safe(() => r.el.loadURL(url)); }); // sign-in popups load in the same view

    // on a game's store page: PLAY / INSTALL (in the real Steam client) and Add to library
    function gameBar() {
      const bar = $('.stm-gbar', root), rec = webs.store, m = rec && STEAM_APP_RE.exec(rec.url || '');
      if (!m) { cur = null; bar.classList.add('hidden'); return; }
      const id = +m[1], name = (rec.title || '').replace(/^Save \d+% on /i, '').replace(/\s+on Steam$/i, '').trim() || 'App ' + id;
      cur = { id, name }; const have = inLib(id);
      bar.classList.remove('hidden');
      bar.innerHTML = `<img src="${STEAM_CDN}${id}/capsule_184x69.jpg" alt=""><div class="nm"><strong>${esc(name)}</strong><small>Steam game · App ${id}</small></div><span class="sp"></span>
        <button class="stm-b play" data-a="run" data-id="${id}"><i class="fas fa-play"></i> PLAY</button>
        <button class="stm-b blue" data-a="install" data-id="${id}"><i class="fas fa-download"></i> INSTALL</button>
        <button class="stm-b ghost" data-a="addcur">${have ? '<i class="fas fa-check"></i> IN LIBRARY' : '<i class="fas fa-plus"></i> ADD TO LIBRARY'}</button>`;
    }

    /* ---------- Library ---------- */
    const capsule = id => `${STEAM_CDN}${id}/header.jpg`;
    const img = (src, fb, cls = '') => `<img class="${cls}" src="${esc(src)}" ${fb ? `data-fb="${esc(fb)}"` : ''} alt="" draggable="false" loading="lazy">`;
    root.addEventListener('error', e => { const t = e.target; if (t.tagName !== 'IMG') return; if (t.dataset.fb && !t.dataset.tried) { t.dataset.tried = 1; t.src = t.dataset.fb; } else t.style.visibility = 'hidden'; }, true);

    function addGame(id, name, quiet) {
      const l = getLib(); if (l.some(g => g.id === id)) return false;
      l.push({ id, name: String(name || 'App ' + id).slice(0, 120) }); setLib(l);
      if (!quiet) toast('Added to library', name);
      return true;
    }
    function renderList() {
      const k = q.trim().toLowerCase(), by = n => !k || n.toLowerCase().includes(k);
      const st = getLib().filter(g => by(g.name)).sort((a, b) => a.name.localeCompare(b.name)), os = GAMES.filter(g => by(g.name));
      const row = (key, ico, fb, name, sub) => `<div class="stm-row${sel === key ? ' on' : ''}" data-k="${key}">${img(ico, fb)}<span><b>${esc(name)}</b><small>${esc(sub)}</small></span></div>`;
      $('.stm-list', root).innerHTML =
        `<h5>STEAM GAMES<em>${st.length}</em></h5>${st.length ? st.map(g => row('st:' + g.id, capsule(g.id), '', g.name, 'Steam client')).join('') : `<p class="stm-none">${k ? 'No matches.' : 'No Steam games yet. Press <b>Add a game</b>, or <b>Sync</b> after signing in on the Community tab.'}</p>`}
         <h5>PLAYABLE IN THE OS<em>${os.length}</em></h5>${os.length ? os.map(g => row('os:' + g.id, g.ico, '', g.name, g.tag)).join('') : '<p class="stm-none">No matches.</p>'}`;
    }
    function renderDetail() {
      const box = $('.stm-detail', root);
      if (!sel) { const last = LS.get('lastGame'); sel = last && osGame(last.id) ? 'os:' + last.id : 'os:' + GAMES[0].id; renderList(); }
      const [type, rid] = sel.split(':');
      if (type === 'os') {
        const g = osGame(rid); if (!g) { sel = null; return renderDetail(); }
        box.innerHTML = `<div class="stm-hero" style="--g1:${g.c[0]};--g2:${g.c[1]}"><i style="background-image:url('${esc(g.img)}')"></i><div class="in">${img(g.ico, '', 'hi')}<div><small>${esc(g.tag)}</small><h1>${esc(g.name)}</h1></div></div></div>
          <div class="stm-acts"><button class="stm-b play big" data-a="playos" data-id="${g.id}"><i class="fas fa-play"></i> PLAY</button><span class="stm-meta"><b>Ready</b>Runs right here in the OS. Use the back button at the top left to leave a game.</span></div>
          <div class="stm-info"><h4>About</h4><p>${esc(g.name)} · ${esc(g.tag)}. This game ships with the OS and needs no download or Steam client.</p></div>`;
      } else {
        const id = +rid, g = getLib().find(x => x.id === id); if (!g) { sel = null; return renderDetail(); }
        box.innerHTML = `<div class="stm-hero steam"><i style="background-image:url('${STEAM_CDN}${id}/library_hero.jpg'),url('${capsule(id)}')"></i><div class="in">${img(capsule(id), '', 'hc')}<div><small>STEAM GAME</small><h1>${esc(g.name)}</h1></div></div></div>
          <div class="stm-acts"><button class="stm-b play big" data-a="run" data-id="${id}"><i class="fas fa-play"></i> PLAY</button><button class="stm-b blue" data-a="install" data-id="${id}"><i class="fas fa-download"></i> INSTALL</button><button class="stm-b ghost" data-a="storepage" data-id="${id}"><i class="fas fa-store"></i> STORE PAGE</button><button class="stm-b ghost" data-a="remove" data-id="${id}" title="Remove from library"><i class="fas fa-trash"></i></button></div>
          <div class="stm-info"><h4>How it plays</h4><p>Steam games start in the real Steam client on this PC. Sign in to the Steam client once, then PLAY launches ${esc(g.name)} (and INSTALL downloads it first). Steam App ${id}.</p></div>`;
      }
    }
    function selectKey(k) { sel = k; renderList(); renderDetail(); }

    function playOs(id) {
      const g = osGame(id); if (!g) return;
      stopGame && stopGame();
      LS.set('lastGame', { id: g.id, name: g.name }); bus.dispatchEvent(new Event('sidebar'));
      const ov = document.createElement('div'); ov.className = 'cp-frame';
      ov.innerHTML = `<iframe src="${esc(g.file)}" title="${esc(g.name)}" allow="autoplay; fullscreen; gamepad; clipboard-write; cross-origin-isolated" allowfullscreen></iframe><button class="cp-exit" title="Exit game"><i class="fas fa-chevron-left"></i> <img src="${esc(g.ico)}" alt=""> ${esc(g.name)}</button>`;
      document.body.append(ov); // on <body> so it sits above the taskbar
      const f = $('iframe', ov); f.addEventListener('load', () => safe(() => f.contentWindow.focus()));
      const onKey = e => { if (e.key === 'Escape') stopGame && stopGame(); };
      addEventListener('keydown', onKey);
      stopGame = () => { removeEventListener('keydown', onKey); ov.remove(); stopGame = null; renderDetail(); };
      $('.cp-exit', ov).onclick = () => stopGame();
    }

    /* ---------- Add a game (search the Steam store) ---------- */
    let seq = 0, timer = 0;
    function openModal() {
      modal = true; const m = $('.stm-modal', root); m.classList.remove('hidden');
      m.innerHTML = `<div class="stm-box"><button class="stm-x" data-a="closemodal" aria-label="Close"><i class="fas fa-xmark"></i></button><h3>Add a Steam game</h3>
        <label class="stm-sq big"><i class="fas fa-magnifying-glass"></i><input placeholder="Search the Steam store" autocomplete="off" spellcheck="false"></label>
        <div class="stm-res"></div></div>`;
      showSuggest(); const i = $('input', m); i.oninput = () => { clearTimeout(timer); timer = setTimeout(() => search(i.value), 350); }; i.focus();
    }
    function closeModal() { modal = false; $('.stm-modal', root).classList.add('hidden'); }
    const resRow = (id, name, sub) => `<div class="stm-rr">${img(capsule(id), '', 'rc')}<span><b>${esc(name)}</b><small>${esc(sub)}</small></span>${inLib(id) ? '<button class="stm-b ghost" disabled><i class="fas fa-check"></i> ADDED</button>' : `<button class="stm-b play" data-a="addres" data-id="${id}" data-n="${esc(name)}">ADD</button>`}</div>`;
    function showSuggest() { $('.stm-res', root).innerHTML = `<h5>POPULAR FREE-TO-PLAY</h5>${STEAM_FREE.map(([id, n]) => resRow(id, n, 'Free to play')).join('')}`; }
    async function search(term) {
      term = term.trim(); const mine = ++seq; const res = $('.stm-res', root); if (!res) return;
      if (!term) return showSuggest();
      res.innerHTML = '<p class="stm-none">Searching Steam…</p>';
      const d = await api('/api/steam/search?q=' + encodeURIComponent(term)).catch(() => null);
      if (mine !== seq || !modal) return;
      if (!d || d.error) res.innerHTML = '<p class="stm-none">Could not reach Steam. You can also add a game with ADD TO LIBRARY on its store page.</p>';
      else res.innerHTML = d.results.length ? d.results.map(r => resRow(r.id, r.name, r.price)).join('') : `<p class="stm-none">No games found for “${esc(term)}”.</p>`;
    }

    /* ---------- Sync owned games from the signed-in account (best effort) ---------- */
    const waitReady = (rec, ms = 15000) => new Promise(res => { const t0 = Date.now(); (function tick() { if (rec.wcid) return res(true); if (Date.now() - t0 > ms) return res(false); setTimeout(tick, 200); })(); });
    const runIn = async (rec, fn) => { try { return await rec.el.executeJavaScript('(' + fn.toString() + ')()'); } catch { return null; } };
    let syncing = false;
    async function sync() {
      if (!desktop) return toast('Sync needs the desktop app', 'Run the OS with npm start to read your Steam account.');
      if (syncing) return; syncing = true;
      try {
        toast('Steam', 'Reading your game list…', 3000);
        const com = ensureWeb('community');
        if (!(await waitReady(com))) return toast('Steam is still loading', 'Open the Community tab, wait for the page, then press Sync again.');
        if (!/^https?:\/\/steamcommunity\.com\//i.test(com.url || safe(() => com.el.getURL()) || '')) { // the view is somewhere else: go to the Community home first
          await new Promise(res => { const done = () => { com.el.removeEventListener('did-finish-load', done); res(); }; com.el.addEventListener('did-finish-load', done); safe(() => com.el.loadURL(STEAM_COMM)); setTimeout(done, 12000); });
        }
        const a = await runIn(com, steamReadCommunity);
        let list = a && a.games || [];
        if (a && a.loggedIn === false) return toast('Sign in first', 'You are not signed in to Steam. Open the Community tab, sign in, then press Sync again.', 7000);
        if (!list.length) { // backup: ask the Steam Store which apps this account owns
          toast('Steam', 'Trying another way (this can take a minute)…', 6000);
          const st = ensureWeb('store');
          if (await waitReady(st)) { const b = await runIn(st, steamReadStore); if (b && b.games.length) list = b.games; }
        }
        if (!list.length) return toast("Couldn't find your games", a && a.loggedIn ? 'You are signed in, but Steam returned no games. If your library is private, set Game details to Public in Steam (Profile > Edit Profile > Privacy Settings), or use Add a game.' : 'Make sure you are signed in on the Community tab, or use Add a game.', 9000);
        let n = 0; list.slice(0, 3000).forEach(g => { if (addGame(g.id, g.name, true)) n++; });
        toast('Library synced', n ? `${n} Steam games added.` : 'Everything was already in your library.'); renderList(); renderDetail();
      } finally { syncing = false; }
    }

    /* ---------- tabs ---------- */
    function show(t) {
      tab = t; closeModal();
      $$('.stm-tabs button', root).forEach(b => b.classList.toggle('on', b.dataset.tab === t));
      $$('.stm-pane', root).forEach(p => p.classList.toggle('on', p.dataset.p === t));
      $('.stm-nav', root).classList.toggle('hidden', t === 'library' || !desktop);
      if (t === 'library') { renderList(); renderDetail(); } else ensureWeb(t);
    }

    root.addEventListener('click', e => {
      const T = e.target.closest('[data-tab]'); if (T) return show(T.dataset.tab);
      const R = e.target.closest('.stm-row'); if (R) return selectKey(R.dataset.k);
      const b = e.target.closest('[data-a]'); if (!b) return;
      const a = b.dataset.a, id = +b.dataset.id, rec = webs[tab];
      if (a === 'back') return rec && rec.el && safe(() => rec.el.goBack());
      if (a === 'reload') return rec && rec.el && safe(() => rec.el.reload());
      if (a === 'home') return rec && rec.el && safe(() => rec.el.loadURL(tab === 'store' ? STEAM_STORE : STEAM_COMM));
      if (a === 'client') return steamLaunch('steam://open/main', 'Opening the Steam client…');
      if (a === 'tab') return window.open(b.dataset.url, '_blank', 'noopener');
      if (a === 'run') return steamLaunch('steam://run/' + id, 'Starting the game in Steam…');
      if (a === 'install') return steamLaunch('steam://install/' + id, 'Opening the Steam install window…');
      if (a === 'playos') return playOs(b.dataset.id);
      if (a === 'add') return openModal();
      if (a === 'sync') return sync();
      if (a === 'closemodal') return closeModal();
      if (a === 'addcur') { if (cur && addGame(cur.id, cur.name)) gameBar(); else if (cur) toast('Already in your library', cur.name); return; }
      if (a === 'addres') { if (addGame(id, b.dataset.n)) { b.outerHTML = '<button class="stm-b ghost" disabled><i class="fas fa-check"></i> ADDED</button>'; renderList(); } return; }
      if (a === 'storepage') { show('store'); const r = ensureWeb('store'); return r.el && safe(() => r.el.loadURL(`${STEAM_STORE}app/${id}/`)); }
      if (a === 'remove') { const g = getLib().find(x => x.id === id); setLib(getLib().filter(x => x.id !== id)); toast('Removed', (g ? g.name : 'Game') + ' is no longer in your library.'); sel = null; renderList(); renderDetail(); return; }
    });
    root.addEventListener('dblclick', e => { const R = e.target.closest('.stm-row'); if (!R) return; const [t, id] = R.dataset.k.split(':'); t === 'os' ? playOs(id) : steamLaunch('steam://run/' + id, 'Starting the game in Steam…'); });
    $('.stm-sq input', root).oninput = e => { q = e.target.value; renderList(); };
    root.addEventListener('keydown', e => { if (e.key === 'Escape' && modal) { closeModal(); e.stopPropagation(); } });

    w.onclose = () => { stopGame && stopGame(); off && off(); clearTimeout(timer); };
    w.opts = o2 => { if (!o2) return; if (o2.game && osGame(o2.game)) { show('library'); selectKey('os:' + o2.game); return playOs(o2.game); } if (o2.tab) show(o2.tab); };
    show((o && o.tab) || 'store'); if (o && o.game) w.opts(o);
  },
});
