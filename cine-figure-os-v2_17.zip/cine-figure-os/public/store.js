// Cine/Figure OS - App Store (v2.7: featured carousel, categories, install rings, detail panel)
const STORE_INFO = {
  figuretube: {
    cat: 'Entertainment', sub: 'Videos', tag: 'Watch anything', g: ['#3d0b0b', '#e62117'],
    desc: 'Search and watch real videos.',
    long: 'FigureTube is real YouTube search and playback, right inside the OS. Browse with the side panel, watch videos full size, jump to related videos, or flick through Figure Shorts, a full-height vertical feed.',
    feats: ['Real YouTube search and playback', 'Figure Shorts: a vertical short-video feed', 'Side panel you can hide or show', 'Related videos next to the player', 'Opens in its own window on your taskbar'],
  },
  tunes: {
    cat: 'Entertainment', sub: 'Music', tag: 'Full songs, no limits', g: ['#06301d', '#1db954'],
    desc: 'Full songs, albums, artist profiles and a mini player.',
    long: 'Cine-Tunes finds songs and plays them in full with a real timeline. Browse albums with full track lists, open artist profiles with top songs, discography and a short bio, and use the Now Playing screen for big cover art. Close the app while a song plays and it shrinks into a mini player so the music keeps going.',
    feats: ['Plays full songs with a seekable timeline', 'Albums with full track lists', 'Artist profiles: top songs, albums, bio', 'Now Playing screen, shuffle and repeat', 'Mini player keeps music going'],
  },
  flix: {
    cat: 'Entertainment', sub: 'Movies & Shows', tag: 'Movies & shows', g: ['#3a0a0e', '#e50914'],
    desc: 'The real movy.sx site, right in the OS.',
    long: 'CineFlix runs movy.sx inside the OS with its own saved sign-in. Ad popups are dropped, and it follows the proxy you set in Cine-Web.',
    feats: ['The real movy.sx site, in a window', 'Your sign-in is saved inside the OS', 'Ad popups are blocked', 'Follows your proxy setting'],
  },
  play: {
    cat: 'Games', sub: 'Game launcher', tag: 'Your game library', g: ['#0a1a4a', '#2f5cff'],
    desc: 'Game launcher with your HTML games.',
    long: 'Cine-Play is a console-style launcher for the HTML games that ship with the OS. Add a game to your library, then play it full screen.',
    feats: ['Cover art and icons for every game', 'Library and a random-game picker', 'Jump back in from the home screen'],
  },
  xbox: {
    cat: 'Games', sub: 'Cloud Gaming', tag: 'New · Cloud Gaming', g: ['#0b3d0b', '#107c10', '#9bf00b'],
    desc: 'Xbox Cloud Gaming, right in the OS.',
    long: 'Xbox Cloud Gaming in your OS. Sign in once and stream your games. In the desktop app it keeps its own profile, so your Microsoft sign-in stays.',
    feats: ['Xbox Cloud Gaming (xbox.com/play)', 'Sign-in is saved in the desktop app', 'Follows your proxy setting'],
  },
  steam: {
    cat: 'Games', sub: 'PC Gaming', tag: 'New · PC Gaming', g: ['#0e1722', '#1b2838', '#2a6f9e'],
    desc: 'The real Steam store, plus a library you can play from.',
    long: 'Steam in your OS. The real Steam Store and Community run in their own saved profile, so you sign in once. Your Library holds the games that ship with the OS (playable right here) and your Steam games, which start in the Steam client on your PC with PLAY. Game store pages get PLAY, INSTALL and Add to library buttons.',
    feats: ['The real store.steampowered.com and Steam Community', 'Sign-in is saved in the desktop app', 'PLAY / INSTALL buttons on every game page (uses the Steam client)', 'Library: add games by search or sync your account', 'Plays the OS games right inside the window', 'Follows your proxy setting'],
  },
  obs: {
    cat: 'Tools', sub: 'Screen recording', tag: 'New · Record the OS', g: ['#14161b', '#2b2f3a', '#e5484d'],
    desc: 'OBS-style scenes, sources and recording of the OS only.',
    long: 'OBS Studio for the OS: build scenes from the OS itself, images, text, colours and a camera, mix audio and record. OS Capture sees only the Cine/Figure OS window, never your desktop or other apps.',
    feats: ['Records only the OS, not your PC', 'Scenes, sources, drag and resize in the preview', 'Mic mixer, fade / cut transitions, screenshots', 'WebM or MP4 recording with pause and resume', 'Ctrl+Shift+R starts and stops recording'],
  },
  discord: {
    cat: 'Social', sub: 'Chat & Voice', tag: 'Talk to your friends', g: ['#1b1e4f', '#5865f2'],
    desc: 'Discord, signed in and saved in the OS.',
    long: 'The real Discord web app, signed in and saved inside the OS, so your servers and DMs are one click away on the taskbar.',
    feats: ['The real discord.com web app', 'Stay signed in between sessions', 'Follows your proxy setting'],
  },
  tiktok: {
    cat: 'Social', sub: 'Short Videos', tag: 'New · Short videos', g: ['#0a0a0a', '#0e4a4f', '#fe2c55'],
    desc: 'TikTok, signed in and saved in the OS.',
    long: 'The real TikTok web app (tiktok.com/en), running inside the OS in its own saved profile, so your login and your For You feed are one click away on the taskbar.',
    feats: ['The real tiktok.com web app', 'Stay signed in between sessions', 'Follows your proxy setting'],
  },
  maps: {
    cat: 'Tools', sub: 'Maps & Navigation', tag: 'Find your way', g: ['#0b3b4a', '#12b886', '#1c7ed6'],
    desc: 'Our own maps with directions.',
    long: 'Cine-Maps is our own map app built on open data: search places, browse what is nearby, get directions and save the spots you care about.',
    feats: ['Street, Light, Dark, Satellite and Terrain styles', 'Driving, walking and cycling directions', 'Nearby categories and saved places', 'Measure tool and my-location'],
  },
  web: {
    cat: 'Tools', sub: 'Browser', tag: 'Browse anything', g: ['#1a1d33', '#4d7cff'],
    desc: 'Tabbed browser with its own search and a proxy switch.',
    long: 'Cine-Web is a tabbed browser with its own search engine. Set a proxy with the shield button and the browser, CineFlix and Discord all follow it.',
    feats: ['Tabs and the Cine-Search results page', 'Proxy switch (socks5 or http)', 'Every tab is a full browser view'],
  },
};
const STORE_HIDE = ['terminal', 'config', 'appstore'];
const STORE_CATS = ['Entertainment', 'Games', 'Social', 'Tools'];
const STORE_CAT_ICON = { All: 'fa-border-all', Entertainment: 'fa-clapperboard', Games: 'fa-gamepad', Social: 'fa-comments', Tools: 'fa-screwdriver-wrench' };
const STORE_FEATURED = ['steam', 'xbox', 'discord', 'flix', 'maps', 'tunes', 'tiktok'];

registerApp({
  id: 'appstore', name: 'App Store', icon: 'fa-store', img: 'icons/appstore.png', bg: 'transparent', pinned: true,
  mount(root, w, o) {
    root.classList.add('st');
    let q = (o && o.q) || '', tab = 'discover', cat = 'All', slide = 0, hover = false, detailId = null;
    const prog = {};

    const info = a => STORE_INFO[a.id] || { cat: 'Tools', sub: 'App', tag: '', g: ['#1e1f22', '#5865f2'], desc: '', long: '', feats: [] };
    const grad = a => { const g = info(a).g; return `linear-gradient(125deg,${g.join(',')})`; };
    const apps = () => APPS.filter(a => !STORE_HIDE.includes(a.id));
    const find = id => APPS.find(a => a.id === id);
    const match = a => { const i = info(a); return !q.trim() || (a.name + ' ' + i.sub + ' ' + i.cat + ' ' + i.desc).toLowerCase().includes(q.trim().toLowerCase()); };

    const ico = a => `<div class="st-ico" style="background:${a.img ? 'transparent' : a.bg}">${iconHTML(a, ' style="color:#fff"')}</div>`;
    const btnHTML = a => {
      if (prog[a.id] != null) { const p = Math.round(prog[a.id] * 100); return `<button class="st-btn busy" disabled><span class="ring" style="--p:${p}"></span><b>${p}%</b></button>`; }
      return isInstalled(a) ? '<button class="st-btn open" data-a="open">OPEN</button>' : '<button class="st-btn get" data-a="get">GET</button>';
    };
    const act = a => `<span class="st-act" data-bid="${a.id}">${btnHTML(a)}</span>`;
    const paintBtn = (id, pop) => { const a = find(id); if (!a) return; $$(`.st-act[data-bid="${id}"]`, root).forEach(s => { s.innerHTML = btnHTML(a); if (pop) s.firstElementChild.classList.add('pop'); }); };
    const setProg = (id, p) => $$(`.st-act[data-bid="${id}"]`, root).forEach(s => { const r = $('.ring', s), b = $('b', s); if (r) r.style.setProperty('--p', Math.round(p * 100)); if (b) b.textContent = Math.round(p * 100) + '%'; });

    const card = (a, i) => { const f = info(a);
      return `<article class="st-card" data-id="${a.id}" style="--i:${i}">${ico(a)}<div class="st-meta"><strong>${esc(a.name)}</strong><small>${esc(f.cat)} · ${esc(f.sub)}</small><p>${esc(f.desc)}</p></div>${act(a)}</article>`; };
    const section = (title, icon, list, start = 0) => list.length ? `<section class="st-sec"><h3><i class="fas ${icon}"></i>${esc(title)}</h3><div class="st-grid">${list.map((a, i) => card(a, start + i)).join('')}</div></section>` : '';

    const heroHTML = () => {
      const list = STORE_FEATURED.map(find).filter(Boolean);
      if (!list.length) return '';
      return `<section class="st-hero"><div class="st-slides">${list.map((a, i) => { const f = info(a);
        return `<div class="st-slide${i === slide ? ' on' : ''}" data-id="${a.id}" style="background:${grad(a)}"><span class="orb"></span>
          <div class="txt"><small>${esc(f.tag)}</small><h2>${esc(a.name)}</h2><p>${esc(f.long)}</p><div class="row">${act(a)}<button class="st-more" data-more="${a.id}">Details<i class="fas fa-arrow-right"></i></button></div></div>
          <div class="art">${ico(a)}</div></div>`; }).join('')}</div>
        <div class="st-dots">${list.map((a, i) => `<button class="${i === slide ? 'on' : ''}" data-dot="${i}" aria-label="${esc(a.name)}"></button>`).join('')}</div></section>`;
    };

    const empty = (icon, title, sub) => `<div class="st-empty"><i class="fas ${icon}"></i><strong>${esc(title)}</strong><span>${esc(sub)}</span></div>`;

    function renderBody(animate = true) {
      const body = $('.st-body', root), searching = !!q.trim();
      body.classList.toggle('still', !animate);
      let html;
      if (tab === 'installed') {
        const l = apps().filter(a => isInstalled(a) && match(a) && (cat === 'All' || info(a).cat === cat));
        html = l.length ? `<section class="st-sec"><h3><i class="fas fa-circle-check"></i>Installed<span>${l.length}</span></h3><div class="st-grid">${l.map(card).join('')}</div></section>`
          : empty('fa-box-open', searching ? 'No installed apps match' : 'Nothing installed here yet', searching ? 'Try a different search word.' : 'Find something you like in Discover and press GET.');
      } else if (searching || cat !== 'All') {
        const l = apps().filter(a => match(a) && (cat === 'All' || info(a).cat === cat));
        html = l.length ? `<section class="st-sec"><h3><i class="fas ${searching ? 'fa-magnifying-glass' : STORE_CAT_ICON[cat]}"></i>${searching ? 'Results' : esc(cat)}<span>${l.length}</span></h3><div class="st-grid">${l.map(card).join('')}</div></section>`
          : empty('fa-face-frown-open', 'No apps found', 'Try a different word, or clear the category filter.');
      } else {
        let n = 0;
        html = heroHTML() + STORE_CATS.map(c => { const l = apps().filter(a => info(a).cat === c); const s = section(c, STORE_CAT_ICON[c], l, n); n += l.length; return s; }).join('');
      }
      body.innerHTML = html; body.scrollTop = 0;
    }
    function updateChrome() {
      $$('.st-tabs button', root).forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
      $$('.st-chips button', root).forEach(b => b.classList.toggle('on', b.dataset.cat === cat));
      $('.st-cnt', root).textContent = apps().filter(isInstalled).length;
      $('.st-search', root).classList.toggle('has', !!q);
      const on = $('.st-tabs button.on', root), ind = $('.st-ind', root);
      if (on && ind) { ind.style.width = on.offsetWidth + 'px'; ind.style.transform = `translateX(${on.offsetLeft}px)`; }
    }

    /* ---- detail panel ---- */
    function renderDetail() {
      const wrap = $('.st-detail-wrap', root), a = detailId && find(detailId);
      if (!a) { wrap.classList.remove('open'); detailId = null; return; }
      const f = info(a), inst = isInstalled(a);
      wrap.innerHTML = `<div class="st-back" data-close></div><aside class="st-detail">
        <button class="st-x" data-close aria-label="Close"><i class="fas fa-xmark"></i></button>
        <div class="st-d-hero" style="background:${grad(a)}"><span class="orb"></span>${ico(a)}<div><h2>${esc(a.name)}</h2><small>${esc(f.cat)} · ${esc(f.sub)}</small></div>${act(a)}</div>
        <div class="st-d-body"><p class="lead">${esc(f.long || f.desc)}</p>
          ${f.feats.length ? `<h4>What you get</h4><ul>${f.feats.map(x => `<li><i class="fas fa-check"></i>${esc(x)}</li>`).join('')}</ul>` : ''}
          <h4>Information</h4><dl><div><dt>Category</dt><dd>${esc(f.cat)}</dd></div><div><dt>Source</dt><dd>${a.store ? 'App Store' : 'Built into the OS'}</dd></div><div><dt>Status</dt><dd class="${inst ? 'ok' : ''}">${inst ? 'Installed' : 'Not installed'}</dd></div></dl>
          ${a.store && inst ? `<button class="st-un" data-un="${a.id}"><i class="fas fa-trash"></i>Uninstall ${esc(a.name)}</button>` : ''}</div></aside>`;
      requestAnimationFrame(() => wrap.classList.add('open'));
    }
    function openDetail(id) { detailId = id; renderDetail(); }
    function closeDetail() { const wrap = $('.st-detail-wrap', root); wrap.classList.remove('open'); detailId = null; setTimeout(() => { if (!detailId) wrap.innerHTML = ''; }, 260); }

    /* ---- install / uninstall ---- */
    function install(id) {
      const app = find(id); if (!app || prog[id] != null || isInstalled(app)) return;
      prog[id] = 0; paintBtn(id);
      const t0 = Date.now(), D = 1500 + Math.random() * 700;
      const iv = setInterval(() => {
        const x = Math.min(1, (Date.now() - t0) / D); prog[id] = x < .5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2; setProg(id, prog[id]);
        if (x < 1) return;
        clearInterval(iv); delete prog[id]; installApp(id); togglePin(id, true);
        toast('Installed', app.name + ' was added to your taskbar.');
        paintBtn(id, true); updateChrome(); if (detailId === id) renderDetail(); if (tab === 'installed') renderBody(false);
      }, 40);
    }
    function uninstall(id) {
      const app = find(id); if (!app || !app.store) return;
      closeApp(id); uninstallApp(id); togglePin(id, false); toast('Uninstalled', app.name);
      paintBtn(id); updateChrome(); if (detailId === id) renderDetail(); if (tab === 'installed') renderBody(false);
    }

    /* ---- carousel ---- */
    function go(n) {
      const s = $$('.st-slide', root); if (!s.length) return;
      const old = slide; slide = (n + s.length) % s.length;
      s.forEach((el, i) => { el.classList.toggle('on', i === slide); el.classList.toggle('prev', i === old && i !== slide); });
      $$('.st-dots button', root).forEach((d, i) => d.classList.toggle('on', i === slide));
    }
    const timer = setInterval(() => { if (!hover && !detailId && root.isConnected && $('.st-slide', root) && $('.st-hero', root).offsetParent) go(slide + 1); }, 5500);
    const prevClose = w.onclose; w.onclose = () => { clearInterval(timer); prevClose && prevClose(); };

    /* ---- shell (built once so typing in the search box never loses focus) ---- */
    root.innerHTML = `<header class="st-head"><h1><img src="icons/appstore.png" alt=""><span>App Store</span></h1>
        <label class="st-search"><i class="fas fa-magnifying-glass"></i><input placeholder="Search apps" value="${esc(q)}" autocomplete="off" spellcheck="false"><button type="button" class="st-clr" aria-label="Clear"><i class="fas fa-xmark"></i></button></label></header>
      <nav class="st-nav"><div class="st-tabs"><i class="st-ind"></i><button data-tab="discover"><i class="fas fa-compass"></i>Discover</button><button data-tab="installed"><i class="fas fa-circle-check"></i>Installed<em class="st-cnt"></em></button></div>
        <div class="st-chips">${['All', ...STORE_CATS].map(c => `<button data-cat="${c}"><i class="fas ${STORE_CAT_ICON[c]}"></i>${c}</button>`).join('')}</div></nav>
      <div class="st-body"></div><div class="st-detail-wrap"></div>`;

    const inp = $('input', root);
    inp.oninput = e => { q = e.target.value; updateChrome(); renderBody(false); };
    $('.st-clr', root).onclick = () => { q = ''; inp.value = ''; updateChrome(); renderBody(); inp.focus(); };
    root.addEventListener('mouseover', e => { hover = !!e.target.closest('.st-hero'); });
    root.onclick = e => {
      const t = e.target;
      let el;
      if ((el = t.closest('[data-tab]'))) { tab = el.dataset.tab; updateChrome(); return renderBody(); }
      if ((el = t.closest('[data-cat]'))) { cat = el.dataset.cat; updateChrome(); return renderBody(); }
      if ((el = t.closest('[data-dot]'))) return go(+el.dataset.dot);
      if ((el = t.closest('[data-close]'))) return closeDetail();
      if ((el = t.closest('[data-un]'))) return uninstall(el.dataset.un);
      if ((el = t.closest('[data-more]'))) return openDetail(el.dataset.more);
      if ((el = t.closest('[data-a]'))) {
        const id = el.closest('[data-bid]').dataset.bid;
        return el.dataset.a === 'open' ? launchApp(id) : install(id);
      }
      if ((el = t.closest('.st-card'))) openDetail(el.dataset.id);
    };
    root.oncontextmenu = e => {
      const r = e.target.closest('.st-card'); if (!r) return;
      const app = find(r.dataset.id);
      if (!app || !app.store || !isInstalled(app)) return;
      e.preventDefault(); e.stopPropagation();
      ctxMenu(e, [['fa-trash', 'Uninstall ' + app.name, () => uninstall(app.id)]]);
    };
    w.onOpen = o2 => { if (o2 && o2.q) { q = o2.q; tab = 'discover'; cat = 'All'; inp.value = q; closeDetail(); renderBody(); } updateChrome(); };
    updateChrome(); renderBody();
    requestAnimationFrame(updateChrome);
  },
  onOpen(w, o) { w.onOpen && w.onOpen(o); },
});
