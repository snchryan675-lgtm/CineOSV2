// Cine-Terminal 1.2: a tiny shell for Cine/Figure OS (starts with a CINE OS banner drawn from | and /)
//   sudo RS desktop            restart the desktop
//   sudo task main 'AppName'   open an app
//   sudo kill task 'AppName'   close an app
//   sudo install 'AppName'     install an App Store app  (sudo uninstall 'AppName' removes it)
//   plus neofetch, fortune, cowsay, matrix, calc, dice, ... (type "help")
registerApp({
  id: 'terminal', name: 'Terminal', icon: 'fa-terminal', bg: 'linear-gradient(135deg,#2a2a33,#050507)', pinned: true, onOpen,
  mount(root, w) {
    root.classList.add('tm');
    root.innerHTML = `<div class="tm-out"></div>
      <form class="tm-line"><span class="tm-ps">${esc(getProfile().handle)}@cine-os:~$</span><input spellcheck="false" autocomplete="off" autocapitalize="off" autofocus></form>`;
    const out = $('.tm-out', root), input = $('input', root);
    const hist = LS.get('termHist', []); let hp = hist.length;
    const norm = s => String(s).toLowerCase().replace(/[^a-z0-9]/g, '');
    const pids = {}; let nextPid = 1000;

    const print = (text, cls = '') => {
      const d = document.createElement('div'); d.className = 'tm-l ' + cls; d.textContent = text; out.append(d); out.scrollTop = out.scrollHeight; return d;
    };
    const printHTML = html => { const d = document.createElement('div'); d.className = 'tm-l'; d.innerHTML = html; out.append(d); out.scrollTop = out.scrollHeight; };
    const tokenize = s => [...s.matchAll(/"([^"]*)"|'([^']*)'|(\S+)/g)].map(m => m[1] ?? m[2] ?? m[3]);

    function findApp(name) {
      const n = norm(name); if (!n) return null;
      return APPS.find(a => norm(a.id) === n || norm(a.name) === n)
        || APPS.find(a => norm(a.name).startsWith(n) || norm(a.id).startsWith(n)) || null;
    }
    const noApp = name => print(`No app called "${name}". Type "apps" to see what's installed.`, 'bad');

    const HELP = [
      ['# apps'],
      ['sudo install \'AppName\'', 'install an App Store app (also: sudo install list)'],
      ['sudo uninstall \'AppName\'', 'remove an installed app'],
      ["sudo task main 'AppName'", 'open an app, e.g. sudo task main FigureTube'],
      ["sudo kill task 'AppName'", 'close a running app'],
      ['open <app> · apps · store · tasks', 'open an app, list apps, list the store, list running apps'],
      ['# system'],
      ['sudo RS desktop', 'restart the desktop (also: sudo reboot)'],
      ['neofetch · uptime · version · lock', 'system info, how long it has been up, lock the screen'],
      ['date · whoami · pwd · ls · echo · history · clear', 'the usual basics'],
      ['# search'],
      ['music <words> · yt <words> · web <words>', 'search Cine-Tunes, FigureTube or the web (shorts opens Figure Shorts)'],
      ['# Cine-Tunes remote'],
      ['np · play · pause · next · prev', 'now playing with a progress bar, and player controls (play <words> searches)'],
      ['lyrics [full]', 'open the lyrics of the current song (full = full screen)'],
      ['# tools'],
      ['slash <text> · clock', 'big text drawn with | and /, a live big clock (Enter or Ctrl+C stops it)'],
      ['top · stats · timer <1m30s> · speedtest', 'process monitor, memory / fps, countdown, a (simulated) speed test'],
      ['genpass [length] · uuid · rainbow <text>', 'random password, UUID, colourful text'],
      ['# for fun'],
      ['fortune · joke · cowsay <text> · banner', 'random quotes, jokes and ASCII art'],
      ['dice [sides] · flip · 8ball <question>', 'roll, flip and ask'],
      ['calc <math> · ping <host> · hack', 'a calculator and a few toys'],
      ['matrix · snake', 'full-window toys (matrix: click or press a key to stop; snake: arrow keys / WASD, Esc quits)'],
    ];

    const stores = () => APPS.filter(a => a.store);
    const pick = arr => arr[Math.floor(Math.random() * arr.length)];
    const VER = '2.16';
    const bootAt = performance.now();
    const fmtUp = ms => { const s = Math.floor(ms / 1000), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60); return (h ? h + 'h ' : '') + m + 'm ' + (s % 60) + 's'; };

    // a text progress bar that fills over about 1.5 s, then runs done()
    function progress(label, done) {
      const d = print(''), t0 = Date.now(), D = 1300 + Math.random() * 900;
      const iv = setInterval(() => {
        const x = Math.min(1, (Date.now() - t0) / D), n = Math.round(x * 24);
        d.textContent = `${label} [${'#'.repeat(n)}${'.'.repeat(24 - n)}] ${Math.round(x * 100)}%`; out.scrollTop = out.scrollHeight;
        if (x >= 1) { clearInterval(iv); d.classList.add('ok'); done(); }
      }, 40);
    }
    function install(name) {
      if (!name || /^(list|--list|-l)$/i.test(name)) { print('Apps you can install:', 'd'); return cmds.store(); }
      const app = findApp(name); if (!app) return noApp(name);
      if (!app.store) return print(`${app.name} is built into the OS, there is nothing to install.`, 'bad');
      if (isInstalled(app)) return print(`${app.name} is already installed.`, 'bad');
      print(`Resolving ${app.name}…`, 'd');
      progress('Downloading ' + app.name, () => {
        installApp(app.id); togglePin(app.id, true);
        print(`${app.name} installed and pinned to the taskbar. Open it with: sudo task main '${app.name}'`, 'ok'); toast('Installed', app.name + ' was added to your taskbar.');
      });
    }
    function uninstall(name) {
      if (!name) return print("Usage: sudo uninstall 'AppName'", 'bad');
      const app = findApp(name); if (!app) return noApp(name);
      if (!app.store) return print(`${app.name} is built into the OS and can't be removed.`, 'bad');
      if (!isInstalled(app)) return print(`${app.name} isn't installed.`, 'bad');
      if (wins[app.id]) { closeApp(app.id); delete pids[app.id]; print(`Stopped ${app.name}.`, 'd'); }
      progress('Removing ' + app.name, () => { uninstallApp(app.id); togglePin(app.id, false); print(`${app.name} was uninstalled.`, 'ok'); toast('Uninstalled', app.name); });
    }

    const FORTUNES = ['A closed tab is a problem solved for about five minutes.', 'Ship it. You can fix it in version 2.14.', 'The best bug report starts with "it worked yesterday".', 'You will soon find the semicolon you were looking for.', 'Today is a good day to clear your cache and your mind.', 'Fast Boot is for the impatient. Enter Cine is for the poets.', 'There is no place like 127.0.0.1.', 'Someone, somewhere, is also debugging CSS right now.', 'Turn it off and on again. Then blame DNS.', 'Great things are built one tiny commit at a time.', 'Your next idea is hiding behind the thing you are procrastinating on.', 'Dark mode is not a preference, it is a lifestyle.'];
    const JOKES = ['Why do programmers prefer dark mode? Because light attracts bugs.', 'There are 10 kinds of people: those who understand binary and those who do not.', 'A SQL query walks into a bar, walks up to two tables and asks: can I join you?', 'I would tell you a UDP joke, but you might not get it.', "Why did the developer go broke? He used up all his cache.", '!false: it is funny because it is true.', 'How many programmers does it take to change a light bulb? None, that is a hardware problem.', 'My code works and I have no idea why. My code does not work and I have no idea why.'];
    const BALL = ['It is certain.', 'Without a doubt.', 'Yes, definitely.', 'Most likely.', 'Ask again later.', 'Cannot predict now.', 'Do not count on it.', 'My sources say no.', 'Very doubtful.', 'Signs point to yes.'];
    const LOGO = ['   ____ _             ', '  / ___(_)_ __   ___  ', ' | |   | | \'_ \\ / _ \\ ', ' | |___| | | | |  __/ ', '  \\____|_|_| |_|\\___| ', '   /  Figure  OS  /    '];

    function cowsay(text) {
      const t = text || 'moo', line = '-'.repeat(t.length + 2);
      [` ${'_'.repeat(t.length + 2)} `, `< ${t} >`, ` ${line} `, '        \\   ^__^', '         \\  (oo)\\_______', '            (__)\\       )\\/\\', '                ||----w |', '                ||     ||'].forEach(l => print(l));
    }
    function neofetch() {
      const apps = APPS.filter(a => isInstalled(a)).length, p = getProfile(), pal = ['#f23f43', '#f0b232', '#23a55a', '#4d9fff', '#7983f5', '#c67bff'].map(c => `<span style="color:${c}">███</span>`).join('');
      const info = [`<span class="g">${esc(p.handle)}@cine-os</span>`, '<span class="d">----------------</span>', `<span class="g">OS</span>: Cine/Figure OS v${VER}`, `<span class="g">Host</span>: ${window.cine ? 'Desktop app (Electron)' : 'Web browser'}`, `<span class="g">Apps</span>: ${apps} installed / ${APPS.length} total`, `<span class="g">Uptime</span>: ${fmtUp(performance.now() - bootAt)}`, `<span class="g">Display</span>: ${innerWidth}x${innerHeight}`, `<span class="g">Theme</span>: Dark / violet`, `<span class="g">Shell</span>: cine-terminal 1.2`, pal];
      LOGO.forEach((l, i) => printHTML(`<span class="g">${esc(l)}</span>  ${info[i] || ''}`));
      info.slice(LOGO.length).forEach(x => printHTML(' '.repeat(LOGO[0].length + 2) + x));
    }
    function matrix() {
      root.style.position = 'relative';
      const cv = document.createElement('canvas'); cv.className = 'tm-matrix'; root.append(cv);
      cv.width = root.clientWidth; cv.height = root.clientHeight; const c = cv.getContext('2d'), cols = Math.floor(cv.width / 16), drops = Array.from({ length: cols }, () => Math.random() * -40);
      const glyphs = 'アイウエオカキクケコサシスセソ0123456789ABCDEF';
      const iv = setInterval(() => {
        c.fillStyle = 'rgba(0,0,0,.08)'; c.fillRect(0, 0, cv.width, cv.height); c.font = '15px monospace';
        drops.forEach((y, i) => { c.fillStyle = Math.random() > .96 ? '#d6ffe8' : '#27d36b'; c.fillText(glyphs[Math.floor(Math.random() * glyphs.length)], i * 16, y * 16); drops[i] = y * 16 > cv.height && Math.random() > .975 ? 0 : y + 1; });
      }, 50);
      const stop = () => { clearInterval(iv); clearTimeout(to); cv.remove(); removeEventListener('keydown', stop, true); input.focus(); };
      const to = setTimeout(stop, 12000); cv.onclick = stop; addEventListener('keydown', stop, true);
    }
    function hack() {
      const steps = ['Scanning ports…', 'Bypassing firewall…', 'Injecting totally-real exploit…', 'Decrypting mainframe…', 'Downloading all the data…'];
      let i = 0; const iv = setInterval(() => {
        if (i < steps.length) print(steps[i++] + ' [OK]', 'ok');
        else { clearInterval(iv); print('Just kidding. Nothing was touched, this is a toy.', 'd'); }
      }, 550);
    }
    function ping(host) {
      if (!host) return print('Usage: ping <host>', 'bad');
      print(`PING ${host} (simulated, nothing leaves this window)`, 'd');
      let n = 0; const iv = setInterval(() => { print(`64 bytes from ${host}: icmp_seq=${++n} ttl=57 time=${(8 + Math.random() * 40).toFixed(1)} ms`); if (n >= 4) { clearInterval(iv); print('4 packets transmitted, 4 received, 0% packet loss', 'ok'); } }, 450);
    }
    function calc(args) {
      const e = args.join(' ').trim(); if (!e) return print('Usage: calc 12*(3+4)', 'bad');
      if (!/^[0-9+\-*/().%\s^e]+$/i.test(e) || /[a-df-z]/i.test(e)) return print('calc: only numbers and + - * / ( ) % ^ please.', 'bad');
      try { const v = Function('"use strict";return (' + e.replace(/\^/g, '**') + ')')(); print(String(v), Number.isFinite(v) ? 'ok' : 'bad'); } catch { print('calc: that does not compute.', 'bad'); }
    }


    /* ---- slash font: every letter is drawn only with | and / ---- */
    const SF = {
      A: '.###.,#...#,#...#,#####,#...#,#...#,#...#', B: '####.,#...#,#...#,####.,#...#,#...#,####.', C: '.####,#....,#....,#....,#....,#....,.####',
      D: '####.,#...#,#...#,#...#,#...#,#...#,####.', E: '#####,#....,#....,####.,#....,#....,#####', F: '#####,#....,#....,####.,#....,#....,#....',
      G: '.####,#....,#....,#..##,#...#,#...#,.###.', H: '#...#,#...#,#...#,#####,#...#,#...#,#...#', I: '#####,..#..,..#..,..#..,..#..,..#..,#####',
      J: '..###,....#,....#,....#,....#,#...#,.###.', K: '#...#,#..#.,#.#..,##...,#.#..,#..#.,#...#', L: '#....,#....,#....,#....,#....,#....,#####',
      M: '#...#,##.##,#.#.#,#.#.#,#...#,#...#,#...#', N: '#...#,##..#,##..#,#.#.#,#..##,#..##,#...#', O: '.###.,#...#,#...#,#...#,#...#,#...#,.###.',
      P: '####.,#...#,#...#,####.,#....,#....,#....', Q: '.###.,#...#,#...#,#...#,#.#.#,#..#.,.##.#', R: '####.,#...#,#...#,####.,#.#..,#..#.,#...#',
      S: '.####,#....,#....,.###.,....#,....#,####.', T: '#####,..#..,..#..,..#..,..#..,..#..,..#..', U: '#...#,#...#,#...#,#...#,#...#,#...#,.###.',
      V: '#...#,#...#,#...#,#...#,#...#,.#.#.,..#..', W: '#...#,#...#,#...#,#.#.#,#.#.#,##.##,#...#', X: '#...#,#...#,.#.#.,..#..,.#.#.,#...#,#...#',
      Y: '#...#,#...#,.#.#.,..#..,..#..,..#..,..#..', Z: '#####,....#,...#.,..#..,.#...,#....,#####',
      0: '.###.,#...#,#..##,#.#.#,##..#,#...#,.###.', 1: '..#..,.##..,..#..,..#..,..#..,..#..,.###.', 2: '.###.,#...#,....#,...#.,..#..,.#...,#####',
      3: '####.,....#,....#,.###.,....#,....#,####.', 4: '#...#,#...#,#...#,#####,....#,....#,....#', 5: '#####,#....,#....,####.,....#,....#,####.',
      6: '.###.,#....,#....,####.,#...#,#...#,.###.', 7: '#####,....#,...#.,..#..,.#...,.#...,.#...', 8: '.###.,#...#,#...#,.###.,#...#,#...#,.###.',
      9: '.###.,#...#,#...#,.####,....#,....#,.###.',
      '.': '.,.,.,.,.,.,#', '!': '#,#,#,#,#,.,#', '?': '.###.,#...#,....#,...#.,..#..,.....,..#..', ':': '.,#,.,.,.,#,.', '-': '...,...,...,###,...,...,...',
      '/': '....#,....#,...#.,..#..,.#...,#....,#....', ' ': '...,...,...,...,...,...,...',
    };
    // px = characters per pixel. Horizontal strokes become //, vertical strokes ||
    function slashLines(text, px = 2) {
      const rows = ['', '', '', '', '', '', ''], gap = ' '.repeat(px);
      for (const ch0 of String(text).toUpperCase()) {
        const g = (SF[ch0] || SF['?']).split(','), w = g[0].length;
        for (let r = 0; r < 7; r++) {
          let line = '';
          for (let c = 0; c < w; c++) {
            if (g[r][c] !== '#') { line += ' '.repeat(px); continue; }
            line += ((c > 0 && g[r][c - 1] === '#') || (c < w - 1 && g[r][c + 1] === '#') ? '/' : '|').repeat(px);
          }
          rows[r] += line + gap;
        }
      }
      return rows.map(l => l.replace(/\s+$/, ''));
    }
    const slashW = (text, px) => Math.max(...slashLines(text, px).map(l => l.length));
    const GRAD = 'tm-grad';
    // how many characters fit on one terminal line
    function termCols() {
      const m = document.createElement('span'); m.textContent = '0'.repeat(20); m.style.cssText = 'position:absolute;visibility:hidden;white-space:pre'; out.append(m);
      const cw = m.getBoundingClientRect().width / 20 || 8; m.remove();
      const cols = Math.floor((out.clientWidth - 44) / cw);
      return cols > 20 ? cols : 100; // window not laid out yet: assume a roomy one
    }
    function printSlash(text, opts = {}) {
      const cols = termCols(); let px = opts.px || 2;
      if (slashW(text, px) > cols) px = 1;
      if (slashW(text, px) > cols) return print(String(text).toUpperCase() + '  (too wide for this window, make Terminal bigger)', 'd');
      const lines = slashLines(text, px), d = document.createElement('div'); d.className = opts.anim ? 'tm-ban' : 'tm-big';
      d.innerHTML = lines.map((l, i) => `<span class="${GRAD}" style="--i:${i}">${esc(l) || ' '}</span>`).join('');
      out.append(d); out.scrollTop = out.scrollHeight; return slashW(text, px);
    }
    function startBanner() {
      const cols = termCols(), w0 = slashW('CINE OS', 2), w = w0 <= cols ? w0 : slashW('CINE OS', 1);
      const lineOf = (n, flip) => { let s = ''; for (let i = 0; i < n; i++) s += (i + (flip ? 1 : 0)) % 2 ? '|' : '/'; return s; };
      const bar = (n, flip) => { const d = document.createElement('div'); d.className = 'tm-ban'; d.innerHTML = `<span class="${GRAD}" style="--i:0">${lineOf(Math.min(n, cols), flip)}</span>`; out.append(d); };
      bar(w, false); printSlash('CINE OS', { anim: true }); bar(w, true);
      printHTML(`<span class="g">||</span> Cine/Figure OS Terminal <span class="g">v1.2</span> <span class="d">/ type</span> <span class="g">help</span> <span class="d">to see what you can do</span>`);
      print('');
    }

    /* ---- Cine-Tunes remote ---- */
    const tunes = () => { const w = wins.tunes; return w && w.ctl ? w.ctl : null; };
    const needTunes = () => { const c = tunes(); if (!c) print('Cine-Tunes is not running. Start it with: music <song or artist>', 'bad'); return c; };
    function np() {
      const c = needTunes(); if (!c) return; const s = c.state();
      if (!s) return print('Nothing is playing yet. Try: music <song or artist>', 'd');
      const n = 28, f = Math.round(Math.min(1, s.p || 0) * n), fm = x => `${Math.floor(x / 60)}:${String(Math.floor(x % 60)).padStart(2, '0')}`;
      printHTML(`<span class="g">${s.playing ? '▶' : '⏸'}</span> <b>${esc(s.title)}</b> <span class="d">· ${esc(s.artist)}</span>`);
      printHTML(`  <span class="g">${'/'.repeat(f)}</span><span class="d">${'|'.repeat(n - f)}</span>  ${fm(s.cur || 0)} / ${fm(s.dur || 0)}`);
    }
    const mediaCmd = (name, fn) => () => { const c = needTunes(); if (!c) return; const s = c.state(); fn(c, s); print(name, 'ok'); };

    /* ---- background jobs (clock, timer) ---- */
    let clockIv = 0;
    const stopClock = () => { if (clockIv) { clearInterval(clockIv); clockIv = 0; } };
    function clock() {
      stopClock();
      const box = document.createElement('div'); box.className = 'tm-big'; out.append(box);
      const draw = () => {
        const d = new Date(), t = [d.getHours(), d.getMinutes(), d.getSeconds()].map(x => String(x).padStart(2, '0')).join(':');
        const px = slashW(t, 2) <= termCols() ? 2 : 1;
        box.innerHTML = slashLines(t, px).map(l => `<span class="${GRAD}" style="display:block">${esc(l) || ' '}</span>`).join(''); out.scrollTop = out.scrollHeight;
      };
      draw(); clockIv = setInterval(draw, 1000); setTimeout(stopClock, 120000);
      print('(press Enter or Ctrl+C to stop the clock)', 'd');
    }
    function parseTime(a) {
      const txt = a.join(' ').toLowerCase(); let sec = 0, any = false;
      for (const m of txt.matchAll(/(\d+(?:\.\d+)?)\s*(h|hr|hours?|m|min|mins|minutes?|s|sec|secs|seconds?)?/g)) { any = true; const v = parseFloat(m[1]), u = (m[2] || 's')[0]; sec += u === 'h' ? v * 3600 : u === 'm' ? v * 60 : v; }
      return any ? Math.round(sec) : 0;
    }
    function timer(args) {
      const sec = parseTime(args); if (!sec) return print('Usage: timer 90   or   timer 1m30s   or   timer 5 min', 'bad');
      if (sec > 21600) return print('timer: 6 hours is the maximum.', 'bad');
      const d = print(''), t0 = Date.now(), tm = x => { x = Math.max(0, Math.ceil(x)); return `${Math.floor(x / 60)}:${String(x % 60).padStart(2, '0')}`; };
      print(`Timer set for ${tm(sec)}. You can keep using the terminal.`, 'd');
      const iv = setInterval(() => {
        const left = sec - (Date.now() - t0) / 1000, n = Math.round(Math.min(1, 1 - left / sec) * 24);
        d.textContent = `⏱ ${'/'.repeat(n)}${'|'.repeat(24 - n)} ${tm(left)}`;
        if (left <= 0) { clearInterval(iv); d.classList.add('ok'); d.textContent = `⏱ ${'/'.repeat(24)} done`; print(`Time is up! (${tm(sec)})`, 'ok'); toast('Timer finished', tm(sec) + ' has passed.'); }
      }, 250);
    }
    function top() {
      const run = Object.keys(wins), mem = performance.memory ? performance.memory.usedJSHeapSize / 1048576 : 0;
      printHTML(`<span class="g">cine-top</span> <span class="d">— up ${fmtUp(performance.now() - bootAt)}, ${run.length} app${run.length === 1 ? '' : 's'} running${mem ? ', ' + mem.toFixed(0) + ' MB heap' : ''}</span>`);
      printHTML('<span class="d">  PID    NAME            CPU%   MEM</span>');
      const rows = run.length ? run : ['(nothing)'];
      rows.forEach(id => {
        const a = APPS.find(x => x.id === id); pids[id] = pids[id] || nextPid++;
        const cpu = Math.random() * 6, m = 40 + Math.random() * 160, bar = '/'.repeat(Math.max(1, Math.round(cpu))) + '|'.repeat(Math.max(0, 6 - Math.round(cpu)));
        print(`  ${String(a ? pids[id] : '-').padEnd(7)}${(a ? a.name : id).padEnd(16)}${cpu.toFixed(1).padStart(4)}   ${m.toFixed(0).padStart(3)} MB  ${bar}`);
      });
      print('(per-app numbers are estimates, the OS runs everything in one window)', 'd');
    }
    function stats() {
      const m = performance.memory, ls = Object.keys(localStorage).reduce((a, k) => a + k.length + (localStorage.getItem(k) || '').length, 0), fps = ($('#fps-val') || {}).textContent;
      printHTML(`<span class="g">Memory</span>: ${m ? (m.usedJSHeapSize / 1048576).toFixed(0) + ' MB used of ' + (m.jsHeapSizeLimit / 1048576).toFixed(0) + ' MB limit' : 'not reported by this browser'}`);
      printHTML(`<span class="g">FPS</span>: ${fps || '?'}   <span class="g">Cores</span>: ${navigator.hardwareConcurrency || '?'}   <span class="g">Display</span>: ${innerWidth}x${innerHeight} @${devicePixelRatio}x`);
      printHTML(`<span class="g">Saved data</span>: ${(ls / 1024).toFixed(1)} KB   <span class="g">Apps running</span>: ${Object.keys(wins).length}   <span class="g">Online</span>: ${navigator.onLine ? 'yes' : 'no'}`);
    }
    function speedtest() {
      print('Cine-Speed (simulated, nothing leaves this window)', 'd');
      const steps = [['Ping', () => (8 + Math.random() * 20).toFixed(0) + ' ms'], ['Download', () => (80 + Math.random() * 420).toFixed(1) + ' Mbps'], ['Upload', () => (20 + Math.random() * 120).toFixed(1) + ' Mbps']];
      let i = 0; const next = () => { if (i >= steps.length) return print('Done.', 'g'); const [n, f] = steps[i++]; progress(n.padEnd(9), () => { print('  ' + n + ': ' + f(), 'ok'); next(); }); }; next();
    }
    function genpass(args) {
      const n = Math.max(6, Math.min(64, parseInt(args[0], 10) || 20)), set = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*-_=+?', buf = new Uint32Array(n); crypto.getRandomValues(buf);
      print([...buf].map(x => set[x % set.length]).join(''), 'g'); print(`${n} characters, made in this window with your browser's crypto. Nothing is saved.`, 'd');
    }
    function rainbow(args) {
      const t = args.join(' ') || 'Cine/Figure OS';
      printHTML([...t].map((c, i) => `<span style="color:hsl(${(i * 360 / Math.max(6, t.length)) | 0},85%,62%)">${esc(c)}</span>`).join(''));
    }
    function snake() {
      const cv = document.createElement('canvas'); cv.className = 'tm-matrix'; root.append(cv);
      cv.width = root.clientWidth; cv.height = root.clientHeight;
      const c = cv.getContext('2d'), S = 18, cols = Math.max(8, Math.floor(cv.width / S)), rows = Math.max(8, Math.floor(cv.height / S)), ox = (cv.width - cols * S) / 2, oy = (cv.height - rows * S) / 2;
      let sn, dir, nd, food, score, dead, best = LS.get('snakeBest', 0);
      const spawn = () => { let p; do p = { x: Math.floor(Math.random() * cols), y: Math.floor(Math.random() * rows) }; while (sn.some(s => s.x === p.x && s.y === p.y)); return p; };
      const reset = () => { sn = [{ x: 5, y: 5 }, { x: 4, y: 5 }, { x: 3, y: 5 }]; dir = nd = { x: 1, y: 0 }; score = 0; dead = false; food = spawn(); };
      reset();
      const draw = () => {
        c.fillStyle = '#05060a'; c.fillRect(0, 0, cv.width, cv.height); c.strokeStyle = '#1b1d2b'; c.strokeRect(ox, oy, cols * S, rows * S);
        c.fillStyle = '#ff5c7a'; c.fillRect(ox + food.x * S + 3, oy + food.y * S + 3, S - 6, S - 6);
        sn.forEach((p, i) => { c.fillStyle = i ? `hsl(${260 - Math.min(70, i * 3)},80%,62%)` : '#22d3ee'; c.fillRect(ox + p.x * S + 1, oy + p.y * S + 1, S - 2, S - 2); });
        c.fillStyle = '#e8e8ee'; c.font = '14px monospace'; c.fillText(`score ${score}   best ${best}   (arrows / WASD, Esc to quit)`, ox + 6, oy + 18);
        if (dead) { c.font = '22px monospace'; c.fillText('Game over, press Space to retry', cv.width / 2 - 170, cv.height / 2); }
      };
      const iv = setInterval(() => {
        if (dead) return draw();
        dir = nd; const h = { x: (sn[0].x + dir.x + cols) % cols, y: (sn[0].y + dir.y + rows) % rows };
        if (sn.some(s => s.x === h.x && s.y === h.y)) { dead = true; if (score > best) { best = score; LS.set('snakeBest', best); } }
        else { sn.unshift(h); if (h.x === food.x && h.y === food.y) { score++; food = spawn(); } else sn.pop(); }
        draw();
      }, 95);
      const stop = () => { clearInterval(iv); cv.remove(); removeEventListener('keydown', onKey, true); print(`Snake: score ${score}, best ${best}`, 'g'); input.focus(); };
      function onKey(e) {
        const k = e.key.toLowerCase(), map = { arrowup: [0, -1], w: [0, -1], arrowdown: [0, 1], s: [0, 1], arrowleft: [-1, 0], a: [-1, 0], arrowright: [1, 0], d: [1, 0] };
        e.preventDefault(); e.stopPropagation();
        if (k === 'escape' || k === 'q') return stop();
        if (k === ' ' && dead) return reset();
        const m = map[k]; if (m && !(m[0] === -dir.x && m[1] === -dir.y)) nd = { x: m[0], y: m[1] };
      }
      addEventListener('keydown', onKey, true); draw();
    }

    const cmds = {
      help() { HELP.forEach(([c, d]) => printHTML(d == null ? `<span class="d">${esc(c)}</span>` : `<span class="g">${esc(c)}</span>  <span class="d">— ${esc(d)}</span>`)); },
      clear() { out.innerHTML = ''; },
      cls() { out.innerHTML = ''; },
      apps() { APPS.forEach(a => print(`  ${a.name.padEnd(14)} ${('(' + a.id + ')').padEnd(14)} ${isInstalled(a) ? 'installed' : 'not installed'}`)); },
      store() { stores().forEach(a => print(`  ${a.name.padEnd(14)} ${isInstalled(a) ? '[installed]' : '[available]'}`)); print('Use: sudo install \'AppName\'', 'd'); },
      tasks() {
        const run = Object.keys(wins); if (!run.length) return print('No apps running.');
        run.forEach(id => { const a = APPS.find(x => x.id === id); pids[id] = pids[id] || nextPid++; print(`  ${String(pids[id]).padEnd(7)}${a ? a.name : id}`); });
      },
      date() { print(new Date().toString()); },
      whoami() { print(getProfile().handle); },
      echo(args) { print(args.join(' ')); },
      history() { hist.forEach((h, i) => print(`  ${String(i + 1).padStart(3)}  ${h}`)); },
      exit() { closeApp('terminal'); },
      open(args) { const n = args.join(' '); if (!n) return print('Usage: open <app>', 'bad'); const a = findApp(n); if (!a) return noApp(n); print(`Opening ${a.name}…`, 'ok'); if (a.id !== 'terminal') launchApp(a.id); },
      neofetch, uptime() { print('up ' + fmtUp(performance.now() - bootAt)); }, version() { print(`Cine/Figure OS v${VER}`); }, about() { cmds.version(); print('Made by Cine-Hub Softwares.', 'd'); },
      lock() { print('Locking…', 'ok'); setTimeout(lockNow, 350); },
      pwd() { print('/home/' + getProfile().handle); }, time() { cmds.date(); },
      ls() { print('apps/  games/  wallpapers/  profile.cfg  notes.txt'); },
      cd() { print('You are already exactly where you need to be.', 'd'); },
      shorts() { print('Opening Figure Shorts…', 'ok'); launchApp('figuretube', { view: 'shorts' }); },
      yt(args) { const q = args.join(' ').trim(); print(q ? `Searching FigureTube for "${q}"…` : 'Opening FigureTube…', 'ok'); launchApp('figuretube', q ? { q } : {}); },
      web(args) { const q = args.join(' ').trim(); print(q ? `Opening Cine-Web: ${q}` : 'Opening Cine-Web…', 'ok'); launchApp('web', q ? { url: q } : {}); },
      fortune() { print(pick(FORTUNES), 'g'); }, joke() { print(pick(JOKES), 'g'); },
      cowsay(args) { cowsay(args.join(' ')); }, banner() { startBanner(); }, logo() { LOGO.forEach(l => print(l, 'g')); },
      music(args) { const q = args.join(' ').trim(); print(q ? `Searching Cine-Tunes for "${q}"…` : 'Opening Cine-Tunes…', 'ok'); launchApp('tunes', q ? { q } : {}); },
      np, nowplaying: np,
      play(args) { if (args.length) return cmds.music(args); mediaCmd('▶ playing', (c, s) => { if (s && !s.playing) c.toggle(); })(); },
      pause: mediaCmd('⏸ paused', (c, s) => { if (s && s.playing) c.toggle(); }),
      next: mediaCmd('⏭ next song', c => c.next()), prev: mediaCmd('⏮ previous song', c => c.prev()),
      lyrics(args) {
        const full = /^(full|fullscreen|fs|-f)$/i.test(args[0] || '');
        launchApp('tunes', { lyrics: full ? 'full' : true }); print(full ? 'Full-screen lyrics…' : 'Opening lyrics…', 'ok');
      },
      slash(args) { const t = args.join(' ').trim(); if (!t) return print('Usage: slash <text>   (letters, numbers, . ! ? : - /)', 'bad'); printSlash(t, { anim: true }); },
      clock, top, htop: top, stats, timer, speedtest, genpass, uuid() { print(crypto.randomUUID(), 'g'); }, rainbow, snake,
      dice(args) { const n = Math.max(2, Math.min(1000000, parseInt(args[0], 10) || 6)); print(`You rolled a ${1 + Math.floor(Math.random() * n)} (d${n})`, 'ok'); },
      roll(args) { cmds.dice(args); },
      flip() { print(Math.random() < .5 ? 'Heads' : 'Tails', 'ok'); }, coinflip() { cmds.flip(); },
      '8ball'(args) { if (!args.length) return print('Ask a question first: 8ball will I win?', 'bad'); print('🎱 ' + pick(BALL), 'g'); },
      calc, hack, matrix, ping(args) { ping(args[0]); },
      sl() { print('You meant ls. The train has left the station.', 'd'); },
      cat() { print('meow', 'd'); },
    };

    function sudo(args) {
      const a = args.map(x => x.toLowerCase());
      // sudo RS desktop
      if (a[0] === 'rs' && a[1] === 'desktop') {
        print('Restarting desktop…', 'ok'); setTimeout(() => location.reload(), 700); return;
      }
      // sudo task main <app>
      if (a[0] === 'task' && a[1] === 'main') {
        const name = args.slice(2).join(' '); if (!name) return print("Usage: sudo task main 'AppName'", 'bad');
        const app = findApp(name); if (!app) return noApp(name);
        pids[app.id] = pids[app.id] || nextPid++;
        print(`[${pids[app.id]}] ${app.name} started`, 'ok');
        if (app.id !== 'terminal') launchApp(app.id);
        return;
      }
      // sudo kill task <app>
      if (a[0] === 'kill' && a[1] === 'task') {
        const name = args.slice(2).join(' '); if (!name) return print("Usage: sudo kill task 'AppName'", 'bad');
        const app = findApp(name); if (!app) return noApp(name);
        if (!wins[app.id]) return print(`${app.name} isn't running.`, 'bad');
        print(`[${pids[app.id] || '—'}] ${app.name} terminated`, 'ok'); delete pids[app.id];
        closeApp(app.id); return;
      }
      // sudo install / uninstall (also: sudo apt install x, sudo remove x)
      const pk = (a[0] === 'apt' || a[0] === 'apt-get' || a[0] === 'pkg') ? 1 : 0;
      if (a[pk] === 'install') return install(args.slice(pk + 1).join(' '));
      if (a[pk] === 'uninstall' || a[pk] === 'remove' || a[pk] === 'purge') return uninstall(args.slice(pk + 1).join(' '));
      if (pk && (a[1] === 'update' || a[1] === 'upgrade')) { print('Hit:1 https://store.cine-hub.local stable InRelease', 'd'); progress('Updating package lists', () => print('All packages are up to date.', 'ok')); return; }
      if (a[0] === 'reboot' || a[0] === 'restart') { print('Rebooting…', 'ok'); setTimeout(() => location.reload(), 700); return; }
      if (a[0] === 'rm' && /-rf?\b|-fr\b/.test(a.join(' '))) return print('Nice try. The OS is guarded by a very tired cat.', 'bad');
      if (a[0] === 'make' && a.includes('sandwich')) return print('Okay.', 'ok');
      if (a[0] === 'su' || a[0] === 'whoami') return print('root (just kidding, you are ' + getProfile().handle + ')', 'd');
      print(a.length ? `sudo: unknown command "${args.join(' ')}". Type "help".` : 'usage: sudo <command>. Type "help".', 'bad');
    }

    function run(line) {
      const t = tokenize(line); if (!t.length) return;
      const cmd = t[0].toLowerCase();
      if (cmd === 'sudo') return sudo(t.slice(1));
      if (cmd === 'task' || cmd === 'kill' || cmd === 'rs' || cmd === 'install' || cmd === 'uninstall') return print(`${cmd}: permission denied. Try: sudo ${line}`, 'bad');
      if (cmds[cmd]) return cmds[cmd](t.slice(1));
      print(`${t[0]}: command not found. Type "help".`, 'bad');
    }

    $('.tm-line', root).onsubmit = e => {
      e.preventDefault(); const line = input.value; input.value = '';
      stopClock();
      printHTML(`<span class="tm-ps">${esc(getProfile().handle)}@cine-os:~$</span> ${esc(line)}`);
      if (line.trim()) { if (hist[hist.length - 1] !== line) hist.push(line); LS.set('termHist', hist.slice(-50)); }
      hp = hist.length; run(line);
    };
    input.onkeydown = e => {
      if (e.key === 'ArrowUp') { e.preventDefault(); if (hp > 0) input.value = hist[--hp]; }
      else if (e.key === 'ArrowDown') { e.preventDefault(); input.value = hp < hist.length - 1 ? hist[++hp] : ((hp = hist.length), ''); }
      else if (e.key === 'l' && e.ctrlKey) { e.preventDefault(); out.innerHTML = ''; }
      else if (e.key === 'c' && e.ctrlKey && !getSelection().toString()) { e.preventDefault(); stopClock(); print('^C', 'd'); input.value = ''; }
      else if (e.key === 'Tab') { // complete app names after "task main " / "kill task "
        e.preventDefault();
        const m = input.value.match(/^(.*\b(?:task main|kill task|install|uninstall|remove|open)\s+)(\S*)$/i);
        if (m) { const hit = APPS.find(a => norm(a.name).startsWith(norm(m[2]))); if (hit) input.value = m[1] + (/\s/.test(hit.name) ? `'${hit.name}'` : hit.name); }
        else if (input.value && !/\s/.test(input.value)) { // complete a command name
          const v = input.value.toLowerCase(), all = [...Object.keys(cmds), 'sudo'].filter(k => k.startsWith(v)).sort();
          if (all.length === 1) input.value = all[0] + ' ';
          else if (all.length > 1) { let p = all[0]; all.forEach(k => { while (!k.startsWith(p)) p = p.slice(0, -1); }); input.value = p; print(all.join('   '), 'd'); }
        }
      }
    };
    root.onclick = e => { if (!getSelection().toString() && !e.target.closest('input')) input.focus(); };
    w.opts = () => setTimeout(() => input.focus(), 50);

    w.onclose = () => stopClock();
    // the banner needs the window to be laid out before it can measure how wide it may be
    requestAnimationFrame(startBanner);
    w.opts();
  },
});
