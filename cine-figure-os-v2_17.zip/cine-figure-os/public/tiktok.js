// Cine/Figure OS - TikTok (the real https://www.tiktok.com/en/ web app)
// Desktop app: runs inside the OS in its own saved browser profile, so your TikTok login sticks.
// Plain browser (localhost / npm run dev): opens TikTok in a new tab.
const TIKTOK_URL = 'https://www.tiktok.com/en/';
registerApp({
  id: 'tiktok', name: 'TikTok', icon: 'fa-tiktok', img: 'icons/tiktok.png', bg: 'transparent', pinned: false, store: true,
  mount(root, w) {
    root.classList.add('dcw', 'ttk');
    const desktop = !!window.cine;
    root.innerHTML = `<div class="dcw-bar app-head"><img src="icons/tiktok.png" alt=""><strong>TikTok</strong>
        <button data-a="back" title="Back"><i class="fas fa-arrow-left"></i></button>
        <button data-a="reload" title="Reload"><i class="fas fa-rotate-right"></i></button>
        <button data-a="home" title="Home"><i class="fas fa-house"></i></button></div><div class="dcw-view"></div>`;
    const view = $('.dcw-view', root);
    let el = null, off = null;
    const safe = fn => { try { fn(); } catch {} };
    if (desktop) {
      window.cine.setProxy(LS.get('proxy', '')).catch(() => {});
      el = document.createElement('webview');
      el.setAttribute('src', TIKTOK_URL); el.setAttribute('partition', 'persist:tiktok'); el.setAttribute('allowpopups', '');
      let wcid = null; el.addEventListener('dom-ready', () => safe(() => { wcid = el.getWebContentsId(); }));
      view.append(el);
      // sign-in popups open inside the same view
      off = window.cine.onOpenUrl(({ from, url }) => { if (from === wcid) safe(() => el.loadURL(url)); });
    } else {
      view.innerHTML = `<div class="dcw-land"><img src="icons/tiktok.png" alt=""><h1>TikTok</h1>
        <p>TikTok is the real web app. Open it in a new tab, or use the desktop app (<code>npm start</code>) to run it right inside the OS.</p>
        <button class="btn" data-a="tab"><i class="fas fa-up-right-from-square"></i> Open TikTok</button></div>`;
      $$('.dcw-bar button', root).forEach(x => x.classList.add('hidden'));
    }
    root.addEventListener('click', e => {
      const b = e.target.closest('[data-a]'); if (!b) return;
      const a = b.dataset.a;
      if (a === 'tab') window.open(TIKTOK_URL, '_blank', 'noopener');
      if (!el) return;
      if (a === 'back') safe(() => el.goBack());
      if (a === 'reload') safe(() => el.reload());
      if (a === 'home') safe(() => el.loadURL(TIKTOK_URL));
    });
    w.onclose = () => off && off();
  },
});
