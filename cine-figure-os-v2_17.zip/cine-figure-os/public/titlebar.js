// Cine/Figure OS - custom title bar for the desktop app (replaces the plain Windows frame).
// Logo + title on the left, settings, then minimize / maximize / close on the right. Drag it to move the window.
(function () {
  if (!window.cine || !window.cine.win) return;
  const W = window.cine.win;
  const ic = {
    gear: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
    min: '<svg viewBox="0 0 12 12" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M2 6h8"/></svg>',
    max: '<svg viewBox="0 0 12 12" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"><rect x="2" y="2" width="8" height="8" rx="1.6"/></svg>',
    res: '<svg viewBox="0 0 12 12" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"><rect x="2" y="3.6" width="6.4" height="6.4" rx="1.4"/><path d="M4 3.6V3a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1h-.6"/></svg>',
    close: '<svg viewBox="0 0 12 12" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M2.5 2.5l7 7M9.5 2.5l-7 7"/></svg>',
  };
  const bar = document.createElement('div');
  bar.id = 'titlebar';
  bar.innerHTML = `<img src="icons/logo.png" alt="" draggable="false"><span class="tbt-name"></span><span class="tbt-sp"></span>
    <button class="tbt-b" data-w="settings" title="Settings">${ic.gear}</button><i class="tbt-div"></i>
    <button class="tbt-b" data-w="min" title="Minimize">${ic.min}</button>
    <button class="tbt-b" data-w="max" title="Maximize">${ic.max}</button>
    <button class="tbt-b close" data-w="close" title="Close">${ic.close}</button>`;
  // the bar sits above <body>; body becomes the area under it (so every fixed-position part of the OS shifts down 40px)
  document.documentElement.classList.add('desktop');
  document.documentElement.insertBefore(bar, document.body);

  const name = bar.querySelector('.tbt-name'), maxBtn = bar.querySelector('[data-w=max]');
  const sync = () => { name.textContent = document.title || 'Cine-OS'; };
  sync();
  new MutationObserver(sync).observe(document.querySelector('title'), { childList: true, characterData: true, subtree: true });

  const apply = s => {
    if (!s) return;
    document.documentElement.classList.toggle('fs', !!s.full);
    document.documentElement.classList.toggle('maxed', !!s.max);
    maxBtn.innerHTML = s.max ? ic.res : ic.max; maxBtn.title = s.max ? 'Restore' : 'Maximize';
  };
  W.state().then(apply).catch(() => {});
  W.onState(apply);

  bar.addEventListener('click', e => {
    const b = e.target.closest('[data-w]'); if (!b) return;
    const a = b.dataset.w;
    if (a === 'settings') { if (typeof launchApp === 'function') launchApp('config'); }
    else W.do(a);
  });
})();
