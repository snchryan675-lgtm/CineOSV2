// Cine/Figure OS - Visual Code
// A small code editor for the OS's own code (the files in public/). Desktop app only.
//  - Your edits and added files are saved in a separate folder next to the app's data and layered over the originals, so
//    the original files are never changed; "Revert" simply deletes your copy. Only app code can be edited (main.js enforces this).
//  - CSS changes show live when you press Save; for HTML / JS press Apply to reload the OS with your changes.
//  - Add PNGs and other files with Upload (or drag them onto the explorer). Use them in code as e.g. icons/mine.png
//  - If an edit stops the OS from starting, the next launch offers Safe mode (original files) so you can fix it.
(function () {
  /* ---------- syntax highlighting (small, dependency free) ---------- */
  const sp = (c, s) => `<span class="vt-${c}">${esc(s)}</span>`;
  function tok(t, re, fn) {
    let out = '', last = 0, m; re.lastIndex = 0;
    while ((m = re.exec(t))) { if (!m[0]) { re.lastIndex++; continue; } out += esc(t.slice(last, m.index)) + fn(m); last = m.index + m[0].length; }
    return out + esc(t.slice(last));
  }
  const KW = new Set('const let var function return if else for while do switch case break continue new this class extends super import export from default try catch finally throw typeof instanceof in of async await yield delete void null undefined true false static get set'.split(' '));
  const hlJS = t => tok(t, /(\/\/[^\n]*|\/\*[\s\S]*?(?:\*\/|$))|("(?:\\.|[^"\\\n])*"?|'(?:\\.|[^'\\\n])*'?|`(?:\\[\s\S]|[^`\\])*`?)|(\b0x[\da-fA-F]+\b|\b\d[\d_]*\.?\d*(?:e[+-]?\d+)?\b)|\b([A-Za-z_$][\w$]*)\b(?=\s*\()|\b([A-Za-z_$][\w$]*)\b/g,
    m => m[1] ? sp('c', m[0]) : m[2] ? sp('s', m[0]) : m[3] ? sp('n', m[0]) : m[4] ? sp(KW.has(m[4]) ? 'k' : 'f', m[0]) : KW.has(m[5]) ? sp('k', m[0]) : /^[A-Z]/.test(m[5]) ? sp('t', m[0]) : esc(m[0]));
  const hlCSS = t => tok(t, /(\/\*[\s\S]*?(?:\*\/|$))|("(?:\\.|[^"\\\n])*"?|'(?:\\.|[^'\\\n])*'?)|(@[\w-]+)|(#[\da-fA-F]{3,8}\b)|((?<![\w-])-?\d*\.?\d+(?:px|em|rem|%|vh|vw|ms|s|deg|fr)?\b)|(--[\w-]+|[\w-]+)(?=\s*:)|(\b[\w-]+)(?=\()/g,
    m => m[1] ? sp('c', m[0]) : m[2] ? sp('s', m[0]) : m[3] ? sp('k', m[0]) : m[4] || m[5] ? sp('n', m[0]) : m[6] ? sp('a', m[0]) : sp('f', m[0]));
  const hlTag = t => tok(t, /(<\/?[\w:-]+)|("[^"]*"?|'[^']*'?)|([\w:@.-]+)(?==)|(\/?>)/g, m => m[1] ? sp('t', m[1]) : m[2] ? sp('s', m[2]) : m[3] ? sp('a', m[3]) : sp('t', m[4]));
  function hlHTML(t) {
    let out = '', i = 0, m; const re = /<!--[\s\S]*?(?:-->|$)|<\/?[A-Za-z][^>]*>?/g;
    while ((m = re.exec(t))) {
      out += esc(t.slice(i, m.index)); const s = m[0];
      if (s.startsWith('<!--')) out += sp('c', s);
      else {
        out += hlTag(s);
        const nm = /^<(script|style)\b/i.exec(s);
        if (nm && !/\/>$/.test(s)) { // highlight inline <script> / <style> bodies with the JS / CSS rules
          const from = re.lastIndex, c = new RegExp('</' + nm[1] + '\\s*>', 'i').exec(t.slice(from)), end = c ? from + c.index : t.length;
          const body = t.slice(from, end); out += nm[1].toLowerCase() === 'script' ? hlJS(body) : hlCSS(body); re.lastIndex = end;
        }
      }
      i = re.lastIndex;
    }
    return out + esc(t.slice(i));
  }
  const hlJSON = t => tok(t, /("(?:\\.|[^"\\\n])*")(\s*:)?|(-?\d+\.?\d*(?:[eE][+-]?\d+)?)|\b(true|false|null)\b/g, m => m[1] ? sp(m[2] ? 'a' : 's', m[1]) + esc(m[2] || '') : m[3] ? sp('n', m[3]) : sp('k', m[4]));
  const langOf = p => ({ html: 'html', htm: 'html', svg: 'html', xml: 'html', css: 'css', js: 'js', mjs: 'js', json: 'json' }[(p.split('.').pop() || '').toLowerCase()] || 'text');
  const LANG_NAME = { html: 'HTML', css: 'CSS', js: 'JavaScript', json: 'JSON', text: 'Plain text' };
  const highlight = (t, lang) => (t.length > 400000 || lang === 'text') ? esc(t) : lang === 'html' ? hlHTML(t) : lang === 'css' ? hlCSS(t) : lang === 'js' ? hlJS(t) : hlJSON(t);

  const extOf = p => (p.split('.').pop() || '').toLowerCase();
  const isImg = p => /^(png|jpe?g|gif|webp|avif|ico|bmp)$/.test(extOf(p));
  const fileIcon = p => { const x = extOf(p); return x === 'js' || x === 'mjs' ? '<i class="fab fa-js vc-js"></i>' : x === 'html' || x === 'htm' ? '<i class="fab fa-html5 vc-html"></i>' : x === 'css' ? '<i class="fab fa-css3-alt vc-css"></i>' : x === 'json' ? '<i class="fas fa-file-code vc-json"></i>' : isImg(p) || x === 'svg' ? '<i class="fas fa-file-image vc-img"></i>' : /^(mp3|ogg|wav|m4a)$/.test(x) ? '<i class="fas fa-file-audio vc-img"></i>' : /^(mp4|webm)$/.test(x) ? '<i class="fas fa-file-video vc-img"></i>' : /^(woff2?|ttf|otf)$/.test(x) ? '<i class="fas fa-font vc-img"></i>' : '<i class="fas fa-file-lines vc-txt"></i>'; };
  const fmtSize = n => n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(1) + ' MB';

  const GUIDE = [
    ['style.css', 'Colours, fonts and the look of every app', 'fa-palette'],
    ['index.html', 'The layout: boot screen, top bar, home screen', 'fa-table-columns'],
    ['os.js', 'Taskbar, windows, start menu, app drawer', 'fa-window-restore'],
    ['games.js', 'The Cine-Play games list', 'fa-gamepad'],
  ];

  registerApp({
    id: 'vcode', name: 'Visual Code', icon: 'fa-code', bg: 'linear-gradient(135deg,#0a3d7a,#1e90ff)', pinned: true, keepAlive: true, onOpen,
    mount(root, w) {
      root.classList.add('vc');
      const code = window.cine && window.cine.code;
      if (!code) {
        root.innerHTML = `<div class="vc-land"><i class="fas fa-code"></i><h1>Visual Code</h1><p>Visual Code edits the OS's own code, so it needs the desktop app (<code>npm start</code> or the built .exe). It is not available in a browser.</p></div>`;
        return;
      }

      let files = [], info = { safeMode: false, unlocked: false, folder: '' };
      const tabs = [];            // { path, kind, text, saved, dataUrl, size, added, modified }
      let active = null, q = '', hlLang = 'text', raf = 0, findOpen = false;
      let openDirs = new Set(LS.get('vc.dirs', []));
      const tabOf = p => tabs.find(t => t.path === p);
      const dirty = t => t.kind === 'text' && t.text !== t.saved;
      const dirtyTabs = () => tabs.filter(dirty);
      w.ctl = { state: () => ({ playing: dirtyTabs().length > 0 }) }; // the close button minimizes instead of closing while there are unsaved changes

      root.innerHTML = `<div class="vc-head app-head"><i class="fas fa-code vc-logo"></i><strong>VISUAL CODE</strong><span class="vc-scope" title="Only the OS's own files (the public folder) can be edited here"><i class="fas fa-lock"></i> App code only</span><span class="sp"></span>
          <button class="vc-b" data-a="save" title="Save (Ctrl+S)"><i class="fas fa-floppy-disk"></i> Save</button>
          <button class="vc-b" data-a="saveall" title="Save all (Ctrl+Shift+S)"><i class="fas fa-copy"></i> Save all</button>
          <button class="vc-b run" data-a="apply" title="Save everything and reload the OS with your changes"><i class="fas fa-play"></i> Apply</button>
          <button class="vc-b ico" data-a="menu" title="More"><i class="fas fa-ellipsis"></i></button></div>
        <div class="vc-ban hidden"></div>
        <div class="vc-main">
          <aside class="vc-side"><div class="vc-sh"><span>EXPLORER</span><em class="vc-count"></em>
              <button data-a="new" title="New file"><i class="fas fa-file-circle-plus"></i></button><button data-a="upload" title="Upload PNGs or other files"><i class="fas fa-upload"></i></button><button data-a="refresh" title="Refresh"><i class="fas fa-rotate"></i></button></div>
            <label class="vc-sq"><i class="fas fa-magnifying-glass"></i><input placeholder="Filter files" autocomplete="off" spellcheck="false"></label>
            <div class="vc-tree"></div><div class="vc-drop"><i class="fas fa-cloud-arrow-up"></i><b>Drop files to add them</b><small>PNG, JPG, GIF, WebP, SVG, MP3 and more</small></div>
            <input type="file" class="vc-file" multiple hidden></aside>
          <section class="vc-ed"><div class="vc-tabs"></div><div class="vc-find hidden"><input class="f1" placeholder="Find" spellcheck="false"><span class="vc-fc"></span><input class="f2" placeholder="Replace" spellcheck="false">
              <button data-a="fprev" title="Previous"><i class="fas fa-chevron-up"></i></button><button data-a="fnext" title="Next (Enter)"><i class="fas fa-chevron-down"></i></button><button data-a="frep" title="Replace this one">Replace</button><button data-a="frepall">All</button><button data-a="fclose"><i class="fas fa-xmark"></i></button></div>
            <div class="vc-view"></div></section>
        </div>
        <div class="vc-status"><span class="vc-s1"></span><span class="sp"></span><span class="vc-s2"></span></div>
        <div class="vc-modal hidden"></div>`;
      const el = s => $(s, root);
      const tree = el('.vc-tree'), tabsEl = el('.vc-tabs'), view = el('.vc-view'), ban = el('.vc-ban'), modal = el('.vc-modal');
      let ta = null, pre = null, gut = null, gutIn = null;

      /* ---------- status + banners ---------- */
      let msgTimer = 0;
      function say(msg, ms = 3500) { const s = el('.vc-s1'); s.textContent = msg; s.classList.add('on'); clearTimeout(msgTimer); msgTimer = setTimeout(() => { s.classList.remove('on'); statusBase(); }, ms); }
      function statusBase() {
        const n = dirtyTabs().length, m = files.filter(f => f.modified).length;
        const s = el('.vc-s1'); if (s.classList.contains('on')) return;
        s.textContent = n ? `● ${n} unsaved ${n === 1 ? 'file' : 'files'}: save before closing (Ctrl+S)` : m ? `${m} edited ${m === 1 ? 'file' : 'files'} · press Apply to run them` : 'No edits yet. Your changes are saved separately from the original files.';
        s.classList.toggle('warn', !!n);
      }
      function cursorInfo() {
        const t = tabOf(active), s2 = el('.vc-s2');
        if (!t) return s2.textContent = '';
        if (t.kind !== 'text' || !ta) return s2.textContent = fmtSize(t.size || 0);
        const before = ta.value.slice(0, ta.selectionStart), ln = before.split('\n').length, col = before.length - before.lastIndexOf('\n');
        s2.textContent = `Ln ${ln}, Col ${col}   ·   Spaces: 2   ·   ${LANG_NAME[hlLang]}`;
      }
      function banners() {
        const parts = [];
        if (info.safeMode) parts.push(`<div class="vc-bn safe"><i class="fas fa-shield-halved"></i><span><b>Safe mode.</b> The OS is running the original files. Your edits are still saved (marked with a dot). Fix or revert them, then press Apply to run them again.</span></div>`);
        if (!info.unlocked) parts.push(`<div class="vc-bn lock"><i class="fas fa-lock"></i><span><b>Editing is locked.</b> You can look at the files, but you have to allow Visual Code to change them.</span><button class="vc-b run" data-a="unlock">Allow editing</button></div>`);
        ban.innerHTML = parts.join(''); ban.classList.toggle('hidden', !parts.length);
      }
      async function unlock() {
        const r = await code.unlock().catch(() => null);
        info.unlocked = !!(r && r.unlocked); banners();
        if (ta) { ta.readOnly = !info.unlocked; ta.classList.toggle('ro', !info.unlocked); }
        if (!info.unlocked) say('Editing stays locked.');
        return info.unlocked;
      }
      async function need() { return info.unlocked || unlock(); }

      /* ---------- explorer ---------- */
      function buildTree(list) {
        const rootN = { dirs: {}, files: [] };
        list.forEach(f => { const parts = f.path.split('/'); let n = rootN; parts.slice(0, -1).forEach(d => n = (n.dirs[d] = n.dirs[d] || { dirs: {}, files: [] })); n.files.push(f); });
        return rootN;
      }
      function renderTree() {
        const k = q.trim().toLowerCase(), list = k ? files.filter(f => f.path.toLowerCase().includes(k)) : files;
        const row = (f, d) => { const name = f.path.split('/').pop(); return `<div class="vc-r file${active === f.path ? ' on' : ''}${f.modified ? ' mod' : ''}" data-p="${esc(f.path)}" style="--d:${d}">${fileIcon(f.path)}<span class="nm">${esc(name)}</span>${f.added ? '<em class="u">NEW</em>' : f.modified ? '<em class="m">●</em>' : ''}</div>`; };
        const walk = (n, base, d) => {
          let h = '';
          Object.keys(n.dirs).sort().forEach(name => {
            const p = base ? base + '/' + name : name, open = k || openDirs.has(p), cnt = n.dirs[name];
            const changed = (function c(x) { return x.files.some(f => f.modified) || Object.values(x.dirs).some(c); })(cnt);
            h += `<div class="vc-r dir" data-d="${esc(p)}" style="--d:${d}"><i class="fas fa-chevron-${open ? 'down' : 'right'} cv"></i><i class="fas fa-folder${open ? '-open' : ''} fd"></i><span class="nm">${esc(name)}</span>${changed ? '<em class="m">●</em>' : ''}</div>`;
            if (open) h += walk(cnt, p, d + 1);
          });
          n.files.sort((a, b) => a.path.localeCompare(b.path)).forEach(f => h += row(f, d));
          return h;
        };
        tree.innerHTML = walk(buildTree(list), '', 0) || '<p class="vc-none">No files match.</p>';
        const m = files.filter(f => f.modified).length; el('.vc-count').textContent = m ? m + ' changed' : '';
        statusBase();
      }
      async function refresh(quiet) {
        const r = await code.list().catch(() => null);
        if (!r || !r.ok) { if (!quiet) toast('Visual Code', (r && r.error) || 'Could not read the app files.'); return; }
        files = r.files; renderTree();
      }
      const patchFile = (p, r) => { // after a save / upload: keep the explorer in sync without re-reading the whole folder
        let f = files.find(x => x.path === p);
        if (!f) { f = { path: p }; files.push(f); files.sort((a, b) => a.path.localeCompare(b.path)); }
        Object.assign(f, { size: r.size, added: r.added, modified: r.modified });
        const t = tabOf(p); if (t) Object.assign(t, { added: r.added, modified: r.modified, size: r.size });
      };

      /* ---------- tabs + editor ---------- */
      function renderTabs() {
        tabsEl.innerHTML = tabs.map(t => `<div class="vc-tab${t.path === active ? ' on' : ''}" data-p="${esc(t.path)}" title="${esc(t.path)}">${fileIcon(t.path)}<span>${esc(t.path.split('/').pop())}</span><b class="cl${dirty(t) ? ' dirty' : ''}" data-x="${esc(t.path)}"><i class="fas fa-xmark"></i><u></u></b></div>`).join('');
        const a = tabsEl.querySelector('.on'); if (a) { const l = a.offsetLeft, r = l + a.offsetWidth; if (l < tabsEl.scrollLeft) tabsEl.scrollLeft = l; else if (r > tabsEl.scrollLeft + tabsEl.clientWidth) tabsEl.scrollLeft = r - tabsEl.clientWidth; }
      }
      function paint() { // highlight + line numbers; synced on every change
        raf = 0; if (!ta) return;
        pre.innerHTML = highlight(ta.value, hlLang) + '\n';
        const n = ta.value.split('\n').length; if (gutIn.dataset.n !== String(n)) { gutIn.dataset.n = n; gutIn.textContent = Array.from({ length: n }, (_, i) => i + 1).join('\n'); }
      }
      const queuePaint = () => { if (!raf) raf = requestAnimationFrame(paint); };
      function syncScroll() { pre.style.transform = `translate(${-ta.scrollLeft}px,${-ta.scrollTop}px)`; gutIn.style.transform = `translateY(${-ta.scrollTop}px)`; }

      function showEmpty() {
        ta = pre = gut = gutIn = null; hlLang = 'text';
        view.innerHTML = `<div class="vc-empty"><div class="vc-hero"><i class="fas fa-code"></i></div><h2>Make Cine/Figure OS yours</h2>
          <p>Open a file on the left and change it. Press <kbd>Ctrl</kbd> <kbd>S</kbd> to save (CSS changes show instantly), then <b>Apply</b> to run your edits. Add your own pictures with <b>Upload</b>.</p>
          <div class="vc-guide">${GUIDE.map(([p, d, ic]) => `<button data-open="${p}"><i class="fas ${ic}"></i><span><b>${p}</b><small>${d}</small></span></button>`).join('')}</div>
          <p class="vc-tip"><i class="fas fa-lightbulb"></i><span>Tip: the colours at the top of <b>style.css</b> (the <code>:root</code> block) change the whole OS at once.</span></p></div>`;
        cursorInfo();
      }
      function showEditor(t) {
        hlLang = langOf(t.path);
        view.innerHTML = `<div class="vc-code"><div class="vc-gut"><pre></pre></div><div class="vc-cw"><pre class="vc-hl" aria-hidden="true"></pre><textarea class="vc-ta" spellcheck="false" wrap="off" autocapitalize="off" autocomplete="off" autocorrect="off"></textarea></div></div>`;
        ta = $('.vc-ta', view); pre = $('.vc-hl', view); gut = $('.vc-gut', view); gutIn = $('pre', gut);
        ta.value = t.text; ta.readOnly = !info.unlocked; ta.classList.toggle('ro', !info.unlocked);
        if (t.sel) ta.setSelectionRange(t.sel[0], t.sel[1]); else ta.setSelectionRange(0, 0);
        ta.scrollTop = 0; ta.scrollLeft = 0;
        paint(); syncScroll();
        if (t.scroll) { ta.scrollTop = t.scroll[0]; ta.scrollLeft = t.scroll[1]; syncScroll(); }
        ta.addEventListener('scroll', syncScroll);
        ta.addEventListener('input', () => { t.text = ta.value; queuePaint(); renderTabs(); statusBase(); cursorInfo(); if (findOpen) countFind(); });
        ['keyup', 'click', 'select'].forEach(ev => ta.addEventListener(ev, cursorInfo));
        ta.addEventListener('keydown', editorKeys);
        ta.addEventListener('blur', () => { t.sel = [ta.selectionStart, ta.selectionEnd]; t.scroll = [ta.scrollTop, ta.scrollLeft]; });
        cursorInfo();
      }
      function showOther(t) {
        ta = pre = gut = gutIn = null;
        const rel = esc(t.path), used = esc(t.path);
        view.innerHTML = t.kind === 'image'
          ? `<div class="vc-media"><div class="vc-chk"><img src="${t.dataUrl}" alt=""></div><div class="vc-mi"><b>${rel}</b><small>${fmtSize(t.size)}${t.added ? ' · added by you' : t.modified ? ' · replaced by you' : ' · original'}</small><p>Use it in your code like <code>${used}</code> (for example <code>background-image:url('${used}')</code> or <code>&lt;img src="${used}"&gt;</code>).</p></div></div>`
          : `<div class="vc-media"><div class="vc-mi"><i class="fas fa-file big"></i><b>${rel}</b><small>${fmtSize(t.size)}${t.added ? ' · added by you' : ''}</small><p>${t.kind === 'big' ? 'This file is too big to edit here.' : 'This kind of file can\'t be edited, but you can use it in your code as <code>' + used + '</code>.'}</p></div></div>`;
        cursorInfo();
      }
      function activate(p) {
        const prev = tabOf(active); if (prev && ta) { prev.sel = [ta.selectionStart, ta.selectionEnd]; prev.scroll = [ta.scrollTop, ta.scrollLeft]; }
        active = p; const t = tabOf(p);
        if (!t) showEmpty(); else if (t.kind === 'text') showEditor(t); else showOther(t);
        renderTabs(); renderTree(); if (t && t.kind === 'text' && findOpen) countFind();
      }
      async function openFile(p, focus = true) {
        if (tabOf(p)) return activate(p);
        const r = await code.read(p).catch(() => null);
        if (!r || !r.ok) return toast('Visual Code', (r && r.error) || 'Could not open that file.');
        tabs.push({ path: p, kind: r.kind, text: r.text || '', saved: r.text || '', dataUrl: r.dataUrl, size: r.size, added: r.added, modified: r.modified });
        activate(p); if (focus && ta) ta.focus();
      }
      function closeTab(p) {
        const i = tabs.findIndex(t => t.path === p); if (i < 0) return;
        const t = tabs[i];
        if (dirty(t) && !t.warned) { t.warned = true; say(`${t.path.split('/').pop()} has unsaved changes. Press the X again to discard them, or Ctrl+S to save.`, 5000); renderTabs(); return; }
        tabs.splice(i, 1);
        if (active === p) activate(tabs[Math.min(i, tabs.length - 1)] ? tabs[Math.min(i, tabs.length - 1)].path : null); else renderTabs();
      }

      /* ---------- editing keys ---------- */
      function ins(text) { document.execCommand('insertText', false, text); } // keeps Ctrl+Z working
      function editorKeys(e) {
        if (e.key === 'Tab') {
          e.preventDefault(); if (ta.readOnly) return;
          const a = ta.selectionStart, b = ta.selectionEnd, v = ta.value;
          if (a === b && !e.shiftKey) return ins('  ');
          const ls = v.lastIndexOf('\n', a - 1) + 1; let le = v.indexOf('\n', b); if (le < 0) le = v.length;
          if (b > a && v[b - 1] === '\n') le = b - 1;
          const block = v.slice(ls, le), out = e.shiftKey ? block.replace(/^( {1,2}|\t)/gm, '') : block.replace(/^/gm, '  ');
          ta.setSelectionRange(ls, le); ins(out); ta.setSelectionRange(ls, ls + out.length);
        } else if (e.key === 'Enter' && !e.ctrlKey && !e.metaKey && !e.shiftKey && !ta.readOnly) {
          const a = ta.selectionStart, v = ta.value, ls = v.lastIndexOf('\n', a - 1) + 1, ind = /^[ \t]*/.exec(v.slice(ls, a))[0], prev = v[a - 1];
          e.preventDefault(); ins('\n' + ind + (/[{(\[]/.test(prev) ? '  ' : ''));
        } else if (e.key === 'Escape' && findOpen) { closeFind(); }
      }

      /* ---------- find / replace ---------- */
      const fq = () => el('.vc-find .f1').value;
      function countFind() {
        const k = fq(), c = el('.vc-fc'); if (!k || !ta) return c.textContent = '';
        const hay = ta.value.toLowerCase(), needle = k.toLowerCase(); let n = 0, i = -1; while ((i = hay.indexOf(needle, i + 1)) >= 0) n++;
        c.textContent = n ? n + ' found' : 'No results';
      }
      function openFind() { if (!ta) return; findOpen = true; el('.vc-find').classList.remove('hidden'); const f = el('.vc-find .f1'); const s = ta.value.slice(ta.selectionStart, ta.selectionEnd); if (s && !s.includes('\n')) f.value = s; f.focus(); f.select(); countFind(); }
      function closeFind() { findOpen = false; el('.vc-find').classList.add('hidden'); ta && ta.focus(); }
      function findNext(dir = 1) {
        const k = fq(); if (!k || !ta) return; const hay = ta.value.toLowerCase(), n = k.toLowerCase();
        let i = dir > 0 ? hay.indexOf(n, ta.selectionEnd) : hay.lastIndexOf(n, ta.selectionStart - 1);
        if (i < 0) i = dir > 0 ? hay.indexOf(n) : hay.lastIndexOf(n);
        if (i < 0) return countFind();
        ta.setSelectionRange(i, i + k.length);
        const line = ta.value.slice(0, i).split('\n').length - 1, lh = parseFloat(getComputedStyle(ta).lineHeight) || 20;
        if (line * lh < ta.scrollTop || line * lh > ta.scrollTop + ta.clientHeight - 3 * lh) ta.scrollTop = Math.max(0, line * lh - ta.clientHeight / 2);
        syncScroll(); cursorInfo();
      }
      function replaceOne() {
        if (!ta || ta.readOnly) return; const k = fq(); if (!k) return;
        if (ta.value.slice(ta.selectionStart, ta.selectionEnd).toLowerCase() === k.toLowerCase()) { const s = ta.selectionStart; ta.focus(); ins(el('.vc-find .f2').value); ta.setSelectionRange(s, s + el('.vc-find .f2').value.length); }
        findNext(1);
      }
      function replaceAll() {
        if (!ta || ta.readOnly) return; const k = fq(); if (!k) return;
        const re = new RegExp(k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), rep = el('.vc-find .f2').value, cnt = (ta.value.match(re) || []).length;
        if (!cnt) return countFind();
        ta.focus(); ta.select(); ins(ta.value.replace(re, () => rep)); say(`Replaced ${cnt}.`);
      }

      /* ---------- save / apply ---------- */
      function hotCss(p) { // show CSS changes right away, no reload
        $$('link[rel="stylesheet"]').forEach(l => {
          const h = l.getAttribute('href') || ''; if (h.split('?')[0].replace(/^\.?\//, '') !== p) return;
          const n = l.cloneNode(); n.href = h.split('?')[0] + '?t=' + Date.now(); n.onload = () => l.remove(); l.after(n);
        });
      }
      async function save(t, quiet) {
        if (!t || t.kind !== 'text') return true;
        if (!(await need())) return false;
        const r = await code.write(t.path, t.text).catch(() => null);
        if (!r || !r.ok) { if (r && r.locked) { info.unlocked = false; banners(); } toast('Could not save ' + t.path, (r && r.error) || 'Something went wrong.'); return false; }
        t.saved = t.text; t.warned = false; patchFile(t.path, r);
        if (extOf(t.path) === 'css') hotCss(t.path);
        if (!quiet) say(extOf(t.path) === 'css' ? 'Saved. CSS applied live.' : 'Saved. Press Apply to run your changes.');
        renderTabs(); renderTree(); return true;
      }
      async function saveAll() { let ok = true; for (const t of dirtyTabs()) ok = (await save(t, true)) && ok; if (ok) say('All files saved.'); return ok; }
      async function apply(safe) {
        if (!(await need())) return;
        if (!safe && !(await saveAll())) return;
        say(safe ? 'Reloading without your edits…' : 'Reloading with your edits…', 8000);
        const r = await code.apply(!!safe).catch(() => null);
        if (!r || !r.ok) toast('Could not reload', (r && r.error) || 'Something went wrong.');
      }

      /* ---------- add files ---------- */
      function ask(title, label, value, okText) {
        return new Promise(res => {
          modal.classList.remove('hidden');
          modal.innerHTML = `<div class="vc-box"><h3>${esc(title)}</h3><label>${esc(label)}</label><input value="${esc(value)}" spellcheck="false" autocomplete="off"><div class="vc-bb"><button class="vc-b" data-m="no">Cancel</button><button class="vc-b run" data-m="ok">${esc(okText)}</button></div></div>`;
          const i = $('input', modal); i.focus(); i.setSelectionRange(i.value.length, i.value.length);
          const done = v => { modal.classList.add('hidden'); modal.innerHTML = ''; res(v); };
          modal.onclick = e => { const b = e.target.closest('[data-m]'); if (b) done(b.dataset.m === 'ok' ? i.value.trim() : null); else if (e.target === modal) done(null); };
          i.onkeydown = e => { if (e.key === 'Enter') done(i.value.trim()); else if (e.key === 'Escape') { e.stopPropagation(); done(null); } };
        });
      }
      function confirmBox(title, text, okText) {
        return new Promise(res => {
          modal.classList.remove('hidden');
          modal.innerHTML = `<div class="vc-box"><h3>${esc(title)}</h3><p>${esc(text)}</p><div class="vc-bb"><button class="vc-b" data-m="no">Cancel</button><button class="vc-b danger" data-m="ok">${esc(okText)}</button></div></div>`;
          const done = v => { modal.classList.add('hidden'); modal.innerHTML = ''; res(v); };
          modal.onclick = e => { const b = e.target.closest('[data-m]'); if (b) done(b.dataset.m === 'ok'); else if (e.target === modal) done(false); };
        });
      }
      const folderOfActive = () => { const p = active || ''; return p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : ''; };
      async function newFile() {
        if (!(await need())) return;
        const d = folderOfActive(), p = await ask('New file', 'Path inside the app (for example mytheme.css or ui/panel.js)', d ? d + '/' : '', 'Create');
        if (!p) return;
        const r = await code.write(p, '').catch(() => null);
        if (!r || !r.ok) return toast('Could not create the file', (r && r.error) || 'Something went wrong.');
        patchFile(p, r); const dir = p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : ''; dir && dir.split('/').reduce((a, s) => { const x = a ? a + '/' + s : s; openDirs.add(x); return x; }, ''); LS.set('vc.dirs', [...openDirs]);
        renderTree(); openFile(p);
      }
      async function addFiles(list) {
        list = [...list]; if (!list.length) return;
        if (!(await need())) return;
        const allImg = list.every(f => /\.(png|jpe?g|gif|webp|avif|ico|bmp|svg)$/i.test(f.name));
        const dir = await ask(`Add ${list.length === 1 ? list[0].name : list.length + ' files'}`, 'Folder to put it in (leave empty for the main folder)', allImg ? 'icons' : (folderOfActive() || ''), 'Add');
        if (dir === null) return;
        let ok = 0, last = null;
        for (const f of list) {
          const name = f.name.replace(/[^\w.\-@+()]+/g, '-').replace(/^[^A-Za-z0-9]+/, '').replace(/-+(\.[A-Za-z0-9]+)$/, '$1'), p = (dir ? dir.replace(/^\/+|\/+$/g, '') + '/' : '') + name;
          let r; try { r = await code.writeFile(p, new Uint8Array(await f.arrayBuffer())); } catch { r = null; }
          if (!r || !r.ok) { toast('Could not add ' + f.name, (r && r.error) || 'Something went wrong.'); continue; }
          patchFile(p, r); ok++; last = p;
          const dd = p.split('/').slice(0, -1); dd.reduce((a, s) => { const x = a ? a + '/' + s : s; openDirs.add(x); return x; }, '');
          if (tabOf(p)) { const t = tabs.find(x => x.path === p); const rd = await code.read(p).catch(() => null); if (rd && rd.ok) { Object.assign(t, { kind: rd.kind, text: rd.text || '', saved: rd.text || '', dataUrl: rd.dataUrl, size: rd.size }); } }
        }
        LS.set('vc.dirs', [...openDirs]); renderTree();
        if (last) { await openFile(last, false); if (tabOf(last) && active === last) activate(last); say(ok === 1 ? `Added. Use it as ${last}` : `Added ${ok} files.`, 6000); }
      }

      /* ---------- revert / delete / reset ---------- */
      async function revert(p) {
        if (!(await need())) return;
        const f = files.find(x => x.path === p); if (!f) return;
        const t = tabOf(p);
        if (!(await confirmBox(f.added ? 'Delete file' : 'Revert to original', f.added ? `Delete ${p}? It was added by you.` : `Throw away your changes to ${p} and go back to the original?`, f.added ? 'Delete' : 'Revert'))) return;
        const r = await code.reset(p).catch(() => null);
        if (!r || !r.ok) return toast('Visual Code', (r && r.error) || 'Could not do that.');
        if (r.removedAdded) { files = files.filter(x => x.path !== p); if (t) { t.saved = t.text; tabs.splice(tabs.indexOf(t), 1); if (active === p) activate(tabs.length ? tabs[tabs.length - 1].path : null); } }
        else { Object.assign(f, { modified: false }); if (t) { const rd = await code.read(p).catch(() => null); if (rd && rd.ok) { Object.assign(t, { text: rd.text || '', saved: rd.text || '', modified: false, kind: rd.kind, dataUrl: rd.dataUrl, size: rd.size }); } } if (active === p) activate(p); }
        if (extOf(p) === 'css') hotCss(p);
        renderTabs(); await refresh(true); say(r.removedAdded ? 'Deleted.' : 'Reverted. Press Apply to run the original.');
      }
      async function resetAll() {
        if (!(await need())) return;
        if (!(await confirmBox('Reset all edits', 'This removes every change and every file you added, and puts the original Cine/Figure OS back. It cannot be undone.', 'Reset everything'))) return;
        const r = await code.resetAll().catch(() => null);
        if (!r || !r.ok) return toast('Visual Code', (r && r.error) || 'Could not reset.');
        tabs.length = 0; active = null; showEmpty(); renderTabs(); await refresh(true); say('All edits removed. Press Apply to reload the original OS.', 6000);
        info.hasMods = false;
      }

      /* ---------- clicks ---------- */
      root.addEventListener('click', e => {
        const op = e.target.closest('[data-open]'); if (op) return openFile(op.dataset.open);
        const x = e.target.closest('[data-x]'); if (x) { e.stopPropagation(); return closeTab(x.dataset.x); }
        const tb = e.target.closest('.vc-tab'); if (tb) return activate(tb.dataset.p);
        const d = e.target.closest('.vc-r.dir'); if (d) { const p = d.dataset.d; openDirs.has(p) ? openDirs.delete(p) : openDirs.add(p); LS.set('vc.dirs', [...openDirs]); return renderTree(); }
        const f = e.target.closest('.vc-r.file'); if (f) return openFile(f.dataset.p);
        const b = e.target.closest('[data-a]'); if (!b) return;
        const a = b.dataset.a;
        if (a === 'save') return save(tabOf(active));
        if (a === 'saveall') return saveAll();
        if (a === 'apply') return apply(false);
        if (a === 'unlock') return unlock();
        if (a === 'new') return newFile();
        if (a === 'upload') { $('.vc-file', root).value = ''; return $('.vc-file', root).click(); }
        if (a === 'refresh') return refresh();
        if (a === 'fnext') return findNext(1);
        if (a === 'fprev') return findNext(-1);
        if (a === 'frep') return replaceOne();
        if (a === 'frepall') return replaceAll();
        if (a === 'fclose') return closeFind();
        if (a === 'menu') {
          const r = b.getBoundingClientRect();
          return ctxMenu({ clientX: r.right - 200, clientY: r.bottom + 4 }, [
            ['fa-shield-halved', 'Reload in safe mode (original files)', () => apply(true)],
            ['fa-folder-open', 'Open the folder with my edits', () => code.folder()],
            ['fa-trash-can-arrow-up', 'Reset all edits…', resetAll],
          ]);
        }
      });
      tree.addEventListener('contextmenu', e => {
        const r = e.target.closest('.vc-r.file'); if (!r) return; e.preventDefault(); e.stopPropagation();
        const p = r.dataset.p, f = files.find(x => x.path === p) || {};
        const items = [['fa-file-pen', 'Open', () => openFile(p)], ['fa-copy', 'Copy path', () => { navigator.clipboard && navigator.clipboard.writeText(p); say('Copied ' + p); }]];
        if (f.added) items.push(['fa-trash', 'Delete this file', () => revert(p)]); else if (f.modified) items.push(['fa-rotate-left', 'Revert to original', () => revert(p)]);
        ctxMenu(e, items);
      });
      el('.vc-sq input').oninput = e => { q = e.target.value; renderTree(); };
      el('.vc-file').onchange = e => addFiles(e.target.files);
      const f1 = el('.vc-find .f1'); f1.oninput = () => { countFind(); }; f1.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); findNext(e.shiftKey ? -1 : 1); } else if (e.key === 'Escape') closeFind(); };
      el('.vc-find .f2').onkeydown = e => { if (e.key === 'Enter') replaceOne(); else if (e.key === 'Escape') closeFind(); };

      // drag files onto the explorer to add them
      const side = el('.vc-side');
      let dragN = 0;
      const hasFiles = e => e.dataTransfer && [...(e.dataTransfer.types || [])].includes('Files');
      side.addEventListener('dragenter', e => { if (!hasFiles(e)) return; e.preventDefault(); dragN++; side.classList.add('drag'); });
      side.addEventListener('dragover', e => { if (hasFiles(e)) e.preventDefault(); });
      side.addEventListener('dragleave', () => { if (--dragN <= 0) { dragN = 0; side.classList.remove('drag'); } });
      side.addEventListener('drop', e => { if (!hasFiles(e)) return; e.preventDefault(); dragN = 0; side.classList.remove('drag'); addFiles(e.dataTransfer.files); });

      root.addEventListener('keydown', e => {
        const k = e.key.toLowerCase(), mod = e.ctrlKey || e.metaKey;
        if (mod && k === 's') { e.preventDefault(); e.shiftKey ? saveAll() : save(tabOf(active)); }
        else if (mod && k === 'f') { e.preventDefault(); openFind(); }
        else if (mod && k === 'w') { e.preventDefault(); active && closeTab(active); }
        else if (mod && k === 'enter') { e.preventDefault(); apply(false); }
        else if (e.key === 'Escape' && !modal.classList.contains('hidden')) { modal.classList.add('hidden'); modal.innerHTML = ''; }
      });

      w.onclose = () => { cancelAnimationFrame(raf); clearTimeout(msgTimer); };
      w.opts = o => { if (o && o.file) openFile(o.file); };

      /* ---------- start ---------- */
      showEmpty(); renderTabs();
      (async () => {
        const i = await code.info().catch(() => null); if (i && i.ok) info = i;
        banners(); await refresh();
        if (!info.unlocked) await unlock();
      })();
    },
  });
})();
