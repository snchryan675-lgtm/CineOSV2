// Cine/Figure OS - Xbox Cloud Gaming (https://www.xbox.com/en-us/play)
// In the desktop app (Electron) it runs the real site inside the OS in its own saved browser profile,
// so your Microsoft sign-in sticks. In a normal browser it opens the site in a new tab (or tries the OS proxy).
const XBOX_URL = 'https://www.xbox.com/en-us/play';
const XBOX_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0';
registerApp({
  id: 'xbox', name: 'Xbox', icon: 'fa-xbox', img: 'icons/xbox.png', bg: 'transparent', pinned: false, store: true, onOpen,
  mount(root, w, o) {
    root.classList.add('xbc');
    const electron = !!window.cine;
    root.innerHTML = `<div class="xbc-bar app-head"><img src="icons/xbox.svg" alt=""><strong>Xbox Cloud Gaming</strong>
      <button data-a="back" title="Back"><i class="fas fa-arrow-left"></i></button>
      <button data-a="reload" title="Reload"><i class="fas fa-rotate-right"></i></button>
      <button data-a="home" title="Xbox home"><i class="fas fa-house"></i></button></div><div class="xbc-view"></div>`;
    const view = $('.xbc-view', root);
    let el = null;
    const safe = fn => { try { fn(); } catch {} };

    function openWebview() {
      view.innerHTML = '';
      el = document.createElement('webview');
      el.setAttribute('src', XBOX_URL);
      el.setAttribute('partition', 'persist:xbox'); // keeps your Microsoft sign-in between launches
      el.setAttribute('useragent', XBOX_UA);        // Xbox Cloud Gaming wants an Edge / Chrome browser
      el.setAttribute('allowpopups', '');
      view.append(el);
    }
    function openProxy() {
      view.innerHTML = ''; el = document.createElement('iframe');
      el.src = '/proxy?url=' + encodeURIComponent(XBOX_URL); el.allow = 'autoplay; fullscreen; gamepad'; view.append(el);
    }
    function landing() {
      view.innerHTML = `<div class="xbc-land"><img src="icons/xbox.svg" alt=""><h1>Xbox Cloud Gaming</h1>
        <p>Xbox Cloud Gaming needs a real browser to stream. Open it in a new tab to play, or try it inside the OS (this usually won't work for sign-in or streaming).</p>
        <button class="xbc-btn" data-a="tab"><i class="fas fa-up-right-from-square"></i> Open Xbox Cloud Gaming</button>
        <button class="xbc-btn alt" data-a="proxy">Try inside the OS</button></div>`;
      el = null;
    }
    // sign-in popups open inside the same view
    let off = null;
    if (electron) off = window.cine.onOpenUrl(({ from, url }) => { try { if (el && el.getWebContentsId && from === el.getWebContentsId()) el.loadURL(url); } catch {} });
    w.onclose = () => off && off();
    root.addEventListener('click', e => {
      const b = e.target.closest('[data-a]'); if (!b) return;
      const a = b.dataset.a;
      if (a === 'tab') window.open(XBOX_URL, '_blank', 'noopener');
      if (a === 'proxy') openProxy();
      if (a === 'back') el && (el.goBack ? safe(() => el.goBack()) : safe(() => el.contentWindow.history.back()));
      if (a === 'reload') el && (el.reload ? safe(() => el.reload()) : (el.src = el.src));
      if (a === 'home') electron ? (el && el.loadURL ? safe(() => el.loadURL(XBOX_URL)) : openWebview()) : landing();
    });
    electron ? openWebview() : landing();
  },
});
