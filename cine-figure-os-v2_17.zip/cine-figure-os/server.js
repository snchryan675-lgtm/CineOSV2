// Cine/Figure OS dev server (`npm run dev`): static OS + data APIs + a rewriting proxy for plain browsers.
// The desktop app (`npm start`) does NOT use this: it serves everything through main.js with no local server.
const express = require('express');
const cheerio = require('cheerio');
const dns = require('dns').promises;
const net = require('net');
const path = require('path');
const { routes, UA } = require('./lib/api');

const app = express();
const PORT = process.env.PORT || 3000;

// Visual Code edits (a folder layered over public/); main.js sets it when Localhost mode starts
let overlayStatic = null;
function setOverlay(dir) { overlayStatic = dir ? express.static(dir, { dotfiles: 'ignore' }) : null; }
app.use((req, res, next) => (overlayStatic ? overlayStatic(req, res, next) : next()));
app.use(express.static(path.join(__dirname, 'public')));

// every data API lives in lib/api.js and is shared with the desktop app
for (const name of Object.keys(routes)) {
  app.get('/api/' + name, async (req, res) => {
    const { status, body } = await routes[name](req.query);
    res.status(status).json(body);
  });
}

/* ---------------- Cine-Web proxy ---------------- */
function isPrivateIp(ip) {
  return /^(10\.|127\.|0\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|::1$|fc|fd|fe80)/i.test(ip);
}
async function isSafe(u) {
  const { hostname, protocol } = new URL(u);
  if (!/^https?:$/.test(protocol)) return false;
  if (hostname === 'localhost') return false;
  const ips = net.isIP(hostname) ? [{ address: hostname }] : await dns.lookup(hostname, { all: true });
  return ips.every(i => !isPrivateIp(i.address));
}

const P = (u, base) => {
  try {
    if (!u || /^(data:|javascript:|mailto:|tel:|blob:|#)/i.test(u.trim())) return u;
    if (u.startsWith('/proxy?')) return u;
    return '/proxy?url=' + encodeURIComponent(new URL(u, base).href);
  } catch {
    return u;
  }
};

const shim = base => `(function(){var B=${JSON.stringify(base)};
function P(u){try{if(typeof u!=='string')u=String(u);if(u.indexOf('/proxy?')===0||/^(data:|blob:|javascript:|#)/.test(u))return u;var a=new URL(u,B);if(!/^https?:$/.test(a.protocol))return u;return '/proxy?url='+encodeURIComponent(a.href)}catch(e){return u}}
var of=window.fetch;if(of)window.fetch=function(i,o){try{if(typeof i==='string')i=P(i);else if(i&&i.url)i=new Request(P(i.url),i)}catch(e){}return of.call(this,i,o)};
var ox=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(m,u){arguments[1]=P(u);return ox.apply(this,arguments)};
window.open=function(u){if(u)location.href=P(u);return null};
document.addEventListener('submit',function(e){var f=e.target;if((f.method||'get').toLowerCase()!=='get')return;e.preventDefault();
var act=f.getAttribute('data-orig-action')||B;var u=new URL(act,B);var fd=new FormData(f);u.search='';fd.forEach(function(v,k){if(typeof v==='string')u.searchParams.append(k,v)});location.href=P(u.href)},true);
try{parent.postMessage({cineUrl:B,title:document.title},'*')}catch(e){}
addEventListener('load',function(){try{parent.postMessage({cineUrl:B,title:document.title},'*')}catch(e){}});
})();`;

app.get('/proxy', async (req, res) => {
  let target = String(req.query.url || '').trim();
  if (!target) return res.status(400).send('Missing url');
  if (!/^https?:\/\//i.test(target)) {
    target = /^[^\s]+\.[a-z]{2,}(\/.*)?$/i.test(target)
      ? 'https://' + target
      : 'https://html.duckduckgo.com/html/?q=' + encodeURIComponent(target);
  }
  try {
    if (!(await isSafe(target))) return res.status(403).send('Blocked address');
    const r = await fetch(target, {
      headers: {
        'user-agent': UA,
        accept: req.headers.accept || '*/*',
        'accept-language': 'en-US,en;q=0.9',
      },
      redirect: 'follow',
      signal: AbortSignal.timeout(20000),
    });
    const base = r.url;
    const ct = r.headers.get('content-type') || '';
    res.status(r.status);
    res.set('content-type', ct);
    res.set('cache-control', 'public, max-age=300');

    if (ct.includes('text/html')) {
      const $ = cheerio.load(await r.text());
      $('meta[http-equiv="Content-Security-Policy"], meta[http-equiv="content-security-policy"]').remove();
      $('base').remove();
      const attrs = { a: 'href', link: 'href', script: 'src', img: 'src', iframe: 'src', source: 'src', video: 'src', audio: 'src', form: 'action' };
      for (const [tag, attr] of Object.entries(attrs)) {
        $(tag).each((_, e) => {
          const v = $(e).attr(attr);
          if (tag === 'form') $(e).attr('data-orig-action', v ? new URL(v, base).href : base);
          if (v) $(e).attr(attr, P(v, base));
        });
      }
      $('[srcset]').removeAttr('srcset');
      $('[integrity]').removeAttr('integrity');
      $('[target]').attr('target', '_self');
      $('head').prepend(`<script>${shim(base)}</script>`);
      if (!$('head').length) $.root().prepend(`<script>${shim(base)}</script>`);
      return res.send($.html());
    }
    if (ct.includes('text/css')) {
      const css = (await r.text()).replace(/url\(\s*(['"]?)(.*?)\1\s*\)/g, (m, q, u) => `url(${q}${P(u, base)}${q})`)
        .replace(/@import\s+(['"])(.*?)\1/g, (m, q, u) => `@import ${q}${P(u, base)}${q}`);
      return res.send(css);
    }
    return res.send(Buffer.from(await r.arrayBuffer()));
  } catch (e) {
    res
      .status(502)
      .type('html')
      .send(
        `<body style="background:#0b0b0f;color:#ddd;font-family:sans-serif;padding:40px"><h2>Couldn't load that page</h2><p>${String(
          e.message
        ).replace(/[<>]/g, '')}</p></body>`
      );
  }
});

function start(port = PORT, host) {
  return new Promise((resolve, reject) => {
    const srv = host ? app.listen(port, host, () => resolve(srv)) : app.listen(port, () => resolve(srv));
    srv.on('error', reject);
  });
}

// `node server.js` (npm run dev) starts it directly; the desktop app (main.js) calls start() itself.
if (require.main === module) {
  start().then(srv => console.log(`\n  CINE/FIGURE OS running →  http://localhost:${srv.address().port}\n`)).catch(e => {
    console.error(e.code === 'EADDRINUSE' ? `\n  Port ${PORT} is busy. Try:  PORT=3001 npm run dev\n` : e);
    process.exit(1);
  });
}

module.exports = { app, start, setOverlay };
